# hlms — Microservice Integration Notes

This service (document/audit management) is now discovery- and config-ready
to join your other 5 microservices. No Lombok was added or used anywhere.

## What changed

1. **pom.xml**
   - Added `spring-cloud-dependencies` BOM (`2023.0.3`, matches Boot 3.3.5)
   - Added: `spring-cloud-starter-netflix-eureka-client`,
     `spring-cloud-starter-config`, `spring-cloud-starter-openfeign`,
     `spring-boot-starter-actuator`, `spring-boot-starter-validation`

2. **HlmsApplication.java** — added `@EnableDiscoveryClient` (registers with
   Eureka) and `@EnableFeignClients` (activates the Feign client below).

3. **New packages**
   - `client/LoanApplicationClient.java` — Feign client that calls
     `loan-application-service` (resolved via Eureka, no hardcoded host) to
     validate an `appId` before a document is stored against it.
   - `dto/LoanApplicationResponse.java` — response shape for that call.
     **Update the fields here once you confirm the real response body** of
     `GET /api/applications/{appId}` on the loan-application service.
   - `config/FeignClientConfig.java` — timeouts, logging, and forwards the
     incoming `Authorization` header + `X-Correlation-Id` to downstream
     calls so auth and tracing survive the hop between services.
   - `exceptions/ExternalServiceException.java` — new exception + handler
     entry in `GlobalExceptionHandler` (maps downstream failures to `503`,
     separate from a plain `404` when the appId genuinely doesn't exist).

4. **serviceImplementation/** — `ApplicationDocumentServiceImpl` and
   `PostDisbursementDocumentServiceImpl` now validate `appId` against
   loan-application-service before saving.

5. **resources/** — replaced the single `application.properties` with:
   - `application.yml` — service name, Eureka client config, Config Server
     import, Actuator exposure, and the configurable Feign service name.
   - `application-dev.yml` — local Postgres connection (still points at your
     original DB), read from env vars with the old values as fallback.
   - `application-docker.yml` — same, but pointing at container hostnames
     (`eureka-server`, `config-server`, `postgres-db`) for when this runs
     next to the other services in docker-compose.
   - Secrets (`DB_PASSWORD` etc.) are now env-var driven rather than
     hardcoded — move them into your Config Server repo or a secrets
     manager for anything beyond local dev.

6. **Dockerfile** — multi-stage build, defaults to the `docker` profile.

## What you need to check/do

- Confirm `loan-application-service` is the exact `spring.application.name`
  registered by that service in Eureka (override via
  `LOAN_APPLICATION_SERVICE_NAME` env var if different).
- Confirm the real JSON shape of its `GET /api/applications/{appId}`
  endpoint and adjust `LoanApplicationResponse` accordingly.
- If any of the other 4 services also need to call **this** service, they
  can do the same thing: add a Feign client with
  `name = "${services.hlms.name:hlms}"` pointing at this service's
  `/api/application-documents`, `/api/post-disbursement-documents`, or
  `/api/audit-logs` endpoints (all already Eureka-registered once this
  starts up).
- If you're running an API Gateway, this service just needs a route like
  `/hlms/**` -> `lb://hlms` (the `lb://` prefix tells the gateway to
  resolve the instance through Eureka).
