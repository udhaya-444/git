package com.tcs.hlms.client;

import com.tcs.hlms.config.FeignClientConfig;
import com.tcs.hlms.dto.LoanApplicationResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Declarative REST client for loan-application-service.
 *
 * The "name" below is resolved through Eureka, so no hardcoded host/port is
 * needed - it must exactly match that service's spring.application.name as
 * registered with the Discovery Server. It can be overridden per-environment
 * via the "services.loan-application.name" property (see application.yml).
 */
@FeignClient(
        name = "${services.loan-application.name:loan-application-service}",
        configuration = FeignClientConfig.class)
public interface LoanApplicationClient {

    @GetMapping("/api/applications/{appId}")
    LoanApplicationResponse getApplicationById(@PathVariable("appId") String appId);
}
