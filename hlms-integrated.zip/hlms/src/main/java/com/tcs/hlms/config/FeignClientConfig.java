package com.tcs.hlms.config;

import feign.Logger;
import feign.Request;
import feign.RequestInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.concurrent.TimeUnit;

/**
 * Shared configuration applied to every Feign client in this service.
 *
 * - Sets sane connect/read timeouts so a slow downstream service
 *   (e.g. loan-application-service) cannot hang a request indefinitely.
 * - Logs the request/response line for every Feign call (full body logging
 *   is enabled only in the "dev" profile via application-dev.yml).
 * - Forwards the incoming Authorization header (JWT) and a correlation id
 *   onto outgoing Feign calls so the downstream service can authorize the
 *   request and traces can be followed across services.
 */
@Configuration
public class FeignClientConfig {

    public static final String CORRELATION_ID_HEADER = "X-Correlation-Id";

    @Bean
    public Request.Options requestOptions() {
        return new Request.Options(
                3000, TimeUnit.MILLISECONDS,   // connect timeout
                5000, TimeUnit.MILLISECONDS,   // read timeout
                true);
    }

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.BASIC;
    }

    @Bean
    public RequestInterceptor forwardHeadersInterceptor() {
        return requestTemplate -> {
            ServletRequestAttributes attributes =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();

            if (attributes == null) {
                return;
            }

            String authorization = attributes.getRequest().getHeader("Authorization");
            if (authorization != null) {
                requestTemplate.header("Authorization", authorization);
            }

            String correlationId = attributes.getRequest().getHeader(CORRELATION_ID_HEADER);
            if (correlationId != null) {
                requestTemplate.header(CORRELATION_ID_HEADER, correlationId);
            }
        };
    }
}
