package com.tcs.hlms.dto;

/**
 * Minimal view of a loan application as returned by loan-application-service.
 *
 * NOTE: field names here must match the actual response body of that
 * service's GET /api/applications/{appId} endpoint. Adjust the field
 * names/types below once that service's contract is confirmed - this
 * shape is the commonly-needed subset (id + status + owning customer)
 * for validating an appId before a document is stored against it.
 */
public class LoanApplicationResponse {

    private String appId;
    private String applicationStatus;
    private String customerId;

    public LoanApplicationResponse() {
    }

    public LoanApplicationResponse(String appId, String applicationStatus, String customerId) {
        this.appId = appId;
        this.applicationStatus = applicationStatus;
        this.customerId = customerId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
}
