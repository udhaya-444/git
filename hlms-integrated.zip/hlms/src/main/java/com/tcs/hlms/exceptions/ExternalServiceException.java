package com.tcs.hlms.exceptions;

/**
 * Thrown when a call to another microservice (e.g. loan-application-service
 * via Feign) fails for a reason other than "resource not found" - for
 * example the service is down, times out, or returns a 5xx error.
 */
public class ExternalServiceException extends RuntimeException {

    public ExternalServiceException(String message) {
        super(message);
    }

    public ExternalServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
