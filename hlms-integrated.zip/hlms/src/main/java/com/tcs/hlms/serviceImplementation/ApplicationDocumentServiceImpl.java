package com.tcs.hlms.serviceImplementation;
import com.tcs.hlms.client.LoanApplicationClient;
import com.tcs.hlms.exceptions.ExternalServiceException;
import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.entity.ApplicationDocumentEntity;
import com.tcs.hlms.repository.ApplicationDocumentRepository;
import com.tcs.hlms.service.ApplicationDocumentService;
import feign.FeignException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApplicationDocumentServiceImpl
        implements ApplicationDocumentService {

    private final ApplicationDocumentRepository repository;
    private final LoanApplicationClient loanApplicationClient;

    public ApplicationDocumentServiceImpl(
            ApplicationDocumentRepository repository,
            LoanApplicationClient loanApplicationClient) {
        this.repository = repository;
        this.loanApplicationClient = loanApplicationClient;
    }

    @Override
    public ApplicationDocumentEntity saveDocument(
            ApplicationDocumentEntity document) {

        if (document != null) {
            validateApplicationExists(document.getAppId());
        }

        return repository.save(document);
    }

    /**
     * Confirms the loan application referenced by this document actually
     * exists by calling loan-application-service through Feign, so we never
     * store a document against an appId that isn't real.
     */
    private void validateApplicationExists(String appId) {

        if (appId == null) {
            return;
        }

        try {
            loanApplicationClient.getApplicationById(appId);

        } catch (FeignException.NotFound ex) {
            throw new ResourceNotFoundException(
                    "Loan application not found : " + appId);

        } catch (FeignException ex) {
            throw new ExternalServiceException(
                    "loan-application-service call failed while validating appId "
                            + appId, ex);
        }
    }

    @Override
    public ApplicationDocumentEntity getDocumentById(
            String documentId) {

        return repository.findById(documentId)
        		.orElseThrow(() ->
        	    new ResourceNotFoundException(
        	        "Application Document not found : "
        	                + documentId));
    }

    @Override
    public List<ApplicationDocumentEntity> getDocumentsByAppId(
            String appId) {

        return repository.findByAppId(appId);
    }

    @Override
    public List<ApplicationDocumentEntity> getAllDocuments() {
        return repository.findAll();
    }

    @Override
    public void deleteDocument(String documentId) {
        repository.deleteById(documentId);
    }
}