package com.tcs.hlms.serviceImplementation;
import com.tcs.hlms.client.LoanApplicationClient;
import com.tcs.hlms.exceptions.ExternalServiceException;
import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.entity.PostDisbursementDocumentEntity;
import com.tcs.hlms.repository.PostDisbursementDocumentRepository;
import com.tcs.hlms.service.PostDisbursementDocumentService;
import feign.FeignException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostDisbursementDocumentServiceImpl
        implements PostDisbursementDocumentService {

    private final PostDisbursementDocumentRepository repository;
    private final LoanApplicationClient loanApplicationClient;

    public PostDisbursementDocumentServiceImpl(
            PostDisbursementDocumentRepository repository,
            LoanApplicationClient loanApplicationClient) {
        this.repository = repository;
        this.loanApplicationClient = loanApplicationClient;
    }

    @Override
    public PostDisbursementDocumentEntity saveDocument(
            PostDisbursementDocumentEntity document) {

        if (document != null) {
            validateApplicationExists(document.getAppId());
        }

        return repository.save(document);
    }

    /**
     * Confirms the loan application referenced by this document actually
     * exists by calling loan-application-service through Feign.
     */
    private void validateApplicationExists(String appId) {

        if (appId == null) {
            return;
        }

        try {
            loanApplicationClient.getApplicationById(appId);

        } catch (FeignException.NotFound ex) {
            throw new ResourceNotFoundException(
                    "Loan application not found : " + appId);

        } catch (FeignException ex) {
            throw new ExternalServiceException(
                    "loan-application-service call failed while validating appId "
                            + appId, ex);
        }
    }

    @Override
    public PostDisbursementDocumentEntity getDocumentById(
            String documentId) {

        return repository.findById(documentId)
        		.orElseThrow(() ->
        	    new ResourceNotFoundException(
        	        "Post Disbursement Document not found : "
        	                + documentId));
    }

    @Override
    public List<PostDisbursementDocumentEntity> getDocumentsByAppId(
            String appId) {

        return repository.findByAppId(appId);
    }

    @Override
    public List<PostDisbursementDocumentEntity> getAllDocuments() {

        return repository.findAll();
    }

    @Override
    public void deleteDocument(String documentId) {

        repository.deleteById(documentId);
    }
}