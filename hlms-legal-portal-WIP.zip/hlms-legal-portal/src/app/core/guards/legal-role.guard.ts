import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * Restricts routes to the Legal & Valuation Team. Assumes authGuard already ran
 * (compose both on protected routes: canActivate: [authGuard, legalRoleGuard]).
 */
export const legalRoleGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const user = auth.currentUser();
  if (user?.role === 'legal') {
    return true;
  }

  // Not signed in at all -> let them log in; signed in as some other role -> send home instead of looping.
  return router.createUrlTree([user ? '/' : '/login']);
};
