/** ApplicationDocumentEntity — documents submitted with the original loan application. */
export interface ApplicationDocument {
  documentId?: string;
  appId: string;
  docType: string;
  fileName: string;
  fileSize?: number;
  uploadedAt?: string;
  verificationStatus: 'Pending' | 'Verified' | 'Rejected' | string;
  verifiedBy?: string | null;
  verifiedAt?: string | null;
  remarks?: string;
}

/** PostDisbursementDocumentEntity — documents uploaded by the customer after disbursement. */
export interface PostDisbursementDocument {
  pdDocId?: string;
  appId: string;
  docType: string;
  fileName: string;
  fileSize?: number;
  note?: string;
  status: 'Pending' | 'Verified' | 'Rejected' | string;
  uploadedAt?: string;
  verifiedBy?: string | null;
  verifiedAt?: string | null;
  remarks?: string;
}

export function docBadgeClass(status: string): string {
  return status === 'Verified' ? 'badge-green' : status === 'Rejected' ? 'badge-red' : 'badge-orange';
}
