/** LegalVerificationDTO — the Legal Team's decision on an application. */
export interface LegalVerification {
  verificationId?: number;
  appId: string;
  decision: 'Approved' | 'Rejected' | 'Query Raised' | null;
  decisionDate?: string | null;
  officerEmail?: string | null;
  remarks?: string;
  infoRequested?: boolean;
  infoRequestDetails?: string;
  infoRequestedAt?: string | null;
}

/** LegalChecklistItemDTO — one row per title/mortgage document check. */
export interface LegalChecklistItem {
  checklistItemId?: string;
  appId: string;
  checklistKey: string;
  status: 'Pending' | 'Verified' | 'Discrepancy';
}

export const LEGAL_CHECKLIST: { key: string; label: string }[] = [
  { key: 'titleDeed', label: 'Title Deed / Ownership Document' },
  { key: 'encumbrance', label: 'Encumbrance Certificate (13 yrs)' },
  { key: 'saleDeed', label: 'Sale Deed / Agreement to Sell' },
  { key: 'noc', label: 'NOC from Society / Builder / Competent Authority' },
  { key: 'valuation', label: 'Property Valuation Report' },
  { key: 'taxReceipt', label: 'Latest Property Tax Receipt' },
];

/** LegalNoticeDTO — demand notices, SARFAESI notices & manual correspondence. */
export interface LegalNotice {
  noticeId?: string;
  noticeNo: string;
  appId?: string | null;
  noticeType: string;
  issueDate: string;
  dueDate?: string | null;
  status: 'Active' | 'Closed' | string;
  officerEmail?: string;
  content: string;
}

/** BankOfficeDecisionDTO — reference only (Bank Office's own sign-off). */
export interface BankOfficeDecision {
  decisionId?: number;
  appId: string;
  status: string;
  officerEmail?: string;
  decisionDate?: string;
  reason?: string;
  remarks?: string;
}

export function decisionBadgeClass(d: string | null | undefined): string {
  if (d === 'Approved') return 'badge-green';
  if (d === 'Rejected') return 'badge-red';
  if (d === 'Query Raised') return 'badge-orange';
  return 'badge-gray';
}
