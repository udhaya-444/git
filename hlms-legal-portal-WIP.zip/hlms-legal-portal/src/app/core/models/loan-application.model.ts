/** Mirrors loan-service's LoanApplication entity (loan_application table). */
export interface LoanApplication {
  appId: string;
  trackingNo: string;
  userEmail: string;
  productId?: string;
  loanAmount: number;
  tenureYears: number;
  purpose?: string;
  interestRate?: number;
  status: string; // Draft, Submitted, Under Review, Rejected, Disbursed
  stageIndex: number;
  currentStep?: number;
  formData?: string;
  savedAt?: string;
  createdAt: string;

  applicantName?: string;
  applicantMobile?: string;
  applicantPan?: string;

  addrDoorNo?: string;
  addrStreet?: string;
  addrCity?: string;
  addrState?: string;
  addrPincode?: string;

  employmentType?: string;
  employer?: string;
  monthlyIncome?: number;
  otherEmis?: number;

  propertyAddress?: string;
  propertyType?: string;
  propertyValue?: number;

  deletedAt?: string | null;
}

/** The Legal & Valuation Team acts once an application reaches this stage
 *  (index 3 = "Mortgage / Property Verification" in WORKFLOW_STAGES). */
export const LEGAL_STAGE_INDEX = 3;

export const WORKFLOW_STAGES = [
  'Application Submitted',
  'Document Verification',
  'Eligibility & Credit Check',
  'Mortgage / Property Verification',
  'Final Approval',
  'Disbursement',
];
