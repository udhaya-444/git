/** notification-service's Notification entity. */
export interface AppNotification {
  notificationId?: string;
  userEmail: string;
  title: string;
  body: string;
  channels?: string[];
  read?: boolean;
  createdAt?: string;
}
