export type UserRole = 'admin' | 'employee' | 'legal' | 'bankoffice' | 'customer' | 'bidder' | 'loanofficer';

export const ROLE_LABELS: Record<string, string> = {
  admin: 'Admin',
  employee: 'Employee',
  legal: 'Legal Team',
  bankoffice: 'Bank Office',
  customer: 'Customer',
  bidder: 'Bidder',
  loanofficer: 'Loan Officer',
};

/** appUserEntity, as returned by GET /user-service/api/users/{email} */
export interface AppUser {
  email: string;
  name: string;
  mobile: string;
  role: UserRole;
  active: boolean;
  idType?: string;
  idNumber?: string;
  prefSms?: boolean;
  prefEmail?: boolean;
  prefInapp?: boolean;
  createdAt?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
}

/** Decoded JWT payload (user-service signs { sub: email, role }) */
export interface JwtClaims {
  sub: string;
  role: UserRole;
  iat: number;
  exp: number;
}
