import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AuctionCase, AuctionNote, Bid, EmiInstallment } from '../models/auction.model';

/** Wraps repayment-service's /api/auctions (+ nested notes/bids) and EMI schedule lookup. */
@Injectable({ providedIn: 'root' })
export class AuctionService {
  private readonly baseUrl = `${environment.apiBaseUrl}/repayment-service/api/auctions`;
  private readonly emiUrl = `${environment.apiBaseUrl}/repayment-service/api/emi`;

  constructor(private http: HttpClient) {}

  // ---- Auction case (SARFAESI recovery stage) ----

  listAll(): Observable<AuctionCase[]> {
    return this.http.get<AuctionCase[]>(this.baseUrl);
  }

  getByAppId(appId: string): Observable<AuctionCase> {
    return this.http.get<AuctionCase>(`${this.baseUrl}/by-application/${encodeURIComponent(appId)}`);
  }

  create(dto: AuctionCase): Observable<AuctionCase> {
    return this.http.post<AuctionCase>(this.baseUrl, dto);
  }

  update(auctionId: number, dto: AuctionCase): Observable<AuctionCase> {
    return this.http.put<AuctionCase>(`${this.baseUrl}/${auctionId}`, dto);
  }

  // ---- Notes (nested under appId) ----

  getNotes(appId: string): Observable<AuctionNote[]> {
    return this.http.get<AuctionNote[]>(`${this.baseUrl}/${encodeURIComponent(appId)}/notes`);
  }

  addNote(appId: string, noteText: string): Observable<AuctionNote> {
    return this.http.post<AuctionNote>(`${this.baseUrl}/${encodeURIComponent(appId)}/notes`, { appId, noteText });
  }

  // ---- Bids (nested under appId; read-only from Legal's side) ----

  getBids(appId: string): Observable<Bid[]> {
    return this.http.get<Bid[]>(`${this.baseUrl}/${encodeURIComponent(appId)}/bids`);
  }

  // ---- EMI schedule (used to show outstanding balance / overdue count on the auction/case screens) ----

  getSchedule(appId: string): Observable<EmiInstallment[]> {
    return this.http.get<EmiInstallment[]>(`${this.emiUrl}/${encodeURIComponent(appId)}/schedule`);
  }
}
