import { Injectable, computed, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap, switchMap, of } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AppUser, JwtClaims, LoginRequest, LoginResponse } from '../models/user.model';

const TOKEN_KEY = 'hlms_legal_token';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly userServiceUrl = `${environment.apiBaseUrl}/user-service/api/users`;
  private readonly otpUrl = `${environment.apiBaseUrl}/user-service/api/otp`;

  /** The signed-in user's profile, loaded once after login/refresh. */
  readonly currentUser = signal<AppUser | null>(null);
  readonly isAuthenticated = computed(() => !!this.currentUser());

  constructor(private http: HttpClient, private router: Router) {}

  get token(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  /** Decodes the JWT payload without verifying the signature (verification is server-side). */
  private decodeToken(token: string): JwtClaims | null {
    try {
      const payload = token.split('.')[1];
      const json = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
      return JSON.parse(decodeURIComponent(escape(json)));
    } catch {
      return null;
    }
  }

  /** Logs in against user-service, then loads the full profile so we know name/role/etc. */
  login(req: LoginRequest): Observable<AppUser> {
    return this.http.post<LoginResponse>(`${this.userServiceUrl}/login`, req).pipe(
      tap((res) => localStorage.setItem(TOKEN_KEY, res.token)),
      switchMap((res) => {
        const claims = this.decodeToken(res.token);
        const email = claims?.sub ?? req.email;
        return this.http.get<AppUser>(`${this.userServiceUrl}/${encodeURIComponent(email)}`);
      }),
      tap((user) => this.currentUser.set(user))
    );
  }

  /** Restores the session on app start-up if a valid, non-expired token is stored. */
  restoreSession(): Observable<AppUser | null> {
    const token = this.token;
    if (!token) return of(null);
    const claims = this.decodeToken(token);
    if (!claims || claims.exp * 1000 < Date.now()) {
      this.logout();
      return of(null);
    }
    return this.http.get<AppUser>(`${this.userServiceUrl}/${encodeURIComponent(claims.sub)}`).pipe(
      tap((user) => this.currentUser.set(user))
    );
  }

  logout(): void {
    localStorage.removeItem(TOKEN_KEY);
    this.currentUser.set(null);
    this.router.navigate(['/login']);
  }

  updateProfile(email: string, patch: Partial<AppUser>): Observable<AppUser> {
    const current = this.currentUser();
    const body = { ...current, ...patch };
    return this.http.put<AppUser>(`${this.userServiceUrl}/${encodeURIComponent(email)}`, body).pipe(
      tap((user) => this.currentUser.set(user))
    );
  }

  /** Step 1 of "forgot password" — sends a real OTP via notification-service. */
  requestPasswordResetOtp(email: string): Observable<string> {
    return this.http.post(`${this.otpUrl}/generate`, { email, purpose: 'RESET_PASSWORD' }, { responseType: 'text' });
  }

  verifyPasswordResetOtp(email: string, otpCode: string): Observable<string> {
    return this.http.post(`${this.otpUrl}/verify`, { email, otpCode }, { responseType: 'text' });
  }

  resetPassword(email: string, otpCode: string, newPassword: string): Observable<string> {
    return this.http.post(`${this.userServiceUrl}/reset-password`, { email, otpCode, newPassword }, { responseType: 'text' });
  }
}
