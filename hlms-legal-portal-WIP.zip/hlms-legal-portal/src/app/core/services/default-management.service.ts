import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

/** Wraps repayment-service's /api/default-management (US-DMNG-01/04/05). */
@Injectable({ providedIn: 'root' })
export class DefaultManagementService {
  private readonly baseUrl = `${environment.apiBaseUrl}/repayment-service/api/default-management`;

  constructor(private http: HttpClient) {}

  /** Plain-text status, e.g. "No Default" / "Default" — drives the overdue banner on case detail. */
  getDefaultStatus(appId: string): Observable<string> {
    return this.http.get(`${this.baseUrl}/status/${encodeURIComponent(appId)}`, { responseType: 'text' });
  }

  /** Plain-text escalation level, e.g. "None" / "Notice" / "Legal Action" / "Auction". */
  getEscalationLevel(appId: string): Observable<string> {
    return this.http.get(`${this.baseUrl}/escalation/${encodeURIComponent(appId)}`, { responseType: 'text' });
  }

  /** Set of appIds currently flagged overdue — used to badge the Legal dashboard/queue. */
  detectOverdueLoans(): Observable<string[]> {
    return this.http.get<string[]>(`${this.baseUrl}/overdue`);
  }
}
