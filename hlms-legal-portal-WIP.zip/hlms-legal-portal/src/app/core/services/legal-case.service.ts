import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { LegalVerification, LegalChecklistItem, BankOfficeDecision } from '../models/legal.model';

/**
 * Wraps legal-service's three case-related resources:
 *  - /api/legal/verifications   (the Legal Team's own decision)
 *  - /api/legal/checklist-items (title/mortgage document checklist rows)
 *  - /api/bank-office/decisions (read-only reference to Bank Office's sign-off)
 */
@Injectable({ providedIn: 'root' })
export class LegalCaseService {
  private readonly verificationsUrl = `${environment.apiBaseUrl}/legal-service/api/legal/verifications`;
  private readonly checklistUrl = `${environment.apiBaseUrl}/legal-service/api/legal/checklist-items`;
  private readonly bankOfficeUrl = `${environment.apiBaseUrl}/legal-service/api/bank-office/decisions`;

  constructor(private http: HttpClient) {}

  // ---- Legal verification (decision) ----

  getVerificationByApp(appId: string): Observable<LegalVerification> {
    return this.http.get<LegalVerification>(`${this.verificationsUrl}/by-application/${encodeURIComponent(appId)}`);
  }

  createVerification(dto: LegalVerification): Observable<LegalVerification> {
    return this.http.post<LegalVerification>(this.verificationsUrl, dto);
  }

  updateVerification(verificationId: number, dto: LegalVerification): Observable<LegalVerification> {
    return this.http.put<LegalVerification>(`${this.verificationsUrl}/${verificationId}`, dto);
  }

  listAllVerifications(): Observable<LegalVerification[]> {
    return this.http.get<LegalVerification[]>(this.verificationsUrl);
  }

  // ---- Checklist items ----

  listChecklistItems(): Observable<LegalChecklistItem[]> {
    return this.http.get<LegalChecklistItem[]>(this.checklistUrl);
  }

  createChecklistItem(dto: LegalChecklistItem): Observable<LegalChecklistItem> {
    return this.http.post<LegalChecklistItem>(this.checklistUrl, dto);
  }

  updateChecklistItem(checklistItemId: string, dto: LegalChecklistItem): Observable<LegalChecklistItem> {
    return this.http.put<LegalChecklistItem>(`${this.checklistUrl}/${encodeURIComponent(checklistItemId)}`, dto);
  }

  // ---- Bank Office decision (reference only, read-only from Legal's side) ----

  getBankOfficeDecisionByApp(appId: string): Observable<BankOfficeDecision> {
    return this.http.get<BankOfficeDecision>(`${this.bankOfficeUrl}/by-application/${encodeURIComponent(appId)}`);
  }
}
