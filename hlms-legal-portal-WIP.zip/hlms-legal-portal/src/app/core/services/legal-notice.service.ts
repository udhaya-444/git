import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { LegalNotice } from '../models/legal.model';

@Injectable({ providedIn: 'root' })
export class LegalNoticeService {
  private readonly baseUrl = `${environment.apiBaseUrl}/legal-service/api/legal-notices`;

  constructor(private http: HttpClient) {}

  listAll(): Observable<LegalNotice[]> {
    return this.http.get<LegalNotice[]>(this.baseUrl);
  }

  getById(noticeId: string): Observable<LegalNotice> {
    return this.http.get<LegalNotice>(`${this.baseUrl}/${encodeURIComponent(noticeId)}`);
  }

  /** Drafts and logs a new legal notice (demand notice, SARFAESI notice, or manual correspondence). */
  create(dto: LegalNotice): Observable<LegalNotice> {
    return this.http.post<LegalNotice>(this.baseUrl, dto);
  }

  update(noticeId: string, dto: LegalNotice): Observable<LegalNotice> {
    return this.http.put<LegalNotice>(`${this.baseUrl}/${encodeURIComponent(noticeId)}`, dto);
  }

  /** Soft-deletes (closes) a notice; used when withdrawing an incorrectly issued notice. */
  softDelete(noticeId: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${encodeURIComponent(noticeId)}`);
  }
}
