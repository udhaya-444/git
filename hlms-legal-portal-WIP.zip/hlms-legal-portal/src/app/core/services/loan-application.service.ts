import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { LoanApplication } from '../models/loan-application.model';

@Injectable({ providedIn: 'root' })
export class LoanApplicationService {
  private readonly baseUrl = `${environment.apiBaseUrl}/loan-service/api/loan-applications`;

  constructor(private http: HttpClient) {}

  /** All applications across every user — this is what the Legal Review Queue filters down from. */
  listAll(): Observable<LoanApplication[]> {
    return this.http.get<LoanApplication[]>(`${this.baseUrl}/all`);
  }

  get(appId: string): Observable<LoanApplication> {
    return this.http.get<LoanApplication>(`${this.baseUrl}/${encodeURIComponent(appId)}`);
  }

  track(trackingNo: string): Observable<LoanApplication> {
    return this.http.get<LoanApplication>(`${this.baseUrl}/track/${encodeURIComponent(trackingNo)}`);
  }

  workflowStages(): Observable<string[]> {
    return this.http.get<string[]>(`${this.baseUrl}/workflow-stages`);
  }

  /** Advances (or otherwise updates) the application's workflow stage/status — used once Legal reaches a decision. */
  updateStage(appId: string, stageIndex: number, status: string): Observable<LoanApplication> {
    return this.http.patch<LoanApplication>(`${this.baseUrl}/${encodeURIComponent(appId)}/stage`, {
      stageIndex,
      status,
    });
  }
}
