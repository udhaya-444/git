import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AppNotification } from '../models/notification.model';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private readonly baseUrl = `${environment.apiBaseUrl}/notification-service/api/notifications`;

  constructor(private http: HttpClient) {}

  listForUser(userEmail: string): Observable<AppNotification[]> {
    return this.http.get<AppNotification[]>(this.baseUrl, { params: { userEmail } });
  }

  listUnread(userEmail: string): Observable<AppNotification[]> {
    return this.http.get<AppNotification[]>(`${this.baseUrl}/unread`, { params: { userEmail } });
  }

  markRead(notificationId: string): Observable<AppNotification> {
    return this.http.patch<AppNotification>(`${this.baseUrl}/${encodeURIComponent(notificationId)}/read`, {});
  }

  /** Sends an in-app/email/sms notification, e.g. to alert a role group that a notice/document needs attention. */
  send(userEmail: string, title: string, body: string, channels: string[] = ['inapp']): Observable<AppNotification> {
    return this.http.post<AppNotification>(this.baseUrl, { userEmail, title, body, channels });
  }
}
