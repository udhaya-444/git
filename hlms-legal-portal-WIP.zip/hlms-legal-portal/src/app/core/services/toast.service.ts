import { Injectable, signal } from '@angular/core';

export type ToastKind = 'success' | 'error' | 'info' | 'warning';

export interface Toast {
  id: number;
  title: string;
  message?: string;
  kind: ToastKind;
}

/** Mirrors the legacy app's toast(title, message, kind) helper as an injectable signal store. */
@Injectable({ providedIn: 'root' })
export class ToastService {
  private nextId = 1;
  readonly toasts = signal<Toast[]>([]);

  show(title: string, message?: string, kind: ToastKind = 'info', durationMs = 4000): void {
    const toast: Toast = { id: this.nextId++, title, message, kind };
    this.toasts.update((list) => [...list, toast]);
    if (durationMs > 0) {
      setTimeout(() => this.dismiss(toast.id), durationMs);
    }
  }

  success(title: string, message?: string): void {
    this.show(title, message, 'success');
  }

  error(title: string, message?: string): void {
    this.show(title, message, 'error');
  }

  info(title: string, message?: string): void {
    this.show(title, message, 'info');
  }

  warning(title: string, message?: string): void {
    this.show(title, message, 'warning');
  }

  dismiss(id: number): void {
    this.toasts.update((list) => list.filter((t) => t.id !== id));
  }
}
