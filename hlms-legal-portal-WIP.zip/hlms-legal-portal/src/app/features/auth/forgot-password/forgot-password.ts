import { Component, ElementRef, QueryList, ViewChildren, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Matches the legacy REGEX.password: at least one lower, one upper, one digit, one symbol, 8+ chars.
const PASSWORD_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_\-+=]).{8,}$/;

type Step = 'email' | 'otp' | 'reset';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div class="auth-screen">
      <div class="auth-wrap">
        <div class="auth-brand">
          <img src="/logo.png" alt="HLMS" />
          <div>
            <div class="t1">HLMS</div>
            <div class="t2">Legal &amp; Valuation Team Portal</div>
          </div>
        </div>

        <div class="auth-form">
          @if (step() === 'email') {
            <h2>Reset your password</h2>
            <div class="sub">Enter your registered email to receive an OTP.</div>
            <form [formGroup]="emailForm" (ngSubmit)="submitEmail()">
              <div class="field">
                <label>Email<span class="req">*</span></label>
                <input formControlName="email" placeholder="you@hlms.example.com" />
                @if (emailSubmitted() && emailForm.controls.email.invalid) {
                  <div class="error">Enter a valid email address.</div>
                }
              </div>
              <button class="btn btn-primary btn-block" type="submit" [disabled]="loading()">
                {{ loading() ? 'Sending…' : 'Send OTP' }}
              </button>
            </form>
          }

          @if (step() === 'otp') {
            <h2>Verify OTP</h2>
            <div class="sub">Enter the OTP sent to reset your password.</div>
            @if (demoOtpNote(); as note) {
              <div class="demo-note">{{ note }}</div>
            }
            <div class="otp-boxes">
              @for (i of [0, 1, 2, 3, 4, 5]; track i) {
                <input
                  #otpBox
                  maxlength="1"
                  inputmode="numeric"
                  [value]="otpDigits()[i]"
                  (input)="onDigitInput($event, i)"
                  (keydown)="onDigitKeydown($event, i)"
                />
              }
            </div>
            @if (otpError()) {
              <div class="error" style="text-align:center;">{{ otpError() }}</div>
            }
            <button class="btn btn-primary btn-block" type="button" [disabled]="loading()" (click)="submitOtp()">
              {{ loading() ? 'Verifying…' : 'Verify OTP' }}
            </button>
            <div class="auth-switch"><a (click)="resendOtp()">Resend OTP</a></div>
          }

          @if (step() === 'reset') {
            <h2>Set a new password</h2>
            <div class="sub">Choose a strong password for your account.</div>
            <form [formGroup]="resetForm" (ngSubmit)="submitReset()">
              <div class="field">
                <label>New Password<span class="req">*</span></label>
                <div class="password-wrap">
                  <input
                    formControlName="newPassword"
                    [type]="showPassword() ? 'text' : 'password'"
                    placeholder="At least 8 characters"
                  />
                  <span class="password-toggle" (click)="showPassword.set(!showPassword())">👁</span>
                </div>
                @if (resetSubmitted() && resetForm.controls.newPassword.invalid) {
                  <div class="error">
                    Password must be 8+ characters and include upper, lower, a number and a symbol.
                  </div>
                }
              </div>
              <div class="field">
                <label>Confirm Password<span class="req">*</span></label>
                <input
                  formControlName="confirmPassword"
                  [type]="showPassword() ? 'text' : 'password'"
                  placeholder="Re-enter new password"
                />
                @if (resetSubmitted() && resetForm.controls.confirmPassword.value !== resetForm.controls.newPassword.value) {
                  <div class="error">Passwords do not match.</div>
                }
              </div>
              <button class="btn btn-primary btn-block" type="submit" [disabled]="loading()">
                {{ loading() ? 'Saving…' : 'Reset Password' }}
              </button>
            </form>
          }

          <div class="auth-switch"><a routerLink="/login">Back to Log In</a></div>
        </div>
      </div>
    </div>
  `,
})
export class ForgotPasswordComponent {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);

  @ViewChildren('otpBox') otpBoxes!: QueryList<ElementRef<HTMLInputElement>>;

  readonly step = signal<Step>('email');
  readonly loading = signal(false);
  readonly showPassword = signal(false);

  private email = '';

  readonly emailSubmitted = signal(false);
  readonly emailForm = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.pattern(EMAIL_RE)]],
  });

  readonly otpDigits = signal<string[]>(['', '', '', '', '', '']);
  readonly otpError = signal<string | null>(null);
  readonly demoOtpNote = signal<string | null>(null);

  readonly resetSubmitted = signal(false);
  readonly resetForm = this.fb.nonNullable.group({
    newPassword: ['', [Validators.required, Validators.pattern(PASSWORD_RE)]],
    confirmPassword: ['', Validators.required],
  });

  submitEmail(): void {
    this.emailSubmitted.set(true);
    if (this.emailForm.invalid) return;

    this.email = this.emailForm.getRawValue().email;
    this.requestOtp();
  }

  private requestOtp(): void {
    this.loading.set(true);
    this.auth.requestPasswordResetOtp(this.email).subscribe({
      next: (otp) => {
        this.loading.set(false);
        this.step.set('otp');
        this.otpDigits.set(['', '', '', '', '', '']);
        this.otpError.set(null);
        // The backend returns the raw OTP in this environment (no SMS/email gateway configured yet).
        this.demoOtpNote.set(`Your OTP is ${otp} (shown here until real delivery is wired up).`);
      },
      error: () => {
        this.loading.set(false);
        this.toast.error('Could Not Send OTP', 'Check the email address and try again.');
      },
    });
  }

  resendOtp(): void {
    this.toast.info('OTP Resent', 'A new OTP has been generated.');
    this.requestOtp();
  }

  onDigitInput(event: Event, index: number): void {
    const input = event.target as HTMLInputElement;
    const value = input.value.replace(/\D/g, '').slice(0, 1);
    this.otpDigits.update((digits) => {
      const next = [...digits];
      next[index] = value;
      return next;
    });
    if (value && index < 5) {
      this.otpBoxes.get(index + 1)?.nativeElement.focus();
    }
  }

  onDigitKeydown(event: KeyboardEvent, index: number): void {
    if (event.key === 'Backspace' && !this.otpDigits()[index] && index > 0) {
      this.otpBoxes.get(index - 1)?.nativeElement.focus();
    }
  }

  submitOtp(): void {
    const code = this.otpDigits().join('');
    if (code.length !== 6) {
      this.otpError.set('Enter all 6 digits.');
      return;
    }
    this.loading.set(true);
    this.otpError.set(null);
    this.auth.verifyPasswordResetOtp(this.email, code).subscribe({
      next: () => {
        this.loading.set(false);
        this.step.set('reset');
      },
      error: () => {
        this.loading.set(false);
        this.otpError.set('Incorrect or expired OTP. Please try again.');
      },
    });
  }

  submitReset(): void {
    this.resetSubmitted.set(true);
    const { newPassword, confirmPassword } = this.resetForm.getRawValue();
    if (this.resetForm.invalid || newPassword !== confirmPassword) return;

    this.loading.set(true);
    const code = this.otpDigits().join('');
    this.auth.resetPassword(this.email, code, newPassword).subscribe({
      next: () => {
        this.loading.set(false);
        this.toast.success('Password Reset', 'You can now log in with your new password.');
        this.router.navigateByUrl('/login');
      },
      error: () => {
        this.loading.set(false);
        this.toast.error('Reset Failed', 'Something went wrong. Please try again.');
      },
    });
  }
}
