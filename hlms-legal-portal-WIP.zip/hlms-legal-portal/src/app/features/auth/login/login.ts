import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div class="auth-screen">
      <div class="auth-wrap">
        <div class="auth-brand">
          <img src="/logo.png" alt="HLMS" />
          <div>
            <div class="t1">HLMS</div>
            <div class="t2">Legal &amp; Valuation Team Portal</div>
          </div>
        </div>
        <form class="auth-form" [formGroup]="form" (ngSubmit)="submit()">
          <h2>Welcome back</h2>
          <div class="sub">Log in to manage legal review, notices and recovery cases.</div>

          <div class="field">
            <label>Email<span class="req">*</span></label>
            <input formControlName="email" placeholder="you@hlms.example.com" autocomplete="username" />
            @if (submitted() && form.controls.email.invalid) {
              <div class="error">Enter a valid email address.</div>
            }
          </div>

          <div class="field">
            <label>Password<span class="req">*</span></label>
            <div class="password-wrap">
              <input
                formControlName="password"
                [type]="showPassword() ? 'text' : 'password'"
                placeholder="Enter your password"
                autocomplete="current-password"
              />
              <span class="password-toggle" (click)="showPassword.set(!showPassword())">👁</span>
            </div>
            @if (submitted() && form.controls.password.invalid) {
              <div class="error">Password is required.</div>
            }
          </div>

          <button class="btn btn-primary btn-block" type="submit" [disabled]="loading()">
            {{ loading() ? 'Logging in…' : 'Log In' }}
          </button>

          <div class="auth-switch"><a routerLink="/forgot-password">Forgot password?</a></div>
        </form>
      </div>
    </div>
  `,
})
export class LoginComponent {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  readonly submitted = signal(false);
  readonly loading = signal(false);
  readonly showPassword = signal(false);

  readonly form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.pattern(EMAIL_RE)]],
    password: ['', Validators.required],
  });

  submit(): void {
    this.submitted.set(true);
    if (this.form.invalid) return;

    this.loading.set(true);
    const { email, password } = this.form.getRawValue();

    this.auth.login({ email, password }).subscribe({
      next: (user) => {
        this.loading.set(false);
        if (user.role !== 'legal') {
          this.toast.error('Access Denied', 'This portal is only for the Legal & Valuation Team.');
          this.auth.logout();
          return;
        }
        const redirectTo = this.route.snapshot.queryParamMap.get('redirectTo');
        this.router.navigateByUrl(redirectTo || '/dashboard');
      },
      error: () => {
        this.loading.set(false);
        this.toast.error('Login Failed', 'Incorrect email or password.');
      },
    });
  }
}
