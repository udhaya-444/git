import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { LegalNoticeService } from '../../../core/services/legal-notice.service';
import { LoanApplicationService } from '../../../core/services/loan-application.service';
import { LegalNotice } from '../../../core/models/legal.model';
import { LoanApplication } from '../../../core/models/loan-application.model';
import { InDatePipe } from '../../../shared/pipes/in-date.pipe';
import { downloadTextFile } from '../../../shared/utils/download';
import { DraftNoticeModalComponent } from '../../../shared/components/draft-notice-modal/draft-notice-modal';

@Component({
  selector: 'app-legal-notices',
  standalone: true,
  imports: [RouterLink, InDatePipe, DraftNoticeModalComponent],
  template: `
    <div class="page-head">
      <div>
        <h1>Legal Notices Log</h1>
        <p>All demand and auction notices issued, plus manual legal correspondence.</p>
      </div>
      <button class="btn btn-primary" type="button" (click)="modalOpen.set(true)">+ Draft Custom Notice</button>
    </div>

    <div class="card">
      @if (loading()) {
        <div class="empty-state"><div class="ic">⏳</div>Loading notices…</div>
      } @else if (sortedNotices().length === 0) {
        <div class="empty-state"><div class="ic">✉️</div>No notices issued yet.</div>
      } @else {
        <table>
          <thead>
            <tr>
              <th>Notice No.</th>
              <th>Type</th>
              <th>Loan A/C</th>
              <th>Borrower</th>
              <th>Issued</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @for (n of sortedNotices(); track n.noticeId) {
              <tr>
                <td>{{ n.noticeNo }}</td>
                <td>{{ n.noticeType }}</td>
                <td>
                  @if (n.appId) {
                    <a [routerLink]="['/cases', n.appId]">{{ appFor(n.appId)?.trackingNo || n.appId }}</a>
                  } @else {
                    —
                  }
                </td>
                <td>{{ (n.appId && appFor(n.appId)?.applicantName) || '—' }}</td>
                <td>{{ n.issueDate | inDate }}</td>
                <td>
                  <span class="badge" [class.badge-orange]="n.status === 'ACTIVE'" [class.badge-gray]="n.status !== 'ACTIVE'">
                    {{ n.status }}
                  </span>
                </td>
                <td style="text-align:right;">
                  <button class="btn btn-outline btn-sm" type="button" (click)="download(n)">Download</button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>

    @if (modalOpen()) {
      <app-draft-notice-modal (closed)="modalOpen.set(false)" (created)="onNoticeCreated($event)" />
    }
  `,
})
export class LegalNoticesComponent implements OnInit {
  private readonly legalNoticeService = inject(LegalNoticeService);
  private readonly loanApplicationService = inject(LoanApplicationService);

  readonly loading = signal(true);
  readonly modalOpen = signal(false);
  private readonly notices = signal<LegalNotice[]>([]);
  private readonly applications = signal<LoanApplication[]>([]);

  readonly sortedNotices = computed(() =>
    [...this.notices()].sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime())
  );

  ngOnInit(): void {
    this.loanApplicationService.listAll().subscribe((apps) => this.applications.set(apps));
    this.legalNoticeService.listAll().subscribe({
      next: (list) => {
        this.notices.set(list);
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  appFor(appId: string): LoanApplication | undefined {
    return this.applications().find((a) => a.appId === appId);
  }

  download(n: LegalNotice): void {
    downloadTextFile(n.content, `${n.noticeNo.replace(/\//g, '_')}.txt`);
  }

  onNoticeCreated(notice: LegalNotice): void {
    this.notices.update((list) => [notice, ...list]);
    this.modalOpen.set(false);
  }
}
