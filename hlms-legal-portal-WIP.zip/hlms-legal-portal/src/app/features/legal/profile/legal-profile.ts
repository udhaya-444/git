import { Component, OnInit, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LegalCaseService } from '../../../core/services/legal-case.service';
import { LegalNoticeService } from '../../../core/services/legal-notice.service';
import { ROLE_LABELS } from '../../../core/models/user.model';

const MOBILE_RE = /^[6-9]\d{9}$/;
// Matches the legacy REGEX.password: at least one lower, one upper, one digit, one symbol, 8+ chars.
const PASSWORD_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_\-+=]).{8,}$/;

@Component({
  selector: 'app-legal-profile',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <div class="page-head">
      <h1>Profile Settings</h1>
      <p>Your Legal &amp; Valuation Team account details.</p>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3>👤 Account Details</h3>
        <form [formGroup]="profileForm" (ngSubmit)="saveProfile()">
          <div class="field">
            <label>Full Name</label>
            <input formControlName="name" />
            @if (profileSubmitted() && profileForm.controls.name.invalid) {
              <div class="error">Name is required.</div>
            }
          </div>
          <div class="two-col">
            <div class="field">
              <label>Mobile</label>
              <input formControlName="mobile" />
              @if (profileSubmitted() && profileForm.controls.mobile.invalid) {
                <div class="error">Enter a valid 10-digit mobile number.</div>
              }
            </div>
            <div class="field">
              <label>Email</label>
              <input [value]="user()?.email" disabled />
            </div>
          </div>
          <div class="field">
            <label>Role</label>
            <input [value]="roleLabel()" disabled />
          </div>
          <button class="btn btn-primary" type="submit" [disabled]="savingProfile()">
            {{ savingProfile() ? 'Saving…' : 'Save Changes' }}
          </button>
        </form>
      </div>

      <div class="card">
        <h3>📊 Your Activity Summary</h3>
        <table>
          <tbody>
            <tr>
              <td>Cases Reviewed</td>
              <td style="text-align:right;">{{ casesReviewed() ?? '—' }}</td>
            </tr>
            <tr>
              <td>Notices Issued</td>
              <td style="text-align:right;">{{ noticesIssued() ?? '—' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card">
      <h3>🔒 Change Password</h3>
      <form [formGroup]="passwordForm" (ngSubmit)="changePassword()">
        <div class="field">
          <label>Current Password</label>
          <input type="password" formControlName="currentPassword" />
          @if (passwordError()) {
            <div class="error">{{ passwordError() }}</div>
          }
        </div>
        <div class="field">
          <label>New Password</label>
          <input type="password" formControlName="newPassword" />
          @if (passwordSubmitted() && passwordForm.controls.newPassword.invalid) {
            <div class="error">Password must be 8+ characters and include upper, lower, a number and a symbol.</div>
          }
        </div>
        <div class="field">
          <label>Confirm New Password</label>
          <input type="password" formControlName="confirmPassword" />
          @if (passwordSubmitted() && passwordForm.controls.confirmPassword.value !== passwordForm.controls.newPassword.value) {
            <div class="error">Passwords do not match.</div>
          }
        </div>
        <button class="btn btn-primary btn-sm" type="submit" [disabled]="savingPassword()">
          {{ savingPassword() ? 'Updating…' : 'Update Password' }}
        </button>
      </form>
    </div>
  `,
})
export class LegalProfileComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly toast = inject(ToastService);
  private readonly legalCaseService = inject(LegalCaseService);
  private readonly legalNoticeService = inject(LegalNoticeService);

  readonly user = this.auth.currentUser;
  readonly roleLabel = () => ROLE_LABELS[this.user()?.role ?? ''] ?? this.user()?.role ?? '';

  readonly casesReviewed = signal<number | null>(null);
  readonly noticesIssued = signal<number | null>(null);

  readonly profileSubmitted = signal(false);
  readonly savingProfile = signal(false);
  readonly profileForm = this.fb.nonNullable.group({
    name: ['', Validators.required],
    mobile: ['', [Validators.required, Validators.pattern(MOBILE_RE)]],
  });

  readonly passwordSubmitted = signal(false);
  readonly savingPassword = signal(false);
  readonly passwordError = signal<string | null>(null);
  readonly passwordForm = this.fb.nonNullable.group({
    currentPassword: ['', Validators.required],
    newPassword: ['', [Validators.required, Validators.pattern(PASSWORD_RE)]],
    confirmPassword: ['', Validators.required],
  });

  ngOnInit(): void {
    const u = this.user();
    if (u) {
      this.profileForm.patchValue({ name: u.name, mobile: u.mobile });
    }

    const email = u?.email;
    if (!email) return;

    this.legalCaseService
      .listAllVerifications()
      .subscribe((list) => this.casesReviewed.set(list.filter((v) => v.officerEmail === email).length));

    this.legalNoticeService
      .listAll()
      .subscribe((list) => this.noticesIssued.set(list.filter((n) => n.officerEmail === email).length));
  }

  saveProfile(): void {
    this.profileSubmitted.set(true);
    if (this.profileForm.invalid) return;

    const email = this.user()?.email;
    if (!email) return;

    this.savingProfile.set(true);
    const { name, mobile } = this.profileForm.getRawValue();
    this.auth.updateProfile(email, { name, mobile }).subscribe({
      next: () => {
        this.savingProfile.set(false);
        this.toast.success('Profile Updated', 'Your account details have been saved.');
      },
      error: () => {
        this.savingProfile.set(false);
        this.toast.error('Update Failed', 'Could not save your changes. Please try again.');
      },
    });
  }

  /**
   * The backend has no dedicated change-password endpoint that verifies the current
   * password server-side — /api/users/reset-password just overwrites it given an email.
   * To still confirm the user actually knows their current password, we re-authenticate
   * against /login with it before calling resetPassword with the new one.
   */
  changePassword(): void {
    this.passwordSubmitted.set(true);
    this.passwordError.set(null);
    const { currentPassword, newPassword, confirmPassword } = this.passwordForm.getRawValue();

    if (this.passwordForm.controls.newPassword.invalid || !currentPassword) return;
    if (newPassword !== confirmPassword) return;

    const email = this.user()?.email;
    if (!email) return;

    this.savingPassword.set(true);
    this.auth.login({ email, password: currentPassword }).subscribe({
      next: () => {
        this.auth.resetPassword(email, '', newPassword).subscribe({
          next: () => {
            this.savingPassword.set(false);
            this.passwordSubmitted.set(false);
            this.passwordForm.reset();
            this.toast.success('Password Updated', 'Your password has been changed.');
          },
          error: () => {
            this.savingPassword.set(false);
            this.toast.error('Update Failed', 'Could not change your password. Please try again.');
          },
        });
      },
      error: () => {
        this.savingPassword.set(false);
        this.passwordError.set('Current password is incorrect.');
      },
    });
  }
}
