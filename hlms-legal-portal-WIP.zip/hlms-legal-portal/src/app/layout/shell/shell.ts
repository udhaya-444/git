import { Component, OnInit, signal } from '@angular/core';
import { Router, RouterOutlet, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs';
import { TopbarComponent } from '../topbar/topbar';
import { SidebarComponent } from '../sidebar/sidebar';

/** The authenticated layout every Legal page lives inside — mirrors the legacy app's #app shell. */
@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, TopbarComponent, SidebarComponent],
  template: `
    <app-topbar (hamburgerClick)="toggleSidebar()" />
    <app-sidebar [open]="sidebarOpen()" />
    <div class="main">
      <router-outlet />
    </div>
    <footer class="app-footer">HLMS Legal &amp; Valuation Team Portal</footer>
  `,
})
export class ShellComponent implements OnInit {
  readonly sidebarOpen = signal(false);

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Mirrors go(): the mobile sidebar closes on every navigation.
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd)).subscribe(() => {
      this.sidebarOpen.set(false);
      window.scrollTo(0, 0);
    });
  }

  toggleSidebar(): void {
    this.sidebarOpen.update((v) => !v);
  }
}
