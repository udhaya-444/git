import { Component, Input, OnInit, signal, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { DocumentService } from '../../core/services/document.service';
import { LEGAL_STAGE_INDEX } from '../../core/models/loan-application.model';

interface NavItem {
  path: string;
  icon: string;
  label: string;
  badge: () => string | null;
}

/** Mirrors sidebarItemsFor('legal') + renderSidebar() from the legacy app. */
@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <div class="sidebar" [class.open]="open">
      @for (item of navItems; track item.path) {
        <a
          class="nav-item"
          [routerLink]="item.path"
          routerLinkActive="active"
          [routerLinkActiveOptions]="{ exact: false }"
        >
          <span class="ic">{{ item.icon }}</span>
          {{ item.label }}
          @if (item.badge(); as b) {
            <span class="nav-badge">{{ b }}</span>
          }
        </a>
      }
      <button
        type="button"
        class="nav-item"
        style="margin-top:14px;border-top:1px solid var(--border);padding-top:16px;color:var(--red);"
        (click)="logout()"
      >
        <span class="ic" style="color:var(--red);">⏻</span>
        Log Out
      </button>
    </div>
  `,
})
export class SidebarComponent implements OnInit {
  private readonly auth = inject(AuthService);
  private readonly loanApplicationService = inject(LoanApplicationService);
  private readonly documentService = inject(DocumentService);
  private readonly router = inject(Router);

  /** Controls the mobile slide-in state; toggled by the topbar's hamburger via the shell. */
  @Input() open = false;

  private readonly pendingQueueCount = signal<number | null>(null);
  private readonly pendingDocsCount = signal<number | null>(null);

  readonly navItems: NavItem[] = [
    { path: 'dashboard', icon: '▦', label: 'Dashboard', badge: () => null },
    {
      path: 'queue',
      icon: '☑',
      label: 'Legal Review Queue',
      badge: () => (this.pendingQueueCount() ? String(this.pendingQueueCount()) : null),
    },
    {
      path: 'documents',
      icon: '▯',
      label: 'Document Center',
      badge: () => (this.pendingDocsCount() ? String(this.pendingDocsCount()) : null),
    },
    { path: 'auction', icon: '☆', label: 'Auction & SARFAESI', badge: () => null },
    { path: 'notices', icon: '✉', label: 'Legal Notices Log', badge: () => null },
    { path: 'profile', icon: '◍', label: 'Profile Settings', badge: () => null },
  ];

  ngOnInit(): void {
    // Mirrors pendingLegalCount(): applications sitting at the Legal/mortgage-verification
    // stage that are still Under Review.
    this.loanApplicationService.listAll().subscribe((apps) => {
      const count = apps.filter((a) => a.stageIndex === LEGAL_STAGE_INDEX && a.status === 'Under Review').length;
      this.pendingQueueCount.set(count);
    });

    // Mirrors pendingPostDisbDocsCount(): post-disbursement uploads awaiting legal verification.
    this.documentService.listPostDisbursementDocuments().subscribe((docs) => {
      this.pendingDocsCount.set(docs.filter((d) => d.status === 'Pending').length);
    });
  }

  logout(): void {
    this.auth.logout();
  }
}
