import { Component, EventEmitter, OnInit, Output, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { NotificationService } from '../../core/services/notification.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { AppNotification } from '../../core/models/notification.model';
import { LoanApplication } from '../../core/models/loan-application.model';
import { InDatePipe } from '../../shared/pipes/in-date.pipe';

/** Mirrors the legacy app's .topbar: hamburger, brand, global search, notification bell, user chip. */
@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [FormsModule, InDatePipe],
  template: `
    <div class="topbar">
      <button class="hamburger" type="button" (click)="hamburgerClick.emit()">☰</button>
      <div class="brand">
        <div class="logo"><img src="/logo.png" width="34" height="34" style="border-radius:8px;" alt="HLMS" /></div>
        <div>
          <div class="title">HLMS</div>
          <div class="subtitle">Housing Loan Management System</div>
        </div>
      </div>

      <div class="topbar-search">
        <input
          placeholder="Search by application ID or tracking no..."
          autocomplete="off"
          [(ngModel)]="searchTerm"
          (focus)="searchFocused.set(true)"
          (blur)="onSearchBlur()"
        />
        @if (searchFocused() && searchTerm.length > 0) {
          <div class="search-dropdown">
            @if (searchResults().length === 0) {
              <div class="search-dropdown-empty">No matching applications</div>
            } @else {
              @for (app of searchResults(); track app.appId) {
                <div class="search-dropdown-item" (mousedown)="goToCase(app.appId)">
                  <strong>{{ app.trackingNo }}</strong> — {{ app.applicantName || app.userEmail }}
                </div>
              }
            }
          </div>
        }
      </div>

      <div class="topbar-right">
        <button class="icon-btn" type="button" title="Notifications" (click)="toggleNotifPanel()">
          🔔
          @if (unreadCount() > 0) {
            <span class="icon-dot">{{ unreadCount() }}</span>
          }
        </button>
        @if (notifPanelOpen()) {
          <div class="search-dropdown" style="right:70px; left:auto; top:56px;">
            @if (notifications().length === 0) {
              <div class="search-dropdown-empty">No notifications yet</div>
            } @else {
              @for (n of notifications(); track n.notificationId) {
                <div class="search-dropdown-item">
                  <strong>{{ n.title }}</strong><br />
                  <span style="font-size:11.5px;color:var(--text-gray);">{{ n.body }} · {{ n.createdAt | inDate }}</span>
                </div>
              }
            }
          </div>
        }

        <button class="user-chip" type="button" (click)="goToProfile()">
          <div class="user-avatar">{{ initials() }}</div>
          <div class="user-name">{{ auth.currentUser()?.name || 'User' }}</div>
        </button>
      </div>
    </div>
  `,
})
export class TopbarComponent implements OnInit {
  protected readonly auth = inject(AuthService);
  private readonly notificationService = inject(NotificationService);
  private readonly loanApplicationService = inject(LoanApplicationService);
  private readonly router = inject(Router);

  @Output() hamburgerClick = new EventEmitter<void>();

  searchTerm = '';
  readonly searchFocused = signal(false);
  private readonly allApplications = signal<LoanApplication[]>([]);

  readonly searchResults = computed(() => {
    const term = this.searchTerm.trim().toLowerCase();
    if (!term) return [];
    return this.allApplications()
      .filter(
        (a) =>
          a.trackingNo?.toLowerCase().includes(term) ||
          a.appId?.toLowerCase().includes(term) ||
          a.applicantName?.toLowerCase().includes(term)
      )
      .slice(0, 8);
  });

  readonly notifPanelOpen = signal(false);
  readonly notifications = signal<AppNotification[]>([]);
  readonly unreadCount = computed(() => this.notifications().filter((n) => !n.read).length);

  readonly initials = computed(() => {
    const name = this.auth.currentUser()?.name ?? '';
    return name
      .split(' ')
      .filter(Boolean)
      .map((s) => s[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
  });

  ngOnInit(): void {
    this.loanApplicationService.listAll().subscribe((apps) => this.allApplications.set(apps));
    this.loadNotifications();
  }

  private loadNotifications(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.notificationService.listForUser(email).subscribe((list) => this.notifications.set(list));
  }

  /** Mirrors openNotifPanel(): opening the panel marks everything read. */
  toggleNotifPanel(): void {
    const opening = !this.notifPanelOpen();
    this.notifPanelOpen.set(opening);
    if (opening) {
      const unread = this.notifications().filter((n) => !n.read && n.notificationId);
      unread.forEach((n) => this.notificationService.markRead(n.notificationId!).subscribe());
      this.notifications.update((list) => list.map((n) => ({ ...n, read: true })));
    }
  }

  onSearchBlur(): void {
    // Delay so a (mousedown) on a dropdown item fires before the dropdown unmounts.
    setTimeout(() => this.searchFocused.set(false), 150);
  }

  goToCase(appId: string): void {
    this.searchTerm = '';
    this.router.navigate(['/cases', appId]);
  }

  goToProfile(): void {
    this.router.navigate(['/profile']);
  }
}
