import { Component, EventEmitter, OnInit, Output, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { LegalNoticeService } from '../../../core/services/legal-notice.service';
import { LoanApplicationService } from '../../../core/services/loan-application.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuthService } from '../../../core/services/auth.service';
import { LegalNotice } from '../../../core/models/legal.model';
import { LoanApplication } from '../../../core/models/loan-application.model';

/**
 * legal-service requires every notice to be linked to an application and restricts
 * noticeType to a fixed set — unlike the legacy demo's free-text type and "not linked
 * to an application" option, so this form is adapted to those real constraints.
 */
const NOTICE_TYPES = [
  { value: 'DEMAND_NOTICE', label: 'Demand Notice' },
  { value: 'AUCTION_NOTICE', label: 'Auction Notice' },
  { value: 'LEGAL_NOTICE', label: 'Legal Notice' },
  { value: 'DEFAULT_NOTICE', label: 'Default Notice' },
];

@Component({
  selector: 'app-draft-notice-modal',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <div class="modal-overlay" (click)="closed.emit()">
      <div class="modal-box" (click)="$event.stopPropagation()">
        <h3>Draft Custom Legal Notice</h3>
        <form [formGroup]="form" (ngSubmit)="submit()">
          <div class="field">
            <label>Application<span class="req">*</span></label>
            <select formControlName="appId">
              <option value="" disabled>— Select an application —</option>
              @for (app of applications(); track app.appId) {
                <option [value]="app.appId">{{ app.trackingNo }} — {{ app.applicantName || app.userEmail }}</option>
              }
            </select>
            @if (submitted() && form.controls.appId.invalid) {
              <div class="error">Select the application this notice applies to.</div>
            }
          </div>
          <div class="field">
            <label>Notice Type<span class="req">*</span></label>
            <select formControlName="noticeType">
              @for (t of noticeTypes; track t.value) {
                <option [value]="t.value">{{ t.label }}</option>
              }
            </select>
          </div>
          <div class="field">
            <label>Due Date (optional)</label>
            <input type="date" formControlName="dueDate" />
            @if (submitted() && form.controls.dueDate.invalid) {
              <div class="error">Due date can't be before the issue date (today).</div>
            }
          </div>
          <div class="field">
            <label>Notice Content<span class="req">*</span></label>
            <textarea formControlName="content" rows="6" placeholder="Type the full notice text..."></textarea>
            @if (submitted() && form.controls.content.invalid) {
              <div class="error">Notice content is required.</div>
            }
          </div>
          <button class="btn btn-primary btn-block" style="margin-top:10px;" type="submit" [disabled]="saving()">
            {{ saving() ? 'Saving…' : 'Save & Log Notice' }}
          </button>
        </form>
      </div>
    </div>
  `,
})
export class DraftNoticeModalComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly legalNoticeService = inject(LegalNoticeService);
  private readonly loanApplicationService = inject(LoanApplicationService);
  private readonly notificationService = inject(NotificationService);
  private readonly toast = inject(ToastService);
  private readonly auth = inject(AuthService);

  @Output() closed = new EventEmitter<void>();
  @Output() created = new EventEmitter<LegalNotice>();

  readonly noticeTypes = NOTICE_TYPES;
  readonly applications = signal<LoanApplication[]>([]);
  readonly submitted = signal(false);
  readonly saving = signal(false);

  readonly form = this.fb.nonNullable.group({
    appId: ['', Validators.required],
    noticeType: [NOTICE_TYPES[0].value, Validators.required],
    dueDate: [''],
    content: ['', Validators.required],
  });

  ngOnInit(): void {
    this.loanApplicationService.listAll().subscribe((apps) => this.applications.set(apps));
  }

  submit(): void {
    this.submitted.set(true);
    if (this.form.invalid) return;

    const { appId, noticeType, dueDate, content } = this.form.getRawValue();
    const officerEmail = this.auth.currentUser()?.email;
    if (!officerEmail) return;

    const today = new Date().toISOString();
    if (dueDate && new Date(dueDate) < new Date(today.slice(0, 10))) {
      this.form.controls.dueDate.setErrors({ beforeIssue: true });
      return;
    }

    this.saving.set(true);
    const dto: LegalNotice = {
      appId,
      noticeType,
      issueDate: today,
      dueDate: dueDate || null,
      status: 'ACTIVE',
      officerEmail,
      content,
      noticeNo: '', // server-generated; ignored on create
    };

    this.legalNoticeService.create(dto).subscribe({
      next: (notice) => {
        this.saving.set(false);
        const app = this.applications().find((a) => a.appId === appId);
        if (app) {
          this.notificationService
            .send(
              app.userEmail,
              this.noticeTypes.find((t) => t.value === noticeType)?.label ?? noticeType,
              `A new legal communication has been issued regarding your loan account ${app.trackingNo}.`
            )
            .subscribe();
        }
        this.toast.success('Notice Logged', notice.noticeNo);
        this.created.emit(notice);
      },
      error: () => {
        this.saving.set(false);
        this.toast.error('Could Not Log Notice', 'Please check the details and try again.');
      },
    });
  }
}
