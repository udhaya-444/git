import { Component, inject } from '@angular/core';
import { ToastService } from '../../../core/services/toast.service';

/**
 * Renders the app-wide toast queue. Mirrors the legacy app's #toastWrap /
 * toast(title, msg, type) behavior — drop <app-toast-container /> once near
 * the root of the shell so it sits above all routed content.
 */
@Component({
  selector: 'app-toast-container',
  standalone: true,
  template: `
    <div class="toast-wrap">
      @for (t of toastService.toasts(); track t.id) {
        <div class="toast" [class]="t.kind">
          <button type="button" class="close-x" (click)="toastService.dismiss(t.id)" aria-label="Dismiss">✕</button>
          <strong>{{ t.title }}</strong>
          @if (t.message) {
            <span>{{ t.message }}</span>
          }
        </div>
      }
    </div>
  `,
})
export class ToastContainerComponent {
  protected readonly toastService = inject(ToastService);
}
