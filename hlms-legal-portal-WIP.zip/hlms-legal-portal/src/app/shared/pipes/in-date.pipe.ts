import { Pipe, PipeTransform } from '@angular/core';

/** Mirrors the legacy app's fmtDate(d): e.g. "07 Aug 2026". Returns '—' for null/invalid dates. */
@Pipe({ name: 'inDate', standalone: true })
export class InDatePipe implements PipeTransform {
  transform(value: string | number | Date | null | undefined): string {
    if (value === null || value === undefined || value === '') return '—';
    const dt = new Date(value);
    if (isNaN(dt.getTime())) return '—';
    return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  }
}
