import { Pipe, PipeTransform } from '@angular/core';

/** Mirrors the legacy app's fmtINR(n): rounds to the nearest rupee, en-IN digit grouping, ₹ prefix. */
@Pipe({ name: 'inrCurrency', standalone: true })
export class InrCurrencyPipe implements PipeTransform {
  transform(value: number | string | null | undefined): string {
    const n = Math.round(Number(value) || 0);
    return '₹' + n.toLocaleString('en-IN');
  }
}
