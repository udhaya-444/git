/**
 * Client-side-only text file export — mirrors the legacy app's downloadTextFile().
 * No backend endpoint involved; used for placeholder document "downloads",
 * disbursement-letter style generated text, and legal notice content export.
 */
export function downloadTextFile(content: string, filename: string): void {
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/** Same idea, but produces a safe filename from a document/notice name (spaces -> underscores). */
export function downloadPlaceholderDoc(name: string): void {
  const generatedOn = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  const content = `This is a system-generated placeholder document: ${name}\nGenerated on ${generatedOn}`;
  downloadTextFile(content, `${name.replace(/\s+/g, '_')}.txt`);
}
