/**
 * Every HLMS microservice is reached through the API Gateway (api-gateway,
 * port 8080), which routes /<service-name>/** -> that service with the
 * service-name prefix stripped (see api-gateway/application.properties).
 *
 * e.g. GET  http://localhost:8080/legal-service/api/legal-notices
 *      POST http://localhost:8080/user-service/api/users/login
 */
export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8080',
};
