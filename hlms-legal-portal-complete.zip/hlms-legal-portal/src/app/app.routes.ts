import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { legalRoleGuard } from './core/guards/legal-role.guard';

/**
 * All routes below are wired to real, implemented components: auth screens,
 * the Shell/topbar/sidebar layout, and every Legal feature screen
 * (dashboard, queue, case-detail, documents, auction, notices, profile).
 */
export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login/login').then((m) => m.LoginComponent),
  },
  {
    path: 'forgot-password',
    loadComponent: () =>
      import('./features/auth/forgot-password/forgot-password').then((m) => m.ForgotPasswordComponent),
  },
  {
    path: '',
    loadComponent: () => import('./layout/shell/shell').then((m) => m.ShellComponent),
    canActivate: [authGuard, legalRoleGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./features/legal/dashboard/legal-dashboard').then((m) => m.LegalDashboardComponent),
      },
      {
        path: 'queue',
        loadComponent: () => import('./features/legal/queue/legal-queue').then((m) => m.LegalQueueComponent),
      },
      {
        path: 'cases/:appId',
        loadComponent: () =>
          import('./features/legal/case-detail/legal-case-detail').then((m) => m.LegalCaseDetailComponent),
      },
      {
        path: 'documents',
        loadComponent: () =>
          import('./features/legal/documents/legal-documents').then((m) => m.LegalDocumentsComponent),
      },
      {
        path: 'auction',
        loadComponent: () => import('./features/legal/auction/legal-auction').then((m) => m.LegalAuctionComponent),
      },
      {
        path: 'notices',
        loadComponent: () => import('./features/legal/notices/legal-notices').then((m) => m.LegalNoticesComponent),
      },
      {
        path: 'profile',
        loadComponent: () => import('./features/legal/profile/legal-profile').then((m) => m.LegalProfileComponent),
      },
    ],
  },
  { path: '**', redirectTo: 'login' },
];
