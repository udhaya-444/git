/** AuctionCaseDTO — SARFAESI recovery stage for one loan application. */
export type AuctionStage = 'None' | 'Notice Issued' | 'Possession' | 'Auction Scheduled' | 'Resolved';

export interface AuctionCase {
  auctionId?: number;
  appId: string;
  stage: AuctionStage;
  noticeDate?: string | null;
  noticeDueDate?: string | null;
  demandAmount?: number | null;
  possessionDate?: string | null;
  auctionDate?: string | null;
  reservePrice?: number | null;
}

export function emptyAuctionCase(appId: string): AuctionCase {
  return { appId, stage: 'None' };
}

/** AuctionNoteDTO — free-text recovery notes/log entries. */
export interface AuctionNote {
  noteId?: string;
  appId: string;
  noteDate?: string;
  noteText: string;
}

/** BidDTO — bidder activity on a listed property. */
export interface Bid {
  bidId?: string;
  appId: string;
  bidderEmail: string;
  bidAmount: number;
  createdAt?: string;
}

/** EmiInstallmentDTO — used to derive outstanding balance / overdue count. */
export interface EmiInstallment {
  installmentId?: string;
  appId: string;
  installmentNo: number;
  dueDate: string;
  emiAmount: number;
  principalComponent: number;
  interestComponent: number;
  closingBalance: number;
  status: 'PENDING' | 'PAID' | 'OVERDUE' | string;
  paidDate?: string | null;
}

/**
 * Mirrors the legacy app's render-time recomputation in overdueLegalApplications():
 * an installment counts as overdue if it's unpaid and past its due date, even if the
 * stored status hasn't been flipped to OVERDUE yet by a backend job.
 */
export function isOverdueInstallment(i: EmiInstallment): boolean {
  if (i.status === 'PAID') return false;
  if (i.status === 'OVERDUE') return true;
  return new Date(i.dueDate) < new Date();
}

export function auctionBadgeClass(stage: string): string {
  if (stage === 'None') return 'badge-gray';
  if (stage === 'Notice Issued') return 'badge-orange';
  if (stage === 'Possession') return 'badge-red';
  if (stage === 'Auction Scheduled') return 'badge-red';
  if (stage === 'Resolved') return 'badge-green';
  return 'badge-gray';
}
