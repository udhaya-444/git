import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApplicationDocument, PostDisbursementDocument } from '../models/document.model';

/** Wraps document-service's two collections that Legal's Document Center works across. */
@Injectable({ providedIn: 'root' })
export class DocumentService {
  private readonly appDocsUrl = `${environment.apiBaseUrl}/document-service/api/application-documents`;
  private readonly postDisbUrl = `${environment.apiBaseUrl}/document-service/api/post-disbursement-documents`;

  constructor(private http: HttpClient) {}

  // ---- Original application documents ----

  listApplicationDocuments(): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(this.appDocsUrl);
  }

  getApplicationDocumentsForApp(appId: string): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(`${this.appDocsUrl}/app/${encodeURIComponent(appId)}`);
  }

  /** saveDocument on the backend upserts — pass the full entity (with documentId) to update verification status. */
  saveApplicationDocument(doc: ApplicationDocument): Observable<ApplicationDocument> {
    return this.http.post<ApplicationDocument>(this.appDocsUrl, doc);
  }

  /**
   * Mirrors the legacy app's bankOfficeVerified(): an application's mortgage/property
   * case can only be opened for Legal review once Bank Office has verified every
   * document uploaded with the original application. No uploads at all -> locked.
   */
  isBankOfficeVerified(appId: string): Observable<boolean> {
    return this.getApplicationDocumentsForApp(appId).pipe(
      map((docs) => docs.length > 0 && docs.every((d) => d.verificationStatus === 'Verified'))
    );
  }

  // ---- Post-disbursement documents ----

  listPostDisbursementDocuments(): Observable<PostDisbursementDocument[]> {
    return this.http.get<PostDisbursementDocument[]>(this.postDisbUrl);
  }

  getPostDisbursementDocumentsForApp(appId: string): Observable<PostDisbursementDocument[]> {
    return this.http.get<PostDisbursementDocument[]>(`${this.postDisbUrl}/app/${encodeURIComponent(appId)}`);
  }

  savePostDisbursementDocument(doc: PostDisbursementDocument): Observable<PostDisbursementDocument> {
    return this.http.post<PostDisbursementDocument>(this.postDisbUrl, doc);
  }
}
