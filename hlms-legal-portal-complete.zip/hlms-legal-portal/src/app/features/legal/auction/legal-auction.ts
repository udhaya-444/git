import { Component, OnInit, inject, signal } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { LoanApplicationService } from '../../../core/services/loan-application.service';
import { AuctionService } from '../../../core/services/auction.service';
import { LegalNoticeService } from '../../../core/services/legal-notice.service';
import { DefaultManagementService } from '../../../core/services/default-management.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuthService } from '../../../core/services/auth.service';
import { LoanApplication } from '../../../core/models/loan-application.model';
import { AuctionCase, Bid, auctionBadgeClass, emptyAuctionCase, isOverdueInstallment } from '../../../core/models/auction.model';
import { InrCurrencyPipe } from '../../../shared/pipes/inr-currency.pipe';
import { InDatePipe } from '../../../shared/pipes/in-date.pipe';
import { ScheduleAuctionModalComponent } from '../../../shared/components/schedule-auction-modal/schedule-auction-modal';

interface AuctionRow {
  app: LoanApplication;
  auctionCase: AuctionCase;
  overdueCount: number;
  overdueAmount: number;
}

/** Mirrors the legacy app's viewLegalAuction() / renderLegalAuctionCard(). */
@Component({
  selector: 'app-legal-auction',
  standalone: true,
  imports: [InrCurrencyPipe, InDatePipe, ScheduleAuctionModalComponent],
  template: `
    <div class="page-head">
      <div>
        <h1>Auction &amp; SARFAESI Management</h1>
        <p>Manage recovery proceedings for seriously overdue, secured loan accounts.</p>
      </div>
    </div>

    <div class="card" style="background:var(--purple-bg);box-shadow:none;">
      <p style="margin:0;font-size:13px;color:var(--text-mid);">
        Under the SARFAESI Act, a Demand Notice under Section 13(2) gives the borrower 60 days to repay before
        further recovery action (symbolic possession, e-auction) may proceed.
      </p>
    </div>

    @if (loading()) {
      <div class="card"><div class="empty-state"><div class="ic">⏳</div>Loading accounts…</div></div>
    } @else if (rows().length === 0) {
      <div class="card">
        <div class="empty-state">
          <div class="ic">✅</div>
          No accounts currently overdue enough to require recovery action.
        </div>
      </div>
    } @else {
      @for (row of rows(); track row.app.appId) {
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
            <div>
              <h3 style="margin-bottom:6px;">{{ row.app.trackingNo }} — {{ row.app.applicantName || '—' }}</h3>
              <div style="font-size:12.5px;color:var(--text-mid);">{{ row.app.propertyAddress || '—' }}</div>
            </div>
            <span class="badge {{ auctionBadgeClass(row.auctionCase.stage) }}">{{ row.auctionCase.stage }}</span>
          </div>
          <table style="margin-top:14px;">
            <tbody>
              <tr>
                <td>Overdue Installments</td>
                <td style="text-align:right;">{{ row.overdueCount }}</td>
              </tr>
              <tr>
                <td>Overdue Amount</td>
                <td style="text-align:right;">{{ row.overdueAmount | inrCurrency }}</td>
              </tr>
              <tr>
                <td>Property Value</td>
                <td style="text-align:right;">{{ row.app.propertyValue | inrCurrency }}</td>
              </tr>
              @if (row.auctionCase.noticeDate) {
                <tr>
                  <td>Demand Notice Issued</td>
                  <td style="text-align:right;">
                    {{ row.auctionCase.noticeDate | inDate }}
                    @if (row.auctionCase.noticeDueDate) {
                      <span
                        class="countdown-pill"
                        [class.overdue]="daysRemaining(row.auctionCase.noticeDueDate) < 0"
                      >
                        {{
                          daysRemaining(row.auctionCase.noticeDueDate) < 0
                            ? abs(daysRemaining(row.auctionCase.noticeDueDate)) + ' days past notice period'
                            : daysRemaining(row.auctionCase.noticeDueDate) + ' days remaining in notice period'
                        }}
                      </span>
                    }
                  </td>
                </tr>
              }
              @if (row.auctionCase.auctionDate) {
                <tr>
                  <td>e-Auction Scheduled</td>
                  <td style="text-align:right;">
                    {{ row.auctionCase.auctionDate | inDate }} · Reserve
                    {{ row.auctionCase.reservePrice | inrCurrency }}
                  </td>
                </tr>
              }
              @if (row.auctionCase.stage === 'Auction Scheduled') {
                <tr>
                  <td>Bidder Activity</td>
                  <td style="text-align:right;">
                    {{ (bidsByApp().get(row.app.appId) ?? []).length }} bid(s)
                    @if (highestBid(row.app.appId); as hb) {
                      · Highest {{ hb.bidAmount | inrCurrency }}
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
          <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px;">
            @if (row.auctionCase.stage === 'None') {
              <button class="btn btn-danger btn-sm" type="button" [disabled]="busy() === row.app.appId" (click)="issueDemandNotice(row)">
                Issue Demand Notice (Sec 13(2))
              </button>
            }
            @if (row.auctionCase.stage === 'Notice Issued') {
              <button class="btn btn-danger btn-sm" type="button" [disabled]="busy() === row.app.appId" (click)="takePossession(row)">
                Record Symbolic Possession
              </button>
            }
            @if (row.auctionCase.stage === 'Possession') {
              <button class="btn btn-danger btn-sm" type="button" (click)="scheduleTarget.set(row)">
                Post for e-Auction
              </button>
            }
            @if (row.auctionCase.stage !== 'None' && row.auctionCase.stage !== 'Resolved') {
              <button class="btn btn-outline btn-sm" type="button" [disabled]="busy() === row.app.appId" (click)="resolve(row)">
                Mark Resolved / Withdraw
              </button>
            }
          </div>
        </div>
      }
    }

    @if (scheduleTarget(); as target) {
      <app-schedule-auction-modal
        [app]="target.app"
        [auctionCase]="target.auctionCase"
        (closed)="scheduleTarget.set(null)"
        (scheduled)="onScheduled(target, $event)"
      />
    }
  `,
})
export class LegalAuctionComponent implements OnInit {
  private readonly loanApplicationService = inject(LoanApplicationService);
  private readonly auctionService = inject(AuctionService);
  private readonly legalNoticeService = inject(LegalNoticeService);
  private readonly defaultManagementService = inject(DefaultManagementService);
  private readonly notificationService = inject(NotificationService);
  private readonly toast = inject(ToastService);
  private readonly auth = inject(AuthService);

  readonly loading = signal(true);
  readonly rows = signal<AuctionRow[]>([]);
  readonly scheduleTarget = signal<AuctionRow | null>(null);
  /** appId currently mid-action, to disable its buttons and avoid double-submits. */
  readonly busy = signal<string | null>(null);

  readonly bidsByApp = signal<Map<string, Bid[]>>(new Map());
  readonly auctionBadgeClass = auctionBadgeClass;
  readonly abs = Math.abs;

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.loading.set(true);
    this.defaultManagementService
      .detectOverdueLoans()
      .pipe(catchError(() => of([] as string[])))
      .subscribe((overdueIds) => {
        if (overdueIds.length === 0) {
          this.rows.set([]);
          this.loading.set(false);
          return;
        }

        forkJoin({
          apps: this.loanApplicationService.listAll(),
          auctionCases: this.auctionService.listAll(),
        }).subscribe(({ apps, auctionCases }) => {
          const overdueApps = apps.filter((a) => overdueIds.includes(a.appId));

          forkJoin(
            overdueApps.map((app) =>
              this.auctionService.getSchedule(app.appId).pipe(
                map((schedule) => {
                  const overdue = schedule.filter(isOverdueInstallment);
                  return {
                    app,
                    overdueCount: overdue.length,
                    overdueAmount: overdue.reduce((sum, i) => sum + i.emiAmount, 0),
                  };
                }),
                catchError(() => of({ app, overdueCount: 0, overdueAmount: 0 }))
              )
            )
          ).subscribe((results) => {
            const rows: AuctionRow[] = results
              .filter((r) => r.overdueCount > 0)
              .map((r) => ({
                app: r.app,
                overdueCount: r.overdueCount,
                overdueAmount: r.overdueAmount,
                auctionCase: auctionCases.find((a) => a.appId === r.app.appId) ?? emptyAuctionCase(r.app.appId),
              }));
            this.rows.set(rows);
            this.loading.set(false);
            this.loadBids(rows.filter((r) => r.auctionCase.stage === 'Auction Scheduled'));
          });
        });
      });
  }

  private loadBids(scheduled: AuctionRow[]): void {
    if (scheduled.length === 0) return;
    forkJoin(
      scheduled.map((r) =>
        this.auctionService.getBids(r.app.appId).pipe(
          map((bids) => ({ appId: r.app.appId, bids })),
          catchError(() => of({ appId: r.app.appId, bids: [] as Bid[] }))
        )
      )
    ).subscribe((results) => {
      const map = new Map(this.bidsByApp());
      results.forEach((r) => map.set(r.appId, r.bids));
      this.bidsByApp.set(map);
    });
  }

  highestBid(appId: string): Bid | undefined {
    const bids = this.bidsByApp().get(appId) ?? [];
    return [...bids].sort((a, b) => b.bidAmount - a.bidAmount)[0];
  }

  daysRemaining(dueDate: string): number {
    return Math.ceil((new Date(dueDate).getTime() - Date.now()) / 86400000);
  }

  private updateRow(appId: string, patch: Partial<AuctionRow>): void {
    this.rows.update((list) => list.map((r) => (r.app.appId === appId ? { ...r, ...patch } : r)));
  }

  private saveAuctionCase(row: AuctionRow, dto: AuctionCase) {
    return row.auctionCase.auctionId
      ? this.auctionService.update(row.auctionCase.auctionId, dto)
      : this.auctionService.create(dto);
  }

  issueDemandNotice(row: AuctionRow): void {
    const app = row.app;
    const officerEmail = this.auth.currentUser()?.email ?? '';
    const noticeDueDate = new Date();
    noticeDueDate.setDate(noticeDueDate.getDate() + 60);

    const dto: AuctionCase = {
      ...row.auctionCase,
      appId: app.appId,
      stage: 'Notice Issued',
      noticeDate: new Date().toISOString(),
      noticeDueDate: noticeDueDate.toISOString(),
      demandAmount: row.overdueAmount,
    };

    this.busy.set(app.appId);
    this.saveAuctionCase(row, dto).subscribe({
      next: (saved) => {
        this.updateRow(app.appId, { auctionCase: saved });
        this.busy.set(null);

        this.legalNoticeService
          .create({
            appId: app.appId,
            noticeType: 'DEMAND_NOTICE',
            issueDate: new Date().toISOString(),
            dueDate: saved.noticeDueDate,
            status: 'ACTIVE',
            officerEmail,
            noticeNo: '',
            content:
              `HOUSING LOAN MANAGEMENT SYSTEM\nLEGAL & VALUATION TEAM\n\n` +
              `DEMAND NOTICE UNDER SECTION 13(2) OF THE SARFAESI ACT, 2002\n\n` +
              `Date: ${new Date().toLocaleDateString('en-IN')}\nLoan Account No.: ${app.trackingNo}\n\n` +
              `To,\n${app.applicantName}\n${app.propertyAddress}\n\n` +
              `Dear Sir/Madam,\n\nYour loan account has become classified as a Non-Performing Asset due to non-payment of dues. ` +
              `You are hereby called upon to repay the outstanding amount of \u20B9${row.overdueAmount.toLocaleString('en-IN')} ` +
              `within 60 days of this notice, failing which the Bank may exercise its rights under Section 13(4) of the ` +
              `SARFAESI Act, 2002, including taking possession of the secured asset described below and its sale by e-auction, ` +
              `without further reference to you.\n\nSecured Asset: ${app.propertyAddress}\n\n` +
              `This is a system-generated legal notice for demonstration purposes.\n\nFor HLMS Bank\nLegal & Valuation Team\n${officerEmail}`,
          })
          .subscribe();

        this.notificationService
          .send(
            app.userEmail,
            'Legal Notice Issued',
            `A Demand Notice under Section 13(2) of the SARFAESI Act has been issued on your loan account ${app.trackingNo}. Please clear outstanding dues within 60 days.`
          )
          .subscribe();

        // TODO(role-broadcast): see schedule-auction-modal.ts — legacy also notifies every
        // 'bankoffice' user here; no way to enumerate that audience from the frontend yet.

        this.toast.success('Demand Notice Issued', app.trackingNo);
      },
      error: () => {
        this.busy.set(null);
        this.toast.error('Could Not Issue Notice', 'Please try again.');
      },
    });
  }

  takePossession(row: AuctionRow): void {
    const app = row.app;
    const dto: AuctionCase = { ...row.auctionCase, appId: app.appId, stage: 'Possession', possessionDate: new Date().toISOString() };

    this.busy.set(app.appId);
    this.saveAuctionCase(row, dto).subscribe({
      next: (saved) => {
        this.updateRow(app.appId, { auctionCase: saved });
        this.busy.set(null);

        this.auctionService
          .addNote(app.appId, 'Symbolic possession of secured asset recorded under Section 13(4).')
          .subscribe();

        this.notificationService
          .send(
            app.userEmail,
            'Possession Notice',
            `Symbolic possession of the secured property under loan account ${app.trackingNo} has been recorded.`
          )
          .subscribe();

        // TODO(role-broadcast): legacy notifies the *other* recovery team (bankoffice<->legal)
        // that the property is now eligible for e-auction listing — same missing-endpoint gap.

        this.toast.success('Possession Recorded', app.trackingNo);
      },
      error: () => {
        this.busy.set(null);
        this.toast.error('Could Not Record Possession', 'Please try again.');
      },
    });
  }

  resolve(row: AuctionRow): void {
    const app = row.app;
    const dto: AuctionCase = { ...row.auctionCase, appId: app.appId, stage: 'Resolved' };

    this.busy.set(app.appId);
    this.saveAuctionCase(row, dto).subscribe({
      next: (saved) => {
        this.updateRow(app.appId, { auctionCase: saved });
        this.busy.set(null);

        this.auctionService.addNote(app.appId, 'Recovery proceedings resolved / withdrawn.').subscribe();

        this.notificationService
          .send(app.userEmail, 'Recovery Proceedings Resolved', `Recovery proceedings on your loan account ${app.trackingNo} have been resolved.`)
          .subscribe();

        this.toast.success('Marked Resolved', app.trackingNo);
      },
      error: () => {
        this.busy.set(null);
        this.toast.error('Could Not Resolve', 'Please try again.');
      },
    });
  }

  onScheduled(row: AuctionRow, saved: AuctionCase): void {
    this.updateRow(row.app.appId, { auctionCase: saved });
    this.scheduleTarget.set(null);
    // TODO(role-broadcast): legacy also notifies bankoffice/legal colleagues and every 'bidder'
    // ("New Property Listed for e-Auction") — same missing-endpoint gap noted in the modal.
  }
}
