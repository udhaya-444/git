import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { LoanApplicationService } from '../../../core/services/loan-application.service';
import { DocumentService } from '../../../core/services/document.service';
import { LegalCaseService } from '../../../core/services/legal-case.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuthService } from '../../../core/services/auth.service';
import { LoanApplication, LEGAL_STAGE_INDEX } from '../../../core/models/loan-application.model';
import { ApplicationDocument, docBadgeClass } from '../../../core/models/document.model';
import {
  LegalVerification,
  LegalChecklistItem,
  LEGAL_CHECKLIST,
  BankOfficeDecision,
  decisionBadgeClass,
} from '../../../core/models/legal.model';
import { InrCurrencyPipe } from '../../../shared/pipes/inr-currency.pipe';
import { InDatePipe } from '../../../shared/pipes/in-date.pipe';
import { downloadPlaceholderDoc } from '../../../shared/utils/download';

type ChecklistStatus = 'Pending' | 'Verified' | 'Discrepancy';
type Decision = 'Approved' | 'Rejected' | 'Query Raised';

/** Mirrors the legacy app's viewLegalCaseDetail() + its setChecklistStatus/saveLegalRemarks/decideLegalCase. */
@Component({
  selector: 'app-legal-case-detail',
  standalone: true,
  imports: [RouterLink, InrCurrencyPipe, InDatePipe],
  template: `
    @if (loading()) {
      <div class="empty-state"><div class="ic">⏳</div>Loading case…</div>
    } @else if (notFound()) {
      <div class="empty-state"><div class="ic">⚠️</div>Case not found.</div>
      <button class="btn btn-outline btn-sm" type="button" routerLink="/queue">Back to Queue</button>
    } @else if (app(); as a) {
      <div class="back-link" routerLink="/queue">← Back to Legal Review Queue</div>
      <div class="page-head">
        <div>
          <h1>{{ a.trackingNo }}</h1>
          <p>{{ a.purpose || 'Loan Application' }} · {{ a.applicantName || '—' }}</p>
        </div>
        <span class="badge {{ decisionBadgeClass(verification()?.decision) }}">
          {{ verification()?.decision || 'Awaiting Review' }}
        </span>
      </div>

      <div class="grid grid-2">
        <div class="card">
          <h3>👤 Applicant &amp; Loan Details</h3>
          <table>
            <tbody>
              <tr><td>Applicant Name</td><td style="text-align:right;">{{ a.applicantName || '—' }}</td></tr>
              <tr><td>Mobile</td><td style="text-align:right;">{{ a.applicantMobile || '—' }}</td></tr>
              <tr><td>Loan Purpose</td><td style="text-align:right;">{{ a.purpose || '—' }}</td></tr>
              <tr><td>Loan Amount</td><td style="text-align:right;">{{ a.loanAmount | inrCurrency }}</td></tr>
              <tr><td>Tenure</td><td style="text-align:right;">{{ a.tenureYears }} years</td></tr>
              <tr><td>Employment</td><td style="text-align:right;">{{ a.employmentType || '—' }}</td></tr>
            </tbody>
          </table>
        </div>
        <div class="card">
          <h3>⌂ Property Details</h3>
          <table>
            <tbody>
              <tr><td>Address</td><td style="text-align:right;">{{ a.propertyAddress || '—' }}</td></tr>
              <tr><td>Property Type</td><td style="text-align:right;">{{ a.propertyType || '—' }}</td></tr>
              <tr><td>Declared Value</td><td style="text-align:right;">{{ a.propertyValue | inrCurrency }}</td></tr>
              <tr>
                <td>Loan-to-Value (LTV)</td>
                <td style="text-align:right;">{{ ltv() !== null ? ltv() + '%' : '—' }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="card">
        <h3>🏦 Bank Office Reference</h3>
        @if (bankOfficeDecision(); as bo) {
          <table>
            <tbody>
              <tr><td>Status</td><td style="text-align:right;">{{ bo.status }}</td></tr>
              <tr><td>Officer</td><td style="text-align:right;">{{ bo.officerEmail || '—' }}</td></tr>
              <tr><td>Date</td><td style="text-align:right;">{{ bo.decisionDate | inDate }}</td></tr>
              @if (bo.reason) {
                <tr><td>Reason</td><td style="text-align:right;">{{ bo.reason }}</td></tr>
              }
              @if (bo.remarks) {
                <tr><td>Remarks</td><td style="text-align:right;">{{ bo.remarks }}</td></tr>
              }
            </tbody>
          </table>
        } @else {
          <div class="empty-state"><div class="ic">📭</div>No Bank Office decision recorded yet.</div>
        }
        @if (!bankOfficeVerified()) {
          <p style="font-size:12.5px;color:var(--orange);margin:12px 0 0;font-weight:600;">
            ⚠ Not every submitted document has been verified by Bank Office yet.
          </p>
        }
      </div>

      <div class="card">
        <h3>📄 Submitted Documents</h3>
        @if (docs().length === 0) {
          <div class="empty-state"><div class="ic">📭</div>No documents uploaded yet.</div>
        } @else {
          @for (d of docs(); track d.documentId) {
            <div class="doc-row">
              <div>
                <div class="name">{{ d.fileName }} <span class="badge {{ docBadgeClass(d.verificationStatus) }}" style="margin-left:6px;">{{ d.verificationStatus }}</span></div>
                <div class="meta">{{ d.docType }} · Uploaded {{ d.uploadedAt | inDate }}</div>
              </div>
              <div class="actions">
                <button class="btn btn-outline btn-sm" type="button" (click)="view(d.fileName)">View</button>
              </div>
            </div>
          }
        }
      </div>

      <div class="card">
        <h3>⚖️ Legal &amp; Title Verification Checklist</h3>
        @for (c of checklist; track c.key) {
          <div class="checklist-row">
            <div class="cl-name">{{ c.label }}</div>
            <select
              class="cl-{{ statusFor(c.key) }}"
              [value]="statusFor(c.key)"
              (change)="setChecklistStatus(c.key, $any($event.target).value)"
            >
              <option value="Pending">Pending</option>
              <option value="Verified">Verified</option>
              <option value="Discrepancy">Discrepancy Found</option>
            </select>
          </div>
        }
        <div class="field" style="margin-top:14px;">
          <label>Legal Remarks / Notes</label>
          <textarea
            rows="3"
            placeholder="Add any observations, discrepancies or conditions for approval..."
            [value]="remarksDraft()"
            (input)="remarksDraft.set($any($event.target).value)"
          ></textarea>
        </div>
        <button class="btn btn-outline btn-sm" type="button" [disabled]="savingRemarks()" (click)="saveRemarks()">
          {{ savingRemarks() ? 'Saving…' : 'Save Remarks' }}
        </button>
      </div>

      <div
        class="card"
        [style.background]="allVerified() ? 'var(--green-bg)' : anyDiscrepancy() ? 'var(--red-bg)' : ''"
        style="box-shadow:none;"
      >
        @if (allVerified()) {
          <b style="color:var(--green);font-size:13.5px;">
            ✓ All checklist items verified. This case is ready to be forwarded for final approval.
          </b>
        } @else if (anyDiscrepancy()) {
          <b style="color:var(--red);font-size:13.5px;">
            ⚠ Discrepancy found in one or more documents. Consider raising a query or rejecting.
          </b>
        } @else {
          <b style="color:var(--text-mid);font-size:13.5px;">Complete the checklist above before making a decision.</b>
        }
      </div>

      <div class="card">
        <h3>✅ Decision</h3>
        <div style="display:flex;gap:12px;flex-wrap:wrap;">
          <button
            class="btn btn-primary"
            type="button"
            [disabled]="!!verification()?.decision || !!decisionSaving()"
            (click)="decide('Approved')"
          >
            Approve &amp; Forward to Final Approval
          </button>
          <button
            class="btn btn-outline"
            type="button"
            [disabled]="!!verification()?.decision || !!decisionSaving()"
            (click)="decide('Query Raised')"
          >
            Raise Query to Applicant
          </button>
          <button
            class="btn btn-danger"
            type="button"
            [disabled]="!!verification()?.decision || !!decisionSaving()"
            (click)="decide('Rejected')"
          >
            Reject Application
          </button>
        </div>
        @if (verification()?.decision) {
          <p style="font-size:12.5px;color:var(--text-gray);margin:12px 0 0;">
            Decision recorded by {{ verification()?.officerEmail || '' }} on {{ verification()?.decisionDate | inDate }}.
          </p>
        }
      </div>
    }
  `,
})
export class LegalCaseDetailComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly loanApplicationService = inject(LoanApplicationService);
  private readonly documentService = inject(DocumentService);
  private readonly legalCaseService = inject(LegalCaseService);
  private readonly notificationService = inject(NotificationService);
  private readonly toast = inject(ToastService);
  private readonly auth = inject(AuthService);

  readonly checklist = LEGAL_CHECKLIST;
  readonly decisionBadgeClass = decisionBadgeClass;
  readonly docBadgeClass = docBadgeClass;

  readonly loading = signal(true);
  readonly notFound = signal(false);
  private appIdValue = '';

  readonly app = signal<LoanApplication | null>(null);
  readonly docs = signal<ApplicationDocument[]>([]);
  readonly checklistItems = signal<LegalChecklistItem[]>([]);
  readonly verification = signal<LegalVerification | null>(null);
  readonly bankOfficeDecision = signal<BankOfficeDecision | null>(null);

  readonly remarksDraft = signal('');
  readonly savingRemarks = signal(false);
  readonly decisionSaving = signal<Decision | null>(null);

  readonly bankOfficeVerified = computed(() => {
    const docs = this.docs();
    return docs.length > 0 && docs.every((d) => d.verificationStatus === 'Verified');
  });

  readonly allVerified = computed(() => this.checklist.every((c) => this.statusFor(c.key) === 'Verified'));
  readonly anyDiscrepancy = computed(() => this.checklist.some((c) => this.statusFor(c.key) === 'Discrepancy'));

  readonly ltv = computed(() => {
    const a = this.app();
    if (!a || !a.propertyValue) return null;
    return Math.round((a.loanAmount / a.propertyValue) * 100);
  });

  ngOnInit(): void {
    const appId = this.route.snapshot.paramMap.get('appId');
    if (!appId) {
      this.notFound.set(true);
      this.loading.set(false);
      return;
    }
    this.appIdValue = appId;
    this.load(appId);
  }

  private load(appId: string): void {
    this.loading.set(true);
    forkJoin({
      app: this.loanApplicationService.get(appId).pipe(catchError(() => of(null))),
      docs: this.documentService.getApplicationDocumentsForApp(appId).pipe(catchError(() => of([] as ApplicationDocument[]))),
      allChecklist: this.legalCaseService.listChecklistItems().pipe(catchError(() => of([] as LegalChecklistItem[]))),
      verification: this.legalCaseService.getVerificationByApp(appId).pipe(catchError(() => of(null))),
      bankOfficeDecision: this.legalCaseService.getBankOfficeDecisionByApp(appId).pipe(catchError(() => of(null))),
    }).subscribe(({ app, docs, allChecklist, verification, bankOfficeDecision }) => {
      if (!app) {
        this.notFound.set(true);
        this.loading.set(false);
        return;
      }
      this.app.set(app);
      this.docs.set(docs);
      this.checklistItems.set(allChecklist.filter((c) => c.appId === appId));
      this.verification.set(verification);
      this.bankOfficeDecision.set(bankOfficeDecision);
      this.remarksDraft.set(verification?.remarks ?? '');
      this.loading.set(false);
    });
  }

  statusFor(key: string): ChecklistStatus {
    return (this.itemFor(key)?.status as ChecklistStatus | undefined) ?? 'Pending';
  }

  itemFor(key: string): LegalChecklistItem | undefined {
    return this.checklistItems().find((c) => c.checklistKey === key);
  }

  setChecklistStatus(key: string, value: string): void {
    const existing = this.itemFor(key);
    const save$ = existing?.checklistItemId
      ? this.legalCaseService.updateChecklistItem(existing.checklistItemId, {
          ...existing,
          status: value as ChecklistStatus,
        })
      : this.legalCaseService.createChecklistItem({
          appId: this.appIdValue,
          checklistKey: key,
          status: value as ChecklistStatus,
        });

    save$.subscribe({
      next: (saved) => {
        this.checklistItems.update((list) => {
          const idx = list.findIndex((c) => c.checklistKey === key);
          if (idx === -1) return [...list, saved];
          const copy = [...list];
          copy[idx] = saved;
          return copy;
        });
      },
      error: () => this.toast.error('Could Not Save', 'Please try again.'),
    });
  }

  saveRemarks(): void {
    const remarks = this.remarksDraft().trim();
    const existing = this.verification();
    const officerEmail = this.auth.currentUser()?.email;

    const dto: LegalVerification = existing
      ? { ...existing, remarks }
      : { appId: this.appIdValue, decision: null, remarks, officerEmail };

    this.savingRemarks.set(true);
    const save$ = existing?.verificationId
      ? this.legalCaseService.updateVerification(existing.verificationId, dto)
      : this.legalCaseService.createVerification(dto);

    save$.subscribe({
      next: (saved) => {
        this.verification.set(saved);
        this.savingRemarks.set(false);
        this.toast.success('Remarks Saved', 'Legal remarks have been updated.');
      },
      error: () => {
        this.savingRemarks.set(false);
        this.toast.error('Could Not Save Remarks', 'Please try again.');
      },
    });
  }

  decide(decision: Decision): void {
    if (decision === 'Approved' && !this.allVerified()) {
      this.toast.error('Cannot Approve', 'Please mark all checklist items as Verified first.');
      return;
    }

    const app = this.app();
    const officerEmail = this.auth.currentUser()?.email;
    if (!app || !officerEmail) return;

    const existing = this.verification();
    const now = new Date().toISOString();
    const remarks = this.remarksDraft().trim() || existing?.remarks || '';

    const dto: LegalVerification = {
      appId: app.appId,
      decision,
      decisionDate: now,
      officerEmail,
      remarks,
      infoRequested: decision === 'Query Raised',
      infoRequestDetails: decision === 'Query Raised' ? remarks || undefined : undefined,
      infoRequestedAt: decision === 'Query Raised' ? now : undefined,
    };

    this.decisionSaving.set(decision);
    const save$ = existing?.verificationId
      ? this.legalCaseService.updateVerification(existing.verificationId, dto)
      : this.legalCaseService.createVerification(dto);

    save$.subscribe({
      next: (saved) => {
        this.verification.set(saved);
        this.decisionSaving.set(null);
        this.afterDecision(app, decision, remarks);
      },
      error: () => {
        this.decisionSaving.set(null);
        this.toast.error('Could Not Save Decision', 'Please try again.');
      },
    });
  }

  private afterDecision(app: LoanApplication, decision: Decision, remarks: string): void {
    if (decision === 'Approved') {
      // Advances the workflow the same way the legacy demo mutated stageIndex/status directly —
      // here that's a real backend call so loan-service's own record of the case moves too.
      this.loanApplicationService.updateStage(app.appId, LEGAL_STAGE_INDEX + 1, 'Under Review').subscribe();
      this.notificationService
        .send(
          app.userEmail,
          'Legal Verification Completed',
          `Your application ${app.trackingNo} has cleared legal & property verification and moved to Final Approval.`
        )
        .subscribe();
      this.toast.success('Case Approved', `${app.trackingNo} forwarded to Final Approval.`);
    } else if (decision === 'Query Raised') {
      this.notificationService
        .send(
          app.userEmail,
          'Additional Information Required',
          `The Legal team has raised a query on your application ${app.trackingNo}. Please check remarks: ${remarks || 'See portal for details.'}`
        )
        .subscribe();
      // TODO(role-broadcast): legacy also notifies every 'bankoffice' user here — see the
      // note in legal-auction.ts; no list-users-by-role endpoint exists yet to enumerate them.
      this.toast.success('Query Raised', 'Applicant has been notified.');
    } else if (decision === 'Rejected') {
      this.loanApplicationService.updateStage(app.appId, app.stageIndex, 'Rejected').subscribe();
      this.notificationService
        .send(
          app.userEmail,
          'Application Rejected',
          `Your application ${app.trackingNo} could not be approved due to legal/title verification issues. Remarks: ${remarks || 'Contact support for details.'}`
        )
        .subscribe();
      // TODO(role-broadcast): same gap as above.
      this.toast.success('Case Rejected', `${app.trackingNo} has been rejected.`);
    }
  }

  view(fileName: string): void {
    downloadPlaceholderDoc(fileName);
  }
}
