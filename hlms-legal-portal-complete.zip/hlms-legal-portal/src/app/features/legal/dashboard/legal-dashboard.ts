import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { LoanApplicationService } from '../../../core/services/loan-application.service';
import { LegalCaseService } from '../../../core/services/legal-case.service';
import { AuctionService } from '../../../core/services/auction.service';
import { LegalNoticeService } from '../../../core/services/legal-notice.service';
import { DefaultManagementService } from '../../../core/services/default-management.service';
import { DocumentService } from '../../../core/services/document.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoanApplication, LEGAL_STAGE_INDEX } from '../../../core/models/loan-application.model';
import { LegalNotice, LegalVerification } from '../../../core/models/legal.model';
import { AuctionCase, isOverdueInstallment, auctionBadgeClass } from '../../../core/models/auction.model';

interface OverdueRow {
  app: LoanApplication;
  overdueCount: number;
  stage: string;
}

/** Mirrors the legacy app's viewLegalDashboard(). */
@Component({
  selector: 'app-legal-dashboard',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="page-head">
      <h1>Welcome, {{ firstName() }}</h1>
      <p>Here's what needs your attention across legal review and recovery today.</p>
    </div>

    <div class="grid grid-4">
      <div class="card stat">
        <div class="lbl">Pending Legal Review</div>
        <div class="val orange">{{ queue().length }}</div>
        <div class="sub">Property / mortgage clearance</div>
      </div>
      <div class="card stat">
        <div class="lbl">Verified This Month</div>
        <div class="val teal">{{ verifiedThisMonth() }}</div>
        <div class="sub">Applications cleared</div>
      </div>
      <div class="card stat">
        <div class="lbl">Active Auction / SARFAESI</div>
        <div class="val red">{{ auctionActive() }}</div>
        <div class="sub">Recovery proceedings in motion</div>
      </div>
      <div class="card stat">
        <div class="lbl">Active Legal Notices</div>
        <div class="val">{{ noticesActive() }}</div>
        <div class="sub">Awaiting borrower response</div>
      </div>
    </div>

    <div class="card">
      <h3>☑ Legal Review Queue</h3>
      @if (loading()) {
        <div class="empty-state"><div class="ic">⏳</div>Loading queue…</div>
      } @else if (queue().length === 0) {
        <div class="empty-state"><div class="ic">✅</div>No applications pending legal review.</div>
      } @else {
        <table>
          <thead>
            <tr>
              <th>Tracking No.</th>
              <th>Applicant</th>
              <th>Property</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @for (a of queueTop5(); track a.appId) {
              <tr class="clickable-row" (click)="openCase(a)">
                <td>{{ a.trackingNo }}</td>
                <td>{{ a.applicantName || '—' }}</td>
                <td>{{ a.propertyType || '—' }}</td>
                <td style="text-align:right;"><span class="badge badge-orange">Review Now</span></td>
              </tr>
            }
          </tbody>
        </table>
        @if (queue().length > 5) {
          <button class="btn btn-outline btn-sm" style="margin-top:12px;" type="button" routerLink="/queue">
            View all {{ queue().length }} cases
          </button>
        }
      }
    </div>

    <div class="card">
      <h3>☆ Auction &amp; SARFAESI Snapshot</h3>
      @if (loading()) {
        <div class="empty-state"><div class="ic">⏳</div>Loading…</div>
      } @else if (overdueRows().length === 0) {
        <div class="empty-state"><div class="ic">✅</div>No accounts currently under recovery watch.</div>
      } @else {
        <table>
          <thead>
            <tr>
              <th>Tracking No.</th>
              <th>Borrower</th>
              <th>Overdue Installments</th>
              <th>Stage</th>
            </tr>
          </thead>
          <tbody>
            @for (r of overdueRows(); track r.app.appId) {
              <tr>
                <td>{{ r.app.trackingNo }}</td>
                <td>{{ r.app.applicantName || '—' }}</td>
                <td>{{ r.overdueCount }}</td>
                <td><span class="badge {{ auctionBadgeClass(r.stage) }}">{{ r.stage }}</span></td>
              </tr>
            }
          </tbody>
        </table>
      }
      <button class="btn btn-outline btn-sm" style="margin-top:12px;" type="button" routerLink="/auction">
        Manage Auction &amp; SARFAESI
      </button>
    </div>
  `,
})
export class LegalDashboardComponent implements OnInit {
  private readonly loanApplicationService = inject(LoanApplicationService);
  private readonly legalCaseService = inject(LegalCaseService);
  private readonly auctionService = inject(AuctionService);
  private readonly legalNoticeService = inject(LegalNoticeService);
  private readonly defaultManagementService = inject(DefaultManagementService);
  private readonly documentService = inject(DocumentService);
  private readonly auth = inject(AuthService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  private readonly applications = signal<LoanApplication[]>([]);
  private readonly verifications = signal<LegalVerification[]>([]);
  private readonly auctionCases = signal<AuctionCase[]>([]);
  private readonly notices = signal<LegalNotice[]>([]);
  readonly overdueRows = signal<OverdueRow[]>([]);

  readonly auctionBadgeClass = auctionBadgeClass;

  readonly firstName = () => (this.auth.currentUser()?.name ?? '').split(' ')[0] || 'there';

  readonly queue = computed(() =>
    this.applications().filter((a) => a.stageIndex === LEGAL_STAGE_INDEX && a.status === 'Under Review')
  );
  readonly queueTop5 = computed(() => this.queue().slice(0, 5));

  readonly verifiedThisMonth = computed(() => {
    const now = new Date();
    return this.verifications().filter((v) => {
      if (v.decision !== 'Approved' || !v.decisionDate) return false;
      const d = new Date(v.decisionDate);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    }).length;
  });

  readonly auctionActive = computed(
    () => this.auctionCases().filter((a) => a.stage !== 'None' && a.stage !== 'Resolved').length
  );

  readonly noticesActive = computed(() => this.notices().filter((n) => n.status === 'ACTIVE').length);

  ngOnInit(): void {
    forkJoin({
      apps: this.loanApplicationService.listAll(),
      verifications: this.legalCaseService.listAllVerifications(),
      auctions: this.auctionService.listAll(),
      notices: this.legalNoticeService.listAll(),
      overdueIds: this.defaultManagementService.detectOverdueLoans().pipe(catchError(() => of([] as string[]))),
    }).subscribe({
      next: ({ apps, verifications, auctions, notices, overdueIds }) => {
        this.applications.set(apps);
        this.verifications.set(verifications);
        this.auctionCases.set(auctions);
        this.notices.set(notices);

        if (overdueIds.length === 0) {
          this.loading.set(false);
          return;
        }

        forkJoin(
          overdueIds.map((appId) =>
            this.auctionService.getSchedule(appId).pipe(
              map((schedule) => ({ appId, overdueCount: schedule.filter(isOverdueInstallment).length })),
              catchError(() => of({ appId, overdueCount: 0 }))
            )
          )
        ).subscribe((counts) => {
          this.overdueRows.set(
            counts
              .filter((c) => c.overdueCount > 0)
              .map((c) => ({
                app: apps.find((a) => a.appId === c.appId),
                overdueCount: c.overdueCount,
                stage: auctions.find((a) => a.appId === c.appId)?.stage ?? 'None',
              }))
              .filter((r): r is OverdueRow => !!r.app)
          );
          this.loading.set(false);
        });
      },
      error: () => this.loading.set(false),
    });
  }

  /** Mirrors openLegalCase(): locked until Bank Office has verified all uploaded documents. */
  openCase(app: LoanApplication): void {
    if (app.stageIndex === LEGAL_STAGE_INDEX && app.status === 'Under Review') {
      this.documentService.isBankOfficeVerified(app.appId).subscribe((ok) => {
        if (!ok) {
          this.toast.error(
            'Locked',
            'This case cannot be opened yet — Bank Office must verify all submitted documents before mortgage verification can begin.'
          );
          return;
        }
        this.router.navigate(['/cases', app.appId]);
      });
      return;
    }
    this.router.navigate(['/cases', app.appId]);
  }
}
