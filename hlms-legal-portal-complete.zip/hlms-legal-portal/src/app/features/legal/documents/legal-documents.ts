import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { DocumentService } from '../../../core/services/document.service';
import { LoanApplicationService } from '../../../core/services/loan-application.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuthService } from '../../../core/services/auth.service';
import { ApplicationDocument, PostDisbursementDocument, docBadgeClass } from '../../../core/models/document.model';
import { LoanApplication } from '../../../core/models/loan-application.model';
import { InDatePipe } from '../../../shared/pipes/in-date.pipe';
import { downloadPlaceholderDoc } from '../../../shared/utils/download';
import { RejectPostDisbDocModalComponent } from '../../../shared/components/reject-post-disb-doc-modal/reject-post-disb-doc-modal';

/** Mirrors the legacy app's viewLegalDocuments() — Document Center. */
@Component({
  selector: 'app-legal-documents',
  standalone: true,
  imports: [InDatePipe, RejectPostDisbDocModalComponent],
  template: `
    <div class="page-head">
      <div>
        <h1>Document Center</h1>
        <p>All customer-submitted documents across applications, in one place.</p>
      </div>
    </div>

    <div class="card">
      <h3>
        📤 Post-Disbursement Document Verification
        @if (pendingCount() > 0) {
          <span class="badge badge-orange" style="margin-left:6px;">{{ pendingCount() }} pending</span>
        }
      </h3>
      <p style="font-size:12.5px;color:var(--text-mid);margin-top:0;">
        Documents uploaded by customers after loan disbursement, awaiting your verification.
      </p>
      @if (loading()) {
        <div class="empty-state"><div class="ic">⏳</div>Loading documents…</div>
      } @else if (sortedPdDocs().length === 0) {
        <div class="empty-state"><div class="ic">📭</div>No post-disbursement documents uploaded yet.</div>
      } @else {
        <table>
          <thead>
            <tr>
              <th>Tracking No.</th>
              <th>Applicant</th>
              <th>Document</th>
              <th>Type</th>
              <th>Uploaded</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @for (d of sortedPdDocs(); track d.pdDocId) {
              <tr>
                <td>{{ appFor(d.appId)?.trackingNo || '—' }}</td>
                <td>{{ appFor(d.appId)?.applicantName || '—' }}</td>
                <td>
                  {{ d.fileName }}
                  @if (d.note) {
                    <div style="font-size:11px;color:var(--text-gray);">Note: {{ d.note }}</div>
                  }
                </td>
                <td>{{ d.docType }}</td>
                <td>{{ d.uploadedAt | inDate }}</td>
                <td>
                  <span class="badge {{ docBadgeClass(d.status) }}">{{ d.status }}</span>
                  @if (d.status === 'Rejected' && d.remarks) {
                    <div style="font-size:11px;color:var(--red);margin-top:3px;">{{ d.remarks }}</div>
                  }
                </td>
                <td style="text-align:right;white-space:nowrap;">
                  <button class="btn btn-outline btn-sm" type="button" (click)="view(d.fileName)">View</button>
                  @if (d.status === 'Pending') {
                    <button class="btn btn-primary btn-sm" type="button" (click)="verify(d)">Verify</button>
                    <button class="btn btn-danger btn-sm" type="button" (click)="rejectTarget.set(d)">Reject</button>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>

    <div class="card">
      <h3>🗂️ Application Documents</h3>
      @if (loading()) {
        <div class="empty-state"><div class="ic">⏳</div>Loading documents…</div>
      } @else if (appDocRows().length === 0) {
        <div class="empty-state"><div class="ic">📭</div>No documents available.</div>
      } @else {
        <table>
          <thead>
            <tr>
              <th>Tracking No.</th>
              <th>Applicant</th>
              <th>Document</th>
              <th>Uploaded</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @for (r of appDocRows(); track r.documentId) {
              <tr>
                <td>{{ appFor(r.appId)?.trackingNo || '—' }}</td>
                <td>{{ appFor(r.appId)?.applicantName || '—' }}</td>
                <td>{{ r.fileName }}</td>
                <td>{{ r.uploadedAt | inDate }}</td>
                <td style="text-align:right;">
                  <button class="btn btn-outline btn-sm" type="button" (click)="view(r.fileName)">View</button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>

    @if (rejectTarget(); as target) {
      <app-reject-post-disb-doc-modal
        [doc]="target"
        [app]="appFor(target.appId)"
        (closed)="rejectTarget.set(null)"
        (rejected)="onRejected($event)"
      />
    }
  `,
})
export class LegalDocumentsComponent implements OnInit {
  private readonly documentService = inject(DocumentService);
  private readonly loanApplicationService = inject(LoanApplicationService);
  private readonly notificationService = inject(NotificationService);
  private readonly toast = inject(ToastService);
  private readonly auth = inject(AuthService);

  readonly loading = signal(true);
  readonly docBadgeClass = docBadgeClass;
  readonly rejectTarget = signal<PostDisbursementDocument | null>(null);

  private readonly applications = signal<LoanApplication[]>([]);
  private readonly appDocs = signal<ApplicationDocument[]>([]);
  private readonly pdDocs = signal<PostDisbursementDocument[]>([]);

  readonly pendingCount = computed(() => this.pdDocs().filter((d) => d.status === 'Pending').length);

  readonly sortedPdDocs = computed(() =>
    [...this.pdDocs()].sort(
      (a, b) => new Date(b.uploadedAt ?? 0).getTime() - new Date(a.uploadedAt ?? 0).getTime()
    )
  );

  readonly appDocRows = computed(() =>
    [...this.appDocs()].sort(
      (a, b) => new Date(b.uploadedAt ?? 0).getTime() - new Date(a.uploadedAt ?? 0).getTime()
    )
  );

  ngOnInit(): void {
    this.loanApplicationService.listAll().subscribe((apps) => this.applications.set(apps));
    this.documentService.listApplicationDocuments().subscribe((docs) => this.appDocs.set(docs));
    this.documentService.listPostDisbursementDocuments().subscribe({
      next: (docs) => {
        this.pdDocs.set(docs);
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  appFor(appId: string): LoanApplication | undefined {
    return this.applications().find((a) => a.appId === appId);
  }

  /** No real file storage/download endpoint is wired up yet, so — like the legacy demo — this exports a placeholder. */
  view(fileName: string): void {
    downloadPlaceholderDoc(fileName);
  }

  verify(doc: PostDisbursementDocument): void {
    const officerEmail = this.auth.currentUser()?.email;
    const updated: PostDisbursementDocument = {
      ...doc,
      status: 'Verified',
      verifiedBy: officerEmail,
      verifiedAt: new Date().toISOString(),
      remarks: '',
    };
    this.documentService.savePostDisbursementDocument(updated).subscribe({
      next: (saved) => {
        this.pdDocs.update((list) => list.map((d) => (d.pdDocId === saved.pdDocId ? saved : d)));
        const app = this.appFor(doc.appId);
        if (app) {
          this.notificationService
            .send(
              app.userEmail,
              'Document Verified',
              `Your document "${doc.docType}" (${doc.fileName}) has been verified by the Legal & Valuation Team.`
            )
            .subscribe();
        }
        this.toast.success('Document Verified', doc.fileName);
      },
      error: () => this.toast.error('Could Not Verify', 'Please try again.'),
    });
  }

  onRejected(updated: PostDisbursementDocument): void {
    this.pdDocs.update((list) => list.map((d) => (d.pdDocId === updated.pdDocId ? updated : d)));
    this.rejectTarget.set(null);
  }
}
