import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { LoanApplicationService } from '../../../core/services/loan-application.service';
import { LegalCaseService } from '../../../core/services/legal-case.service';
import { DocumentService } from '../../../core/services/document.service';
import { LoanApplication, LEGAL_STAGE_INDEX } from '../../../core/models/loan-application.model';
import { LegalVerification, decisionBadgeClass } from '../../../core/models/legal.model';
import { InrCurrencyPipe } from '../../../shared/pipes/inr-currency.pipe';
import { InDatePipe } from '../../../shared/pipes/in-date.pipe';

/** Mirrors the legacy app's viewLegalQueue(). */
@Component({
  selector: 'app-legal-queue',
  standalone: true,
  imports: [InrCurrencyPipe, InDatePipe],
  template: `
    <div class="page-head">
      <h1>Legal Review Queue</h1>
      <p>Applications awaiting property title &amp; mortgage document clearance.</p>
    </div>

    <div class="card">
      <h3>🕓 Ready for Mortgage Verification ({{ pending().length }})</h3>
      @if (loading()) {
        <div class="empty-state"><div class="ic">⏳</div>Loading queue…</div>
      } @else if (pending().length === 0) {
        <div class="empty-state">
          <div class="ic">✅</div>
          Nothing pending. New applications will appear here once Document Verification and Credit Check are
          complete.
        </div>
      } @else {
        <table>
          <thead>
            <tr>
              <th>Tracking No.</th>
              <th>Applicant</th>
              <th>Purpose</th>
              <th>Loan Amount</th>
              <th>Property Type</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @for (a of pending(); track a.appId) {
              <tr class="clickable-row" (click)="review(a)">
                <td>{{ a.trackingNo }}</td>
                <td>{{ a.applicantName || '—' }}</td>
                <td>{{ a.purpose || '—' }}</td>
                <td>{{ a.loanAmount | inrCurrency }}</td>
                <td>{{ a.propertyType || '—' }}</td>
                <td style="text-align:right;">
                  <button class="btn btn-primary btn-sm" type="button" (click)="$event.stopPropagation(); review(a)">
                    Review
                  </button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>

    <div class="card">
      <h3>🔒 Awaiting Bank Office Verification ({{ locked().length }})</h3>
      @if (!loading() && locked().length === 0) {
        <div class="empty-state"><div class="ic">✅</div>No cases waiting on Bank Office.</div>
      } @else if (locked().length > 0) {
        <p style="font-size:12.5px;color:var(--text-gray);margin-top:0;">
          These applications cannot be opened for mortgage verification yet — Bank Office must verify all submitted
          documents first.
        </p>
        <table>
          <thead>
            <tr>
              <th>Tracking No.</th>
              <th>Applicant</th>
              <th>Purpose</th>
              <th>Loan Amount</th>
              <th>Property Type</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @for (a of locked(); track a.appId) {
              <tr>
                <td>{{ a.trackingNo }}</td>
                <td>{{ a.applicantName || '—' }}</td>
                <td>{{ a.purpose || '—' }}</td>
                <td>{{ a.loanAmount | inrCurrency }}</td>
                <td>{{ a.propertyType || '—' }}</td>
                <td style="text-align:right;"><span class="badge badge-orange">Pending Bank Office</span></td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>

    <div class="card">
      <h3>📋 Recently Actioned</h3>
      @if (resolvedTop10().length === 0) {
        <div class="empty-state"><div class="ic">📭</div>No history yet.</div>
      } @else {
        <table>
          <thead>
            <tr>
              <th>Tracking No.</th>
              <th>Applicant</th>
              <th>Decision</th>
              <th>Officer</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            @for (a of resolvedTop10(); track a.appId) {
              <tr class="clickable-row" (click)="review(a)">
                <td>{{ a.trackingNo }}</td>
                <td>{{ a.applicantName || '—' }}</td>
                <td>
                  <span class="badge {{ decisionBadgeClass(verificationFor(a.appId)?.decision) }}">
                    {{ verificationFor(a.appId)?.decision || 'Not yet reviewed' }}
                  </span>
                </td>
                <td>{{ verificationFor(a.appId)?.officerEmail || '—' }}</td>
                <td>{{ verificationFor(a.appId)?.decisionDate | inDate }}</td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>
  `,
})
export class LegalQueueComponent implements OnInit {
  private readonly loanApplicationService = inject(LoanApplicationService);
  private readonly legalCaseService = inject(LegalCaseService);
  private readonly documentService = inject(DocumentService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly decisionBadgeClass = decisionBadgeClass;

  private readonly applications = signal<LoanApplication[]>([]);
  private readonly verifications = signal<LegalVerification[]>([]);
  readonly pending = signal<LoanApplication[]>([]);
  readonly locked = signal<LoanApplication[]>([]);

  readonly resolvedTop10 = computed(() =>
    this.applications()
      .filter((a) => a.stageIndex >= LEGAL_STAGE_INDEX)
      .filter((a) => !(a.stageIndex === LEGAL_STAGE_INDEX && a.status === 'Under Review'))
      .slice(0, 10)
  );

  verificationFor(appId: string): LegalVerification | undefined {
    return this.verifications().find((v) => v.appId === appId);
  }

  ngOnInit(): void {
    forkJoin({
      apps: this.loanApplicationService.listAll(),
      verifications: this.legalCaseService.listAllVerifications(),
    }).subscribe({
      next: ({ apps, verifications }) => {
        this.applications.set(apps);
        this.verifications.set(verifications);

        const pendingAll = apps.filter((a) => a.stageIndex === LEGAL_STAGE_INDEX && a.status === 'Under Review');
        if (pendingAll.length === 0) {
          this.loading.set(false);
          return;
        }

        // Mirrors bankOfficeVerified() per pending application, to split Ready vs Locked.
        forkJoin(
          pendingAll.map((a) =>
            this.documentService.isBankOfficeVerified(a.appId).pipe(
              map((ok) => ({ app: a, ok })),
              catchError(() => of({ app: a, ok: false }))
            )
          )
        ).subscribe((results) => {
          this.pending.set(results.filter((r) => r.ok).map((r) => r.app));
          this.locked.set(results.filter((r) => !r.ok).map((r) => r.app));
          this.loading.set(false);
        });
      },
      error: () => this.loading.set(false),
    });
  }

  review(app: LoanApplication): void {
    this.router.navigate(['/cases', app.appId]);
  }
}
