import { Component, EventEmitter, Input, Output, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { DocumentService } from '../../../core/services/document.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuthService } from '../../../core/services/auth.service';
import { PostDisbursementDocument } from '../../../core/models/document.model';
import { LoanApplication } from '../../../core/models/loan-application.model';

/** Mirrors the legacy app's openRejectPostDisbDocModal()/rejectPostDisbDoc(). */
@Component({
  selector: 'app-reject-post-disb-doc-modal',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <div class="modal-overlay" (click)="closed.emit()">
      <div class="modal-box" (click)="$event.stopPropagation()">
        <h3>Reject Document</h3>
        <p style="font-size:12.5px;color:var(--text-mid);margin-top:-6px;">
          The customer will be notified and asked to re-upload a correct document.
        </p>
        <form [formGroup]="form" (ngSubmit)="submit()">
          <div class="field">
            <label>Reason for Rejection<span class="req">*</span></label>
            <textarea
              formControlName="remarks"
              rows="4"
              placeholder="e.g. Document unclear, expired, does not match records..."
            ></textarea>
            @if (submitted() && form.controls.remarks.invalid) {
              <div class="error">Please provide a reason for rejection.</div>
            }
          </div>
          <button class="btn btn-danger btn-block" type="submit" [disabled]="saving()">
            {{ saving() ? 'Rejecting…' : 'Confirm Rejection' }}
          </button>
        </form>
      </div>
    </div>
  `,
})
export class RejectPostDisbDocModalComponent {
  private readonly fb = inject(FormBuilder);
  private readonly documentService = inject(DocumentService);
  private readonly notificationService = inject(NotificationService);
  private readonly toast = inject(ToastService);
  private readonly auth = inject(AuthService);

  /** The post-disbursement document being rejected. */
  @Input({ required: true }) doc!: PostDisbursementDocument;
  /** The owning application, used to notify the customer — omitted only if it couldn't be found. */
  @Input() app: LoanApplication | undefined;

  @Output() closed = new EventEmitter<void>();
  @Output() rejected = new EventEmitter<PostDisbursementDocument>();

  readonly submitted = signal(false);
  readonly saving = signal(false);

  readonly form = this.fb.nonNullable.group({
    remarks: ['', Validators.required],
  });

  submit(): void {
    this.submitted.set(true);
    if (this.form.invalid) return;

    const remarks = this.form.controls.remarks.value.trim();
    if (!remarks) {
      this.form.controls.remarks.setErrors({ required: true });
      return;
    }

    const officerEmail = this.auth.currentUser()?.email;
    const updated: PostDisbursementDocument = {
      ...this.doc,
      status: 'Rejected',
      verifiedBy: officerEmail,
      verifiedAt: new Date().toISOString(),
      remarks,
    };

    this.saving.set(true);
    this.documentService.savePostDisbursementDocument(updated).subscribe({
      next: (saved) => {
        this.saving.set(false);
        if (this.app) {
          this.notificationService
            .send(
              this.app.userEmail,
              'Document Rejected',
              `Your document "${this.doc.docType}" (${this.doc.fileName}) was rejected by the Legal & Valuation Team. Reason: ${remarks}. Please re-upload from Post Disbursement.`
            )
            .subscribe();
        }
        this.toast.success('Document Rejected', this.doc.fileName);
        this.rejected.emit(saved);
      },
      error: () => {
        this.saving.set(false);
        this.toast.error('Could Not Reject', 'Please try again.');
      },
    });
  }
}
