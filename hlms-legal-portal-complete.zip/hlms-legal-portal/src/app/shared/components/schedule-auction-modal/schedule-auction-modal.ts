import { Component, EventEmitter, Input, OnInit, Output, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuctionService } from '../../../core/services/auction.service';
import { LegalNoticeService } from '../../../core/services/legal-notice.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuthService } from '../../../core/services/auth.service';
import { AuctionCase } from '../../../core/models/auction.model';
import { LoanApplication } from '../../../core/models/loan-application.model';

/** Mirrors the legacy app's openLegalAuctionScheduleModal()/scheduleLegalAuction(). */
@Component({
  selector: 'app-schedule-auction-modal',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <div class="modal-overlay" (click)="closed.emit()">
      <div class="modal-box" (click)="$event.stopPropagation()">
        <h3>Post Property for e-Auction</h3>
        <p style="font-size:12.5px;color:var(--text-mid);margin-top:-6px;">
          This will publish <strong>{{ app.propertyAddress }}</strong> to the Bidder Portal so registered bidders
          can view and bid on it.
        </p>
        <form [formGroup]="form" (ngSubmit)="submit()">
          <div class="field">
            <label>Auction Date<span class="req">*</span></label>
            <input type="date" formControlName="auctionDate" [min]="today" />
            @if (submitted() && form.controls.auctionDate.invalid) {
              <div class="error">Please choose an auction date (today or later).</div>
            }
          </div>
          <div class="field">
            <label>Reserve Price (₹)<span class="req">*</span></label>
            <input type="number" formControlName="reservePrice" placeholder="e.g. 4200000" />
            @if (submitted() && form.controls.reservePrice.invalid) {
              <div class="error">Reserve price must be greater than zero.</div>
            }
          </div>
          <button class="btn btn-primary btn-block" style="margin-top:10px;" type="submit" [disabled]="saving()">
            {{ saving() ? 'Posting…' : 'Post Auction to Bidder Portal' }}
          </button>
        </form>
      </div>
    </div>
  `,
})
export class ScheduleAuctionModalComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly auctionService = inject(AuctionService);
  private readonly legalNoticeService = inject(LegalNoticeService);
  private readonly notificationService = inject(NotificationService);
  private readonly toast = inject(ToastService);
  private readonly auth = inject(AuthService);

  @Input({ required: true }) app!: LoanApplication;
  @Input({ required: true }) auctionCase!: AuctionCase;

  @Output() closed = new EventEmitter<void>();
  @Output() scheduled = new EventEmitter<AuctionCase>();

  readonly today = new Date().toISOString().slice(0, 10);
  readonly submitted = signal(false);
  readonly saving = signal(false);

  readonly form = this.fb.nonNullable.group({
    auctionDate: ['', Validators.required],
    // Legacy pre-fills reserve at ~80% of declared property value as a starting suggestion.
    reservePrice: [0, [Validators.required, Validators.min(1)]],
  });

  ngOnInit(): void {
    // Legacy pre-fills reserve at ~80% of declared property value as a starting suggestion.
    if (this.app?.propertyValue) {
      this.form.controls.reservePrice.setValue(Math.round(this.app.propertyValue * 0.8));
    }
  }

  submit(): void {
    this.submitted.set(true);
    if (this.form.invalid) return;

    const { auctionDate, reservePrice } = this.form.getRawValue();
    const officerEmail = this.auth.currentUser()?.email ?? '';
    const auctionDateIso = new Date(auctionDate).toISOString();

    const dto: AuctionCase = {
      ...this.auctionCase,
      appId: this.app.appId,
      stage: 'Auction Scheduled',
      auctionDate: auctionDateIso,
      reservePrice,
    };

    this.saving.set(true);
    const save$ = this.auctionCase.auctionId
      ? this.auctionService.update(this.auctionCase.auctionId, dto)
      : this.auctionService.create(dto);

    save$.subscribe({
      next: (saved) => {
        this.legalNoticeService
          .create({
            appId: this.app.appId,
            noticeType: 'AUCTION_NOTICE',
            issueDate: new Date().toISOString(),
            dueDate: auctionDateIso,
            status: 'ACTIVE',
            officerEmail,
            noticeNo: '',
            content:
              `HOUSING LOAN MANAGEMENT SYSTEM\n` +
              `SALE NOTICE FOR e-AUCTION OF SECURED ASSET\n\n` +
              `Loan Account No.: ${this.app.trackingNo}\n` +
              `Borrower: ${this.app.applicantName}\n` +
              `Property: ${this.app.propertyAddress}\n` +
              `Auction Date: ${new Date(auctionDateIso).toLocaleDateString('en-IN')}\n` +
              `Reserve Price: \u20B9${reservePrice.toLocaleString('en-IN')}\n\n` +
              `This is a system-generated legal notice for demonstration purposes.`,
          })
          .subscribe();

        this.notificationService
          .send(
            this.app.userEmail,
            'e-Auction Scheduled',
            `An e-auction sale of the secured property under loan account ${this.app.trackingNo} has been scheduled for ${new Date(auctionDateIso).toLocaleDateString('en-IN')}.`
          )
          .subscribe();

        // TODO(role-broadcast): legacy also fans this out to every 'bankoffice'/'legal' colleague
        // and every 'bidder' ("New Property Listed for e-Auction"). notification-service only
        // exposes send(userEmail, ...) — there's no list-users-by-role endpoint on user-service
        // to enumerate the audience from the frontend, so this is left as a known gap rather
        // than faked. Needs either a user-service `GET /users?role=` endpoint or a dedicated
        // notification-service broadcast endpoint before it can be wired up for real.

        this.saving.set(false);
        this.toast.success('Auction Posted', `Now visible to bidders — ${new Date(auctionDateIso).toLocaleDateString('en-IN')}`);
        this.scheduled.emit(saved);
      },
      error: () => {
        this.saving.set(false);
        this.toast.error('Could Not Post Auction', 'Please try again.');
      },
    });
  }
}
