# HLMS microservices - Eureka + Feign setup

## What's in this zip

7 standalone Eclipse/Maven projects:

| Project | spring.application.name | Port |
|---|---|---|
| eureka-server | eureka-server | 8761 |
| user-service | user-service | 8081 |
| loan-service | loan-service | 8082 |
| notification-service | notification-service | 8083 |
| legal-service | legal-service | 8084 |
| repayment-service | repayment-service | 8085 |
| document-service | document-service | 8086 |

All 6 business services register with eureka-server on startup and can call
each other by name (not hard-coded host:port) using Feign.

## Import into Eclipse

File > Import > Maven > Existing Maven Projects > select this folder (it
will find all 7 pom.xml files at once) > Finish. Let m2e download
dependencies (needs internet access - this sandbox couldn't reach Maven
Central, so nothing has been build/compiled or tested yet).

## Run order

1. **eureka-server** first. Visit http://localhost:8761 - you should see an
   empty "Instances currently registered" table.
2. Start the other 6 in any order. Watch the eureka-server dashboard -
   each one should appear within ~30 seconds of starting.

## What was changed in every service

- `pom.xml`: added `spring-cloud-starter-netflix-eureka-client` and
  `spring-cloud-starter-openfeign`, plus a `spring-cloud-dependencies` BOM
  import matching that service's own Spring Boot version (they weren't all
  on the same Boot version to start with - see table below).
- `application.properties`: added
  `eureka.client.service-url.defaultZone=http://localhost:8761/eureka/`
  and gave every service its own unique `server.port` (two of them,
  notification-service and document-service, were both using port 8080
  under the same application name `hlms` - I split them into two distinct
  services/ports since they can't both bind :8080 at once).
- Main `@SpringBootApplication` class: added `@EnableDiscoveryClient` and
  `@EnableFeignClients`.

| Service | Spring Boot | Spring Cloud BOM used |
|---|---|---|
| loan-service, legal-service, repayment-service | 3.2.5 | 2023.0.1 |
| document-service | 3.3.5 | 2023.0.3 |
| notification-service | 3.5.4 | 2025.0.0 |
| user-service | 4.1.0 | 2025.1.2 |

Mixing Boot versions across services is fine for Eureka/Feign (each is its
own JVM/process) as long as each service's own Spring Cloud BOM matches its
own Boot version, which is what's done here. If you'd rather not think
about this again, the simplest long-term fix is to align every service on
one Spring Boot version.

## Feign clients (service-to-service calls)

- `loan-service` → `UserServiceClient` (`GET /api/users/{email}` on
  user-service).
- `legal-service` → `LoanServiceClient` (`GET`/`PATCH` on loan-service's
  `/api/loan-applications/{appId}`). Wired into
  `LegalVerificationServiceImpl`: after a legal decision is created or
  updated, it best-effort pushes the loan application's stage/status
  forward in loan-service.
- `repayment-service` → `LoanServiceClient`, same shape. Wired into
  `DisbursementServiceImpl`: recording a disbursement pushes the loan to
  "Disbursed" in loan-service.

All these calls are wrapped in try/catch and only logged on failure -
a downstream service being briefly unreachable should never block the
calling service's own write.

To add another cross-service call anywhere else: create an interface like
the ones in each service's new `client` package, annotate it
`@FeignClient(name = "<the other service's spring.application.name>")`,
declare the HTTP method you want with normal `@GetMapping`/`@PostMapping`/
etc., then `@Autowired` (constructor-inject) it wherever you need it.

## JPA relationships added

Your services already share one Postgres database and already keep
read-only "mirror" copies of entities they don't own (e.g. legal-service
has its own `AppUser` class even though user-service owns that table).
I extended that same pattern: every FK-shaped `String`/`Long` column (like
`legal_verification.app_id`) now *also* has a real `@ManyToOne`/`@OneToOne`
Java field next to it, mapped `insertable = false, updatable = false` so
it's purely for reads/joins - the original column + setter stays the one
thing that actually gets written.

Done for:
- **legal-service**: `LegalVerification`, `LegalNotice`,
  `LegalChecklistItem`, `BankOfficeDecision` → `LoanApplication` (new,
  read-only mirror added) and → `AppUser`.
- **loan-service**: `LoanApplication` → `LoanProduct`.
- **repayment-service**: `EmiInstallment`, `InsurancePolicy` →
  `LoanApplication` (`@ManyToOne`); `AuctionCase`, `Disbursement` →
  `LoanApplication` (`@OneToOne`, since `app_id` is unique on those
  tables); `AuctionNote`, `Bid` → `AuctionCase` (their FK is actually to
  `auction_case.app_id`, not directly to `loan_application`); `Bid` →
  `AppUser` (bidder).

Not done yet (lower value - these are mostly log/document tables without
an obvious "other side" to relate to): `notification-service`
(`NotificationEntity`, `ServiceRequestEntity`) and `document-service`
(`ApplicationDocumentEntity`, `PostDisbursementDocumentEntity`,
`AuditLogEntity`). If you want these too, the same recipe applies: add a
small read-only mirror entity for whatever table the FK points at (like
`legal-service`'s `LoanApplication.java`), then add a `@ManyToOne` next to
the existing FK column.

## Known gaps / things to double-check yourself

- **Nothing here has been compiled** - this sandbox has no internet access,
  so Maven couldn't download the new Cloud dependencies to verify the
  build. Run `mvn clean install` (or let Eclipse do it) on each project
  after importing, and fix anything that doesn't compile.
- I did **not** add an API Gateway (e.g. Spring Cloud Gateway). Right now
  each service is still reached directly on its own port; Eureka just lets
  them find *each other*. Say the word if you want a gateway added as a
  single front door too.
- `hlms.jwt.secret` in loan-service's `application.properties` is a
  placeholder - if user-service issues real JWTs, that secret needs to
  match.
