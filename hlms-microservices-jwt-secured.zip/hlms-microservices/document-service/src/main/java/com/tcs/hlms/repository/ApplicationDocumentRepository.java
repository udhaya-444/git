package com.tcs.hlms.repository;

import com.tcs.hlms.entity.ApplicationDocumentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationDocumentRepository
        extends JpaRepository<ApplicationDocumentEntity, String> {

    List<ApplicationDocumentEntity> findByAppId(String appId);
}