package com.tcs.hlms.repository;

import com.tcs.hlms.entity.AuditLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogRepository
        extends JpaRepository<AuditLogEntity, Long> {

}