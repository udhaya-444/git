package com.tcs.hlms.repository;

import com.tcs.hlms.entity.PostDisbursementDocumentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostDisbursementDocumentRepository
        extends JpaRepository<PostDisbursementDocumentEntity, String> {

    List<PostDisbursementDocumentEntity> findByAppId(String appId);
}