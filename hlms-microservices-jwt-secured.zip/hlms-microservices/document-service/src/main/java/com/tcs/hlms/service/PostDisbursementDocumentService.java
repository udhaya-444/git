package com.tcs.hlms.service;

import com.tcs.hlms.entity.PostDisbursementDocumentEntity;

import java.util.List;

public interface PostDisbursementDocumentService {

    PostDisbursementDocumentEntity saveDocument(
            PostDisbursementDocumentEntity document);

    PostDisbursementDocumentEntity getDocumentById(
            String documentId);

    List<PostDisbursementDocumentEntity> getDocumentsByAppId(
            String appId);

    List<PostDisbursementDocumentEntity> getAllDocuments();

    void deleteDocument(String documentId);
}