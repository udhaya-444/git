package com.hlms2.legal.controller;

import com.hlms2.legal.dto.BankOfficeDecisionDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.BankOfficeDecisionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bank-office/decisions")
public class BankOfficeDecisionController {

    private final BankOfficeDecisionService service;

    public BankOfficeDecisionController(BankOfficeDecisionService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<BankOfficeDecisionDTO> create(@RequestBody BankOfficeDecisionDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{decisionId}")
    public BankOfficeDecisionDTO update(@PathVariable Long decisionId, @RequestBody BankOfficeDecisionDTO dto) {
        return service.update(decisionId, dto);
    }

    @DeleteMapping("/{decisionId}")
    public ResponseEntity<Void> softDelete(@PathVariable Long decisionId) {
        return service.softDelete(decisionId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{decisionId}/restore")
    public ResponseEntity<Void> restore(@PathVariable Long decisionId) {
        return service.restore(decisionId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{decisionId}")
    public BankOfficeDecisionDTO findById(@PathVariable Long decisionId) {
        BankOfficeDecisionDTO dto = service.findById(decisionId);
        if (dto == null) {
            throw new ResourceNotFoundException("No bank office decision found with id " + decisionId + ".");
        }
        return dto;
    }

    @GetMapping("/by-application/{appId}")
    public BankOfficeDecisionDTO findByAppId(@PathVariable String appId) {
        BankOfficeDecisionDTO dto = service.findByAppId(appId);
        if (dto == null) {
            throw new ResourceNotFoundException("No bank office decision found for application " + appId + ".");
        }
        return dto;
    }

    @GetMapping
    public List<BankOfficeDecisionDTO> findAll() {
        return service.findAll();
    }
}
