package com.hlms2.legal.dto;

import java.time.OffsetDateTime;

public class LegalVerificationDTO {
    private Long verificationId;
    private String appId;
    private String decision;
    private OffsetDateTime decisionDate;
    private String officerEmail;
    private String remarks;
    private Boolean infoRequested;
    private String infoRequestDetails;
    private OffsetDateTime infoRequestedAt;

    public LegalVerificationDTO() {
    }

    public LegalVerificationDTO(Long verificationId, String appId, String decision, OffsetDateTime decisionDate,
                                 String officerEmail, String remarks, Boolean infoRequested,
                                 String infoRequestDetails, OffsetDateTime infoRequestedAt) {
        this.verificationId = verificationId;
        this.appId = appId;
        this.decision = decision;
        this.decisionDate = decisionDate;
        this.officerEmail = officerEmail;
        this.remarks = remarks;
        this.infoRequested = infoRequested;
        this.infoRequestDetails = infoRequestDetails;
        this.infoRequestedAt = infoRequestedAt;
    }

    public Long getVerificationId() {
        return verificationId;
    }

    public void setVerificationId(Long verificationId) {
        this.verificationId = verificationId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Boolean getInfoRequested() {
        return infoRequested;
    }

    public void setInfoRequested(Boolean infoRequested) {
        this.infoRequested = infoRequested;
    }

    public String getInfoRequestDetails() {
        return infoRequestDetails;
    }

    public void setInfoRequestDetails(String infoRequestDetails) {
        this.infoRequestDetails = infoRequestDetails;
    }

    public OffsetDateTime getInfoRequestedAt() {
        return infoRequestedAt;
    }

    public void setInfoRequestedAt(OffsetDateTime infoRequestedAt) {
        this.infoRequestedAt = infoRequestedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long verificationId;
        private String appId;
        private String decision;
        private OffsetDateTime decisionDate;
        private String officerEmail;
        private String remarks;
        private Boolean infoRequested;
        private String infoRequestDetails;
        private OffsetDateTime infoRequestedAt;

        public Builder verificationId(Long verificationId) {
            this.verificationId = verificationId;
            return this;
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder decision(String decision) {
            this.decision = decision;
            return this;
        }

        public Builder decisionDate(OffsetDateTime decisionDate) {
            this.decisionDate = decisionDate;
            return this;
        }

        public Builder officerEmail(String officerEmail) {
            this.officerEmail = officerEmail;
            return this;
        }

        public Builder remarks(String remarks) {
            this.remarks = remarks;
            return this;
        }

        public Builder infoRequested(Boolean infoRequested) {
            this.infoRequested = infoRequested;
            return this;
        }

        public Builder infoRequestDetails(String infoRequestDetails) {
            this.infoRequestDetails = infoRequestDetails;
            return this;
        }

        public Builder infoRequestedAt(OffsetDateTime infoRequestedAt) {
            this.infoRequestedAt = infoRequestedAt;
            return this;
        }

        public LegalVerificationDTO build() {
            return new LegalVerificationDTO(verificationId, appId, decision, decisionDate, officerEmail, remarks,
                    infoRequested, infoRequestDetails, infoRequestedAt);
        }
    }
}
