package com.hlms2.legal.entity;

import jakarta.persistence.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'bank_office_decision'.
 *
 * CHG(v2): switched from app_id-as-PK to a surrogate decision_id
 * (BIGSERIAL); app_id is now a unique FK column. The "decision" column
 * was also renamed to "status" in the updated schema. Adds the
 * deleted_at soft delete marker.
 */
@Entity
@Table(name = "bank_office_decision")
public class BankOfficeDecision {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "decision_id")
    private Long decisionId;

    @Column(name = "app_id", length = 50, nullable = false, unique = true)
    private String appId;

    // CHG(v2): column renamed from "decision" to "status" in the schema.
    @Column(name = "status", length = 30)
    private String status;

    @Column(name = "officer")
    private String officerEmail;

    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;

    @Column(name = "reason", length = 255)
    private String reason;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    // CHG(v2): soft delete marker. NULL = active, timestamp = deleted.
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    // --- Relationships (read-only joins on the columns above) ---
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "app_id", referencedColumnName = "app_id", insertable = false, updatable = false)
    private LoanApplication loanApplication;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "officer", referencedColumnName = "email", insertable = false, updatable = false)
    private AppUser officer;

    public BankOfficeDecision() {
    }

    public BankOfficeDecision(Long decisionId, String appId, String status, String officerEmail,
                               OffsetDateTime decisionDate, String reason, String remarks,
                               OffsetDateTime deletedAt) {
        this.decisionId = decisionId;
        this.appId = appId;
        this.status = status;
        this.officerEmail = officerEmail;
        this.decisionDate = decisionDate;
        this.reason = reason;
        this.remarks = remarks;
        this.deletedAt = deletedAt;
    }

    public Long getDecisionId() {
        return decisionId;
    }

    public void setDecisionId(Long decisionId) {
        this.decisionId = decisionId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public LoanApplication getLoanApplication() {
        return loanApplication;
    }

    public AppUser getOfficer() {
        return officer;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long decisionId;
        private String appId;
        private String status;
        private String officerEmail;
        private OffsetDateTime decisionDate;
        private String reason;
        private String remarks;
        private OffsetDateTime deletedAt;

        public Builder decisionId(Long decisionId) {
            this.decisionId = decisionId;
            return this;
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder officerEmail(String officerEmail) {
            this.officerEmail = officerEmail;
            return this;
        }

        public Builder decisionDate(OffsetDateTime decisionDate) {
            this.decisionDate = decisionDate;
            return this;
        }

        public Builder reason(String reason) {
            this.reason = reason;
            return this;
        }

        public Builder remarks(String remarks) {
            this.remarks = remarks;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public BankOfficeDecision build() {
            return new BankOfficeDecision(decisionId, appId, status, officerEmail, decisionDate, reason, remarks,
                    deletedAt);
        }
    }
}
