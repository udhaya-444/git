package com.hlms.loan.dto;

import java.math.BigDecimal;
import java.util.List;

public record EligibilityResponse(
        String status,              // Eligible, Conditionally Eligible, Not Eligible
        BigDecimal maxEligibleLoanAmount,
        BigDecimal estimatedEmi,
        BigDecimal debtToIncomeRatio,
        List<String> reasons,
        List<String> recommendations
) {}
