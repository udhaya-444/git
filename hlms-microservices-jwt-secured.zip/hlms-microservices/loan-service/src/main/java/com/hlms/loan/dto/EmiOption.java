package com.hlms.loan.dto;

import java.math.BigDecimal;

public record EmiOption(
        int tenureYears,
        BigDecimal emi,
        BigDecimal totalPayment,
        BigDecimal totalInterest,
        boolean recommended
) {}
