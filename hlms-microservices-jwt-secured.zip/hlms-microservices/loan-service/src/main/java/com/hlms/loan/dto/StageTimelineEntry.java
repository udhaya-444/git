package com.hlms.loan.dto;

import java.time.OffsetDateTime;

/**
 * One entry in a loan application's workflow timeline (US-LT-06).
 * "completed" entries are reconstructed from audit_log rows; anything after the
 * current stage is marked upcoming with no timestamp.
 */
public record StageTimelineEntry(
        int stageIndex,
        String stageName,
        String status,          // "completed", "current", "upcoming"
        OffsetDateTime occurredAt,
        String actorEmail,
        String action
) {}
