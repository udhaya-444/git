package com.hlms.loan.dto;

import java.util.List;

public record WorkflowTimelineResponse(
        String appId,
        int currentStageIndex,
        String currentStatus,
        List<StageTimelineEntry> timeline
) {}
