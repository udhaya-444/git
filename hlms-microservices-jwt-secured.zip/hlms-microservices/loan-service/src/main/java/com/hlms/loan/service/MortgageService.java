package com.hlms.loan.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.loan.dto.EligibilityRequest;
import com.hlms.loan.dto.EligibilityResponse;
import com.hlms.loan.dto.MortgageCalculationRequest;
import com.hlms.loan.dto.MortgageCalculationResponse;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.entity.LoanProduct;
import com.hlms.loan.exception.BadRequestException;
import com.hlms.loan.exception.ResourceNotFoundException;
import com.hlms.loan.repository.LoanApplicationRepository;
import com.hlms.loan.repository.LoanProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class MortgageService {

    private final LoanApplicationRepository loanApplicationRepository;
    private final LoanProductRepository loanProductRepository;
    private final EligibilityService eligibilityService;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;

    public MortgageService(
            LoanApplicationRepository loanApplicationRepository,
            LoanProductRepository loanProductRepository,
            EligibilityService eligibilityService,
            AuditService auditService,
            ObjectMapper objectMapper) {

        this.loanApplicationRepository = loanApplicationRepository;
        this.loanProductRepository = loanProductRepository;
        this.eligibilityService = eligibilityService;
        this.auditService = auditService;
        this.objectMapper = objectMapper;
    }

    /**
     * US-MRC-01/03/04: ad-hoc calculation,
     * usable with or without a specific application.
     *
     * Read-only: the only DB access here is an optional single-row product
     * lookup; everything else is in-memory computation. readOnly = true lets
     * the JPA provider skip dirty-checking on the loaded LoanProduct.
     */
    @Transactional(readOnly = true)
    public MortgageCalculationResponse calculate(
            MortgageCalculationRequest req) {

        int tenureYears =
                req.getTenureYears() == null
                        ? 20
                        : req.getTenureYears();

        BigDecimal interestRate =
                req.getInterestRate() == null
                        ? new BigDecimal("8.50")
                        : req.getInterestRate();

        EligibilityRequest eligibilityRequest =
                new EligibilityRequest();

        eligibilityRequest.setMonthlyIncome(
                req.getMonthlyIncome());
        eligibilityRequest.setOtherEmis(
                req.getOtherEmis());
        eligibilityRequest.setCibilScore(
                req.getCibilScore());
        eligibilityRequest.setRequestedAmount(
                req.getRequestedLoanAmount());
        eligibilityRequest.setTenureYears(
                tenureYears);
        eligibilityRequest.setInterestRate(
                interestRate);

        EligibilityResponse eligibility =
                eligibilityService.assess(
                        eligibilityRequest);

        BigDecimal unsecuredLimit =
                eligibility.maxEligibleLoanAmount();

        BigDecimal requested =
                req.getRequestedLoanAmount();

        boolean mortgageRequired =
                requested.compareTo(unsecuredLimit) > 0;

        BigDecimal mortgageValueRequired =
                mortgageRequired
                        ? requested.subtract(unsecuredLimit)
                                .setScale(2, RoundingMode.HALF_UP)
                        : BigDecimal.ZERO;

        String maxLtv = "N/A";
        BigDecimal maxLtvFraction = null;

        if (req.getProductId() != null) {

            LoanProduct product =
                    loanProductRepository
                            .findByProductIdAndDeletedAtIsNull(
                                    req.getProductId())
                            .orElseThrow(() ->
                                    new BadRequestException(
                                            "Unknown loan product: "
                                                    + req.getProductId()));

            maxLtv = product.getMaxLtv();
            maxLtvFraction = parseLtvPercent(maxLtv);
        }

        BigDecimal ltvRatio =
                req.getPropertyValue().signum() == 0
                        ? BigDecimal.ZERO
                        : requested.multiply(
                                        BigDecimal.valueOf(100))
                                .divide(
                                        req.getPropertyValue(),
                                        2,
                                        RoundingMode.HALF_UP);

        boolean collateralSufficient;

        if (maxLtvFraction != null) {

            BigDecimal maxSecuredAmount =
                    req.getPropertyValue()
                            .multiply(maxLtvFraction)
                            .setScale(
                                    2,
                                    RoundingMode.HALF_UP);

            collateralSufficient =
                    maxSecuredAmount.compareTo(requested) >= 0;

        } else {

            collateralSufficient =
                    req.getPropertyValue()
                            .multiply(
                                    new BigDecimal("0.80"))
                            .setScale(
                                    2,
                                    RoundingMode.HALF_UP)
                            .compareTo(requested) >= 0;
        }

        List<String> notes = new ArrayList<>();

        if (mortgageRequired) {
            notes.add(
                    "Requested amount exceeds the unsecured eligibility limit of "
                            + unsecuredLimit
                            + "; "
                            + mortgageValueRequired
                            + " of the loan must be secured against the property.");
        } else {
            notes.add(
                    "Requested amount is within the unsecured eligibility limit; no mortgage is strictly required.");
        }

        if (!collateralSufficient) {
            notes.add(
                    "Property value is insufficient collateral for the requested loan amount under the applicable LTV policy.");
        }

        return new MortgageCalculationResponse(
                requested,
                req.getPropertyValue(),
                unsecuredLimit,
                mortgageRequired,
                mortgageValueRequired,
                maxLtv,
                ltvRatio,
                collateralSufficient,
                notes);
    }

    @Transactional
    public MortgageCalculationResponse calculateForApplication(
            String appId,
            String actorEmail) {

        LoanApplication app = getApp(appId);

        MortgageCalculationRequest req =
                new MortgageCalculationRequest();

        req.setRequestedLoanAmount(
                nz(app.getLoanAmount()));
        req.setPropertyValue(
                nz(app.getPropertyValue()));
        req.setProductId(
                app.getProductId());
        req.setTenureYears(
                app.getTenureYears());
        req.setInterestRate(
                app.getInterestRate());
        req.setMonthlyIncome(
                app.getMonthlyIncome());
        req.setOtherEmis(
                app.getOtherEmis());

        MortgageCalculationResponse response =
                calculate(req);

        saveMortgageRecord(
                app,
                response,
                "CALCULATION");

        auditService.record(
                "loan_application",
                appId,
                "MORTGAGE_CALCULATED",
                actorEmail,
                null,
                Map.of(
                        "mortgageRequired",
                        response.mortgageRequired(),
                        "mortgageValueRequired",
                        response.mortgageValueRequired().toString()));

        return response;
    }

    @Transactional
    public LoanApplication evaluateProperty(
            String appId,
            BigDecimal propertyValue,
            String propertyType,
            String valuationNotes,
            String actorEmail) {

        LoanApplication app = getApp(appId);

        BigDecimal previousValue =
                app.getPropertyValue();

        app.setPropertyValue(propertyValue);

        if (propertyType != null) {
            app.setPropertyType(propertyType);
        }

        LoanApplication saved =
                loanApplicationRepository.save(app);

        Map<String, Object> evaluation =
                new LinkedHashMap<>();

        evaluation.put(
                "propertyValue",
                propertyValue);
        evaluation.put(
                "propertyType",
                saved.getPropertyType());
        evaluation.put(
                "notes",
                valuationNotes);
        evaluation.put(
                "evaluatedBy",
                actorEmail);
        evaluation.put(
                "evaluatedAt",
                OffsetDateTime.now().toString());

        mergeIntoFormData(
                saved,
                "propertyEvaluation",
                evaluation);

        loanApplicationRepository.save(saved);

        auditService.record(
                "loan_application",
                appId,
                "PROPERTY_EVALUATED",
                actorEmail,
                Map.of(
                        "propertyValue",
                        previousValue == null
                                ? "null"
                                : previousValue.toString()),
                Map.of(
                        "propertyValue",
                        propertyValue.toString()));

        return saved;
    }

    /**
     * Read-only: fetches the application and reads its stored form_data - no
     * writes occur.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> getMortgageRecord(
            String appId) {

        LoanApplication app = getApp(appId);

        Map<String, Object> formData =
                readFormData(app);

        Object record =
                formData.get("mortgageAssessment");

        if (record == null) {
            throw new ResourceNotFoundException(
                    "No mortgage assessment has been calculated yet for "
                            + appId
                            + ". Call POST /api/mortgage/"
                            + appId
                            + "/calculate first.");
        }

        return (Map<String, Object>) record;
    }

    private void saveMortgageRecord(
            LoanApplication app,
            MortgageCalculationResponse response,
            String source) {

        Map<String, Object> record =
                new LinkedHashMap<>();

        record.put("source", source);
        record.put(
                "requestedLoanAmount",
                response.requestedLoanAmount());
        record.put(
                "propertyValue",
                response.propertyValue());
        record.put(
                "unsecuredEligibleAmount",
                response.unsecuredEligibleAmount());
        record.put(
                "mortgageRequired",
                response.mortgageRequired());
        record.put(
                "mortgageValueRequired",
                response.mortgageValueRequired());
        record.put(
                "maxLtvAllowed",
                response.maxLtvAllowed());
        record.put(
                "loanToValueRatio",
                response.loanToValueRatio());
        record.put(
                "collateralSufficient",
                response.collateralSufficient());
        record.put(
                "notes",
                response.notes());
        record.put(
                "calculatedAt",
                OffsetDateTime.now().toString());

        mergeIntoFormData(
                app,
                "mortgageAssessment",
                record);

        loanApplicationRepository.save(app);
    }

    private void mergeIntoFormData(
            LoanApplication app,
            String key,
            Object value) {

        Map<String, Object> formData =
                readFormData(app);

        formData.put(key, value);

        try {
            app.setFormData(
                    objectMapper.writeValueAsString(formData));
        } catch (Exception e) {
            throw new BadRequestException(
                    "Failed to serialize form_data update: "
                            + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> readFormData(
            LoanApplication app) {

        String raw = app.getFormData();

        if (raw == null || raw.isBlank()) {
            return new LinkedHashMap<>();
        }

        try {
            return objectMapper.readValue(
                    raw,
                    LinkedHashMap.class);
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }

    private LoanApplication getApp(String appId) {

        return loanApplicationRepository
                .findById(appId)
                .filter(a -> a.getDeletedAt() == null)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Loan application not found: "
                                        + appId));
    }

    private BigDecimal parseLtvPercent(String maxLtv) {

        if (maxLtv == null) {
            return null;
        }

        try {

            String digits =
                    maxLtv.replace("%", "")
                            .trim();

            return new BigDecimal(digits)
                    .divide(
                            BigDecimal.valueOf(100),
                            4,
                            RoundingMode.HALF_UP);

        } catch (NumberFormatException e) {
            return null;
        }
    }

    private BigDecimal nz(BigDecimal value) {
        return value == null
                ? BigDecimal.ZERO
                : value;
    }
}
