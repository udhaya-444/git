package com.hlms.loan;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.loan.dto.EligibilityRequest;
import com.hlms.loan.dto.EligibilityResponse;
import com.hlms.loan.entity.EligibilityAssessment;
import com.hlms.loan.repository.EligibilityAssessmentRepository;
import com.hlms.loan.service.EligibilityService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EligibilityServiceTest {

    @Mock
    private EligibilityAssessmentRepository assessmentRepository;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private EligibilityService eligibilityService;

    private EligibilityRequest request;

    @BeforeEach
    void setup() {

        request = new EligibilityRequest();
        request.setMonthlyIncome(new BigDecimal("100000"));
        request.setOtherEmis(new BigDecimal("10000"));
        request.setCibilScore(780);
        request.setRequestedAmount(new BigDecimal("2000000"));
        request.setTenureYears(20);
        request.setInterestRate(new BigDecimal("8.5"));
    }

    // =====================================================
    // POSITIVE TEST CASES
    // =====================================================

    @Test
    void assess_ShouldReturnEligible() {

        EligibilityResponse response =
                eligibilityService.assess(request);

        assertEquals("Eligible", response.status());
        assertNotNull(response.maxEligibleLoanAmount());
        assertNotNull(response.estimatedEmi());
        assertFalse(response.reasons().isEmpty());
    }

    @Test
    void assess_ShouldReturnConditionallyEligible() {

        request.setCibilScore(700);

        EligibilityResponse response =
                eligibilityService.assess(request);

        assertEquals(
                "Conditionally Eligible",
                response.status());
    }

    @Test
    void assessAndSave_ShouldPersistAssessment()
            throws Exception {

        when(objectMapper.writeValueAsString(anyList()))
                .thenReturn("[\"reason\"]");

        EligibilityResponse response =
                eligibilityService.assessAndSave(
                        "test@bank.com",
                        request);

        verify(assessmentRepository)
                .save(any(EligibilityAssessment.class));

        assertNotNull(response);
    }

    @Test
    void getHistory_ShouldReturnRecords() {

        EligibilityAssessment assessment =
                EligibilityAssessment.builder()
                        .userEmail("test@bank.com")
                        .build();

        when(assessmentRepository
                .findByUserEmailAndDeletedAtIsNullOrderByCreatedAtDesc(
                        "test@bank.com"))
                .thenReturn(List.of(assessment));

        List<EligibilityAssessment> result =
                eligibilityService.getHistory(
                        "test@bank.com");

        assertEquals(1, result.size());
    }

    @Test
    void emiForLoan_ShouldCalculateEmi() {

        BigDecimal emi =
                eligibilityService.emiForLoan(
                        new BigDecimal("1000000"),
                        new BigDecimal("8.5"),
                        20);

        assertTrue(
                emi.compareTo(BigDecimal.ZERO) > 0);
    }

    @Test
    void maxLoanForEmi_ShouldCalculateLoanAmount() {

        BigDecimal loanAmount =
                eligibilityService.maxLoanForEmi(
                        new BigDecimal("25000"),
                        new BigDecimal("8.5"),
                        20);

        assertTrue(
                loanAmount.compareTo(BigDecimal.ZERO) > 0);
    }

    // =====================================================
    // NEGATIVE TEST CASES
    // =====================================================

    @Test
    void assess_ShouldReturnNotEligible_WhenLowCibil() {

        request.setCibilScore(600);

        EligibilityResponse response =
                eligibilityService.assess(request);

        assertEquals(
                "Not Eligible",
                response.status());

        assertFalse(response.reasons().isEmpty());
    }

    @Test
    void assess_ShouldReturnNotEligible_WhenDtiExceeded() {

        request.setMonthlyIncome(
                new BigDecimal("20000"));

        request.setOtherEmis(
                new BigDecimal("15000"));

        request.setRequestedAmount(
                new BigDecimal("5000000"));

        EligibilityResponse response =
                eligibilityService.assess(request);

        assertEquals(
                "Not Eligible",
                response.status());
    }

    @Test
    void assessAndSave_ShouldHandleJsonException()
            throws Exception {

        when(objectMapper.writeValueAsString(anyList()))
                .thenThrow(
                        new RuntimeException("JSON Error"));

        EligibilityResponse response =
                eligibilityService.assessAndSave(
                        "test@bank.com",
                        request);

        verify(assessmentRepository)
                .save(any(EligibilityAssessment.class));

        assertNotNull(response);
    }

    @Test
    void getHistory_ShouldReturnEmptyList() {

        when(assessmentRepository
                .findByUserEmailAndDeletedAtIsNullOrderByCreatedAtDesc(
                        "user@test.com"))
                .thenReturn(Collections.emptyList());

        List<EligibilityAssessment> result =
                eligibilityService.getHistory(
                        "user@test.com");

        assertTrue(result.isEmpty());
    }

    // =====================================================
    // EDGE TEST CASES
    // =====================================================

    @Test
    void assess_ShouldHandleNullValues() {

        EligibilityRequest req =
                new EligibilityRequest();

        EligibilityResponse response =
                eligibilityService.assess(req);

        assertNotNull(response);
    }

    @Test
    void assess_ShouldBeConditionallyEligible_WhenCibilExactly650() {

        request.setCibilScore(650);

        EligibilityResponse response =
                eligibilityService.assess(request);

        assertEquals(
                "Conditionally Eligible",
                response.status());
    }

    @Test
    void assess_ShouldBeEligible_WhenCibilExactly750() {

        request.setCibilScore(750);

        EligibilityResponse response =
                eligibilityService.assess(request);

        assertEquals(
                "Eligible",
                response.status());
    }

    @Test
    void assess_ShouldReturnNotEligible_WhenDisposableIncomeNegative() {

        request.setMonthlyIncome(
                new BigDecimal("10000"));

        request.setOtherEmis(
                new BigDecimal("12000"));

        EligibilityResponse response =
                eligibilityService.assess(request);

        assertEquals(
                "Not Eligible",
                response.status());
    }

    @Test
    void emiForLoan_ShouldReturnZero_WhenPrincipalZero() {

        BigDecimal emi =
                eligibilityService.emiForLoan(
                        BigDecimal.ZERO,
                        new BigDecimal("8.5"),
                        20);

        assertEquals(
                BigDecimal.ZERO,
                emi);
    }

    @Test
    void emiForLoan_ShouldHandleZeroInterestRate() {

        BigDecimal emi =
                eligibilityService.emiForLoan(
                        new BigDecimal("120000"),
                        BigDecimal.ZERO,
                        10);

        assertTrue(
                emi.compareTo(BigDecimal.ZERO) > 0);
    }

    @Test
    void maxLoanForEmi_ShouldReturnZero_WhenBudgetZero() {

        BigDecimal amount =
                eligibilityService.maxLoanForEmi(
                        BigDecimal.ZERO,
                        new BigDecimal("8.5"),
                        10);

        assertEquals(
                BigDecimal.ZERO,
                amount);
    }

    @Test
    void maxLoanForEmi_ShouldHandleZeroInterestRate() {

        BigDecimal amount =
                eligibilityService.maxLoanForEmi(
                        new BigDecimal("10000"),
                        BigDecimal.ZERO,
                        10);

        assertEquals(
                new BigDecimal("1200000.00"),
                amount);
    }

    @Test
    void assessAndSave_ShouldStoreCorrectFields()
            throws Exception {

        when(objectMapper.writeValueAsString(anyList()))
                .thenReturn("[\"data\"]");

        eligibilityService.assessAndSave(
                "test@bank.com",
                request);

        ArgumentCaptor<EligibilityAssessment> captor =
                ArgumentCaptor.forClass(
                        EligibilityAssessment.class);

        verify(assessmentRepository)
                .save(captor.capture());

        EligibilityAssessment saved =
                captor.getValue();

        assertEquals(
                "test@bank.com",
                saved.getUserEmail());

        assertEquals(
                request.getCibilScore(),
                saved.getCibilScore());

        assertEquals(
                request.getMonthlyIncome(),
                saved.getMonthlyIncome());
    }

    @Test
    void assessAndSave_ShouldHandleNullUserEmail()
            throws Exception {

        when(objectMapper.writeValueAsString(anyList()))
                .thenReturn("[]");

        EligibilityResponse response =
                eligibilityService.assessAndSave(
                        null,
                        request);

        verify(assessmentRepository)
                .save(any(EligibilityAssessment.class));

        assertNotNull(response);
    }

    @Test
    void getHistory_WithNullEmail_ShouldReturnEmptyList() {

        when(assessmentRepository
                .findByUserEmailAndDeletedAtIsNullOrderByCreatedAtDesc(
                        null))
                .thenReturn(List.of());

        List<EligibilityAssessment> result =
                eligibilityService.getHistory(null);

        assertTrue(result.isEmpty());
    }

    @Test
    void assess_ShouldPopulateAllResponseFields() {

        EligibilityResponse response =
                eligibilityService.assess(request);

        assertNotNull(response.status());
        assertNotNull(response.maxEligibleLoanAmount());
        assertNotNull(response.estimatedEmi());
        assertNotNull(response.reasons());
    }
}