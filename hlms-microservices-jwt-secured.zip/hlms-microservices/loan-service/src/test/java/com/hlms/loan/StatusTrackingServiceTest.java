package com.hlms.loan;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.loan.dto.ExpectedCompletion;
import com.hlms.loan.dto.StakeholderInfo;
import com.hlms.loan.dto.TurnaroundReportEntry;
import com.hlms.loan.dto.WorkflowTimelineResponse;
import com.hlms.loan.entity.AuditLog;
import com.hlms.loan.entity.BankOfficeDecision;
import com.hlms.loan.entity.Disbursement;
import com.hlms.loan.entity.LegalVerification;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.repository.BankOfficeDecisionRepository;
import com.hlms.loan.repository.DisbursementRepository;
import com.hlms.loan.repository.LegalVerificationRepository;
import com.hlms.loan.service.AuditService;
import com.hlms.loan.service.LoanApplicationService;
import com.hlms.loan.service.StatusTrackingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StatusTrackingServiceTest {

    @Mock
    private LoanApplicationService loanApplicationService;

    @Mock
    private AuditService auditService;

    @Mock
    private LegalVerificationRepository legalVerificationRepository;

    @Mock
    private BankOfficeDecisionRepository bankOfficeDecisionRepository;

    @Mock
    private DisbursementRepository disbursementRepository;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private StatusTrackingService statusTrackingService;

    private LoanApplication application;

    @BeforeEach
    void setup() {

        application = LoanApplication.builder()
                .appId("APP001")
                .userEmail("user@test.com")
                .status("Submitted")
                .stageIndex(2)
                .createdAt(OffsetDateTime.now().minusDays(2))
                .build();

        lenient().when(
                loanApplicationService.workflowStages())
                .thenReturn(List.of(
                        "Draft",
                        "Submitted",
                        "Document Verification",
                        "Legal Verification",
                        "Bank Office Decision",
                        "Disbursement",
                        "Active"));
    }

    @Test
    void currentStakeholder_ShouldReturnCustomer() {

        application.setStageIndex(0);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertEquals("customer", result.stakeholderRole());
        assertEquals("user@test.com", result.stakeholderEmail());
    }

    @Test
    void currentStakeholder_ShouldReturnAdmin() {

        application.setStageIndex(1);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertEquals("admin", result.stakeholderRole());
    }

    @Test
    void currentStakeholder_ShouldReturnLegalOfficer() {

        application.setStageIndex(2);

        LegalVerification verification =
                new LegalVerification();

        verification.setOfficer("legal@test.com");

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(legalVerificationRepository
                .findByAppIdAndDeletedAtIsNull("APP001"))
                .thenReturn(Optional.of(verification));

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertEquals("legal", result.stakeholderRole());
        assertEquals("legal@test.com",
                result.stakeholderEmail());
    }

    @Test
    void currentStakeholder_ShouldHandleMissingLegalRecord() {

        application.setStageIndex(2);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(legalVerificationRepository
                .findByAppIdAndDeletedAtIsNull("APP001"))
                .thenReturn(Optional.empty());

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertEquals("legal", result.stakeholderRole());
    }

    @Test
    void currentStakeholder_ShouldHandleLegalOfficerNull() {

        application.setStageIndex(2);

        LegalVerification verification =
                new LegalVerification();

        verification.setOfficer(null);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(legalVerificationRepository
                .findByAppIdAndDeletedAtIsNull("APP001"))
                .thenReturn(Optional.of(verification));

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertEquals("legal", result.stakeholderRole());
        assertNull(result.stakeholderEmail());
    }

    @Test
    void currentStakeholder_ShouldReturnBankOfficer() {

        application.setStageIndex(4);

        BankOfficeDecision decision =
                new BankOfficeDecision();

        decision.setOfficer("manager@test.com");

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(bankOfficeDecisionRepository
                .findByAppIdAndDeletedAtIsNull("APP001"))
                .thenReturn(Optional.of(decision));

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertEquals("bankoffice",
                result.stakeholderRole());

        assertEquals("manager@test.com",
                result.stakeholderEmail());
    }

    @Test
    void currentStakeholder_ShouldHandleMissingOfficerRecords() {

        application.setStageIndex(4);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(bankOfficeDecisionRepository
                .findByAppIdAndDeletedAtIsNull("APP001"))
                .thenReturn(Optional.empty());

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertEquals("bankoffice",
                result.stakeholderRole());

        assertNull(result.stakeholderEmail());
    }

    @Test
    void currentStakeholder_ShouldReturnDisbursementTeam() {

        application.setStageIndex(5);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(disbursementRepository
                .findByAppIdAndDeletedAtIsNull("APP001"))
                .thenReturn(
                        Optional.of(mock(Disbursement.class)));

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertEquals("bankoffice",
                result.stakeholderRole());
    }

    @Test
    void currentStakeholder_ShouldHandleMissingDisbursementRecord() {

        application.setStageIndex(5);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(disbursementRepository
                .findByAppIdAndDeletedAtIsNull("APP001"))
                .thenReturn(Optional.empty());

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertEquals("bankoffice",
                result.stakeholderRole());
    }

    @Test
    void currentStakeholder_ShouldHandleUnknownStage() {

        application.setStageIndex(99);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        StakeholderInfo result =
                statusTrackingService.currentStakeholder("APP001");

        assertNotNull(result);
    }

    @Test
    void timeline_ShouldReturnTimelineResponse()
            throws Exception {

        AuditLog log = new AuditLog();
        log.setAction("SUBMIT");
        log.setAfterData("{\"stageIndex\":1}");
        log.setCreatedAt(OffsetDateTime.now());

        JsonNode root = mock(JsonNode.class);
        JsonNode stageNode = mock(JsonNode.class);

        when(stageNode.isInt()).thenReturn(true);
        when(stageNode.asInt()).thenReturn(1);

        when(root.get("stageIndex"))
                .thenReturn(stageNode);

        when(objectMapper.readTree(anyString()))
                .thenReturn(root);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(auditService.historyChronological(
                "loan_application",
                "APP001"))
                .thenReturn(List.of(log));

        WorkflowTimelineResponse response =
                statusTrackingService.timeline("APP001");

        assertNotNull(response);
    }

    @Test
    void timeline_ShouldHandleMissingStageIndex()
            throws Exception {

        AuditLog log = new AuditLog();
        log.setAfterData("{}");

        JsonNode root = mock(JsonNode.class);

        when(root.get("stageIndex"))
                .thenReturn(null);

        when(objectMapper.readTree(anyString()))
                .thenReturn(root);

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(auditService.historyChronological(
                "loan_application",
                "APP001"))
                .thenReturn(List.of(log));

        assertNotNull(
                statusTrackingService.timeline("APP001"));
    }

    @Test
    void timeline_ShouldHandleInvalidJson()
            throws Exception {

        AuditLog log = new AuditLog();
        log.setAfterData("INVALID");

        when(objectMapper.readTree(anyString()))
                .thenThrow(new RuntimeException());

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(auditService.historyChronological(
                "loan_application",
                "APP001"))
                .thenReturn(List.of(log));

        assertNotNull(
                statusTrackingService.timeline("APP001"));
    }

    @Test
    void expectedCompletion_ShouldReturnDate() {

        AuditLog log = new AuditLog();
        log.setCreatedAt(
                OffsetDateTime.now().minusDays(1));

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(auditService.history(
                "loan_application",
                "APP001"))
                .thenReturn(List.of(log));

        ExpectedCompletion result =
                statusTrackingService.expectedCompletion(
                        "APP001");

        assertNotNull(result);
    }

    @Test
    void expectedCompletion_ShouldUseCreatedDate_WhenNoAuditFound() {

        when(loanApplicationService.get("APP001"))
                .thenReturn(application);

        when(auditService.history(
                "loan_application",
                "APP001"))
                .thenReturn(List.of());

        ExpectedCompletion result =
                statusTrackingService.expectedCompletion(
                        "APP001");

        assertNotNull(result);
    }

    @Test
    void turnaroundReport_ShouldReturnEntries() {

        AuditLog log1 = new AuditLog();
        log1.setCreatedAt(
                OffsetDateTime.now().minusHours(5));

        AuditLog log2 = new AuditLog();
        log2.setCreatedAt(
                OffsetDateTime.now());

        when(auditService.historyChronological(
                "loan_application",
                "APP001"))
                .thenReturn(List.of(log1, log2));

        List<TurnaroundReportEntry> result =
                statusTrackingService.turnaroundReport(
                        "APP001");

        assertEquals(1, result.size());
    }

    @Test
    void turnaroundReport_ShouldReturnEmpty_WhenNoEvents() {

        when(auditService.historyChronological(
                "loan_application",
                "APP001"))
                .thenReturn(List.of());

        assertTrue(
                statusTrackingService
                        .turnaroundReport("APP001")
                        .isEmpty());
    }

    @Test
    void averageTurnaroundAcrossApplications_ShouldReturnEmptyMap() {

        when(loanApplicationService.listAll())
                .thenReturn(List.of());

        Map<String, Double> result =
                statusTrackingService
                        .averageTurnaroundAcrossApplications();

        assertTrue(result.isEmpty());
    }

    @Test
    void averageTurnaroundAcrossApplications_ShouldCalculateAverage() {

        LoanApplication app =
                LoanApplication.builder()
                        .appId("APP001")
                        .build();

        AuditLog log1 = new AuditLog();
        log1.setCreatedAt(
                OffsetDateTime.now().minusHours(3));

        AuditLog log2 = new AuditLog();
        log2.setCreatedAt(
                OffsetDateTime.now());

        when(loanApplicationService.listAll())
                .thenReturn(List.of(app));

        when(auditService.historyChronological(
                "loan_application",
                "APP001"))
                .thenReturn(List.of(log1, log2));

        Map<String, Double> result =
                statusTrackingService
                        .averageTurnaroundAcrossApplications();

        assertNotNull(result);
    }
}