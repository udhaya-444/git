package com.hlms.notification.service;
import com.hlms.notification.client.LoanApplicationClient;
import com.hlms.notification.entity.ServiceRequest;
import com.hlms.notification.exception.BadRequestException;
import com.hlms.notification.exception.ResourceNotFoundException;
import com.hlms.notification.repository.ServiceRequestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.UUID;
/** Backs feature "9. Post-Disbursement Service Management". */
@Service
public class ServiceRequestService {
    private static final Logger log = LoggerFactory.getLogger(ServiceRequestService.class);
    private final ServiceRequestRepository repository;
    private final LoanApplicationClient loanApplicationClient;
    @Transactional
    public ServiceRequest create(String appId, String userEmail, String requestType, String description) {
        // Confirm the application exists (via loan-service, over Feign) before opening a
        // post-disbursement request against it. Best-effort: a downstream outage logs a
        // warning rather than blocking the request.
        try {
            loanApplicationClient.getApplication(appId);
        } catch (feign.FeignException.NotFound nf) {
            throw new BadRequestException("No such loan application: " + appId);
        } catch (Exception ex) {
            log.warn("Could not verify application {} with loan-service before creating a service request: {}", appId, ex.getMessage());
        }
        ServiceRequest sr = ServiceRequest.builder()
                .requestId("SR-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .refNo("SR-REF-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase())
                .appId(appId)
                .userEmail(userEmail)
                .requestType(requestType)
                .description(description)
                .status("Requested")
                .build();
        return repository.save(sr);
    }
    public List<ServiceRequest> listForUser(String userEmail) {
        return repository.findByUserEmailAndDeletedAtIsNull(userEmail);
    }
    public List<ServiceRequest> listForApp(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId);
    }
    public ServiceRequest get(String requestId) {
        return repository.findById(requestId)
                .filter(r -> r.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Service request not found: " + requestId));
    }
    @Transactional
    public ServiceRequest updateStatus(String requestId, String status) {
        ServiceRequest sr = get(requestId);
        sr.setStatus(status);
        return repository.save(sr);
    }

    public ServiceRequestService(ServiceRequestRepository repository, LoanApplicationClient loanApplicationClient) {
        this.repository = repository;
        this.loanApplicationClient = loanApplicationClient;
    }
}