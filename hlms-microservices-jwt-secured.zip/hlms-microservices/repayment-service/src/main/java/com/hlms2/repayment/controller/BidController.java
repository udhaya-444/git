package com.hlms2.repayment.controller;

import com.hlms2.repayment.dto.BidDTO;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.service.BidService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Direct by-id access to bids; see AuctionCaseController for the nested /api/auctions/{appId}/bids routes. */
@RestController
@RequestMapping("/api/bids")
public class BidController {

    private final BidService service;

    public BidController(BidService service) {
        this.service = service;
    }

    @PutMapping("/{bidId}")
    public BidDTO update(@PathVariable String bidId, @RequestBody BidDTO dto) {
        dto.setBidId(bidId);
        return service.update(dto);
    }

    @DeleteMapping("/{bidId}")
    public ResponseEntity<Void> softDelete(@PathVariable String bidId) {
        return service.softDelete(bidId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{bidId}/restore")
    public ResponseEntity<Void> restore(@PathVariable String bidId) {
        return service.restore(bidId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{bidId}")
    public BidDTO findById(@PathVariable String bidId) {
        BidDTO dto = service.findById(bidId);
        if (dto == null) {
            throw new ResourceNotFoundException("Bid " + bidId + " does not exist.");
        }
        return dto;
    }

    @GetMapping
    public List<BidDTO> findAll() {
        return service.findAll();
    }
}
