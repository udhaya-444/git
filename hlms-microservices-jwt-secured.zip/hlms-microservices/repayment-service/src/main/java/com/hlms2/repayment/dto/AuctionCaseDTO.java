package com.hlms2.repayment.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AuctionCaseDTO {
    private Long auctionId;
    private String appId;
    private String stage;
    private LocalDate noticeDate;
    private LocalDate noticeDueDate;
    private BigDecimal demandAmount;
    private LocalDate possessionDate;
    private LocalDate auctionDate;
    private BigDecimal reservePrice;

    public AuctionCaseDTO() {
    }

    public AuctionCaseDTO(Long auctionId, String appId, String stage, LocalDate noticeDate, LocalDate noticeDueDate, BigDecimal demandAmount, LocalDate possessionDate, LocalDate auctionDate, BigDecimal reservePrice) {
        this.auctionId = auctionId;
        this.appId = appId;
        this.stage = stage;
        this.noticeDate = noticeDate;
        this.noticeDueDate = noticeDueDate;
        this.demandAmount = demandAmount;
        this.possessionDate = possessionDate;
        this.auctionDate = auctionDate;
        this.reservePrice = reservePrice;
    }

    public Long getAuctionId() {
        return auctionId;
    }
    public void setAuctionId(Long auctionId) {
        this.auctionId = auctionId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getStage() {
        return stage;
    }
    public void setStage(String stage) {
        this.stage = stage;
    }
    public LocalDate getNoticeDate() {
        return noticeDate;
    }
    public void setNoticeDate(LocalDate noticeDate) {
        this.noticeDate = noticeDate;
    }
    public LocalDate getNoticeDueDate() {
        return noticeDueDate;
    }
    public void setNoticeDueDate(LocalDate noticeDueDate) {
        this.noticeDueDate = noticeDueDate;
    }
    public BigDecimal getDemandAmount() {
        return demandAmount;
    }
    public void setDemandAmount(BigDecimal demandAmount) {
        this.demandAmount = demandAmount;
    }
    public LocalDate getPossessionDate() {
        return possessionDate;
    }
    public void setPossessionDate(LocalDate possessionDate) {
        this.possessionDate = possessionDate;
    }
    public LocalDate getAuctionDate() {
        return auctionDate;
    }
    public void setAuctionDate(LocalDate auctionDate) {
        this.auctionDate = auctionDate;
    }
    public BigDecimal getReservePrice() {
        return reservePrice;
    }
    public void setReservePrice(BigDecimal reservePrice) {
        this.reservePrice = reservePrice;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long auctionId;
        private String appId;
        private String stage;
        private LocalDate noticeDate;
        private LocalDate noticeDueDate;
        private BigDecimal demandAmount;
        private LocalDate possessionDate;
        private LocalDate auctionDate;
        private BigDecimal reservePrice;

        public Builder auctionId(Long auctionId) {
            this.auctionId = auctionId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder stage(String stage) {
            this.stage = stage;
            return this;
        }
        public Builder noticeDate(LocalDate noticeDate) {
            this.noticeDate = noticeDate;
            return this;
        }
        public Builder noticeDueDate(LocalDate noticeDueDate) {
            this.noticeDueDate = noticeDueDate;
            return this;
        }
        public Builder demandAmount(BigDecimal demandAmount) {
            this.demandAmount = demandAmount;
            return this;
        }
        public Builder possessionDate(LocalDate possessionDate) {
            this.possessionDate = possessionDate;
            return this;
        }
        public Builder auctionDate(LocalDate auctionDate) {
            this.auctionDate = auctionDate;
            return this;
        }
        public Builder reservePrice(BigDecimal reservePrice) {
            this.reservePrice = reservePrice;
            return this;
        }

        public AuctionCaseDTO build() {
            return new AuctionCaseDTO(auctionId, appId, stage, noticeDate, noticeDueDate, demandAmount, possessionDate, auctionDate, reservePrice);
        }
    }
}
