package com.hlms2.repayment.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public class BidDTO {
    private String bidId;
    private String appId;
    private String bidderEmail;
    private BigDecimal bidAmount;
    private OffsetDateTime createdAt;

    public BidDTO() {
    }

    public BidDTO(String bidId, String appId, String bidderEmail, BigDecimal bidAmount, OffsetDateTime createdAt) {
        this.bidId = bidId;
        this.appId = appId;
        this.bidderEmail = bidderEmail;
        this.bidAmount = bidAmount;
        this.createdAt = createdAt;
    }

    public String getBidId() {
        return bidId;
    }
    public void setBidId(String bidId) {
        this.bidId = bidId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getBidderEmail() {
        return bidderEmail;
    }
    public void setBidderEmail(String bidderEmail) {
        this.bidderEmail = bidderEmail;
    }
    public BigDecimal getBidAmount() {
        return bidAmount;
    }
    public void setBidAmount(BigDecimal bidAmount) {
        this.bidAmount = bidAmount;
    }
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String bidId;
        private String appId;
        private String bidderEmail;
        private BigDecimal bidAmount;
        private OffsetDateTime createdAt;

        public Builder bidId(String bidId) {
            this.bidId = bidId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder bidderEmail(String bidderEmail) {
            this.bidderEmail = bidderEmail;
            return this;
        }
        public Builder bidAmount(BigDecimal bidAmount) {
            this.bidAmount = bidAmount;
            return this;
        }
        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public BidDTO build() {
            return new BidDTO(bidId, appId, bidderEmail, bidAmount, createdAt);
        }
    }
}
