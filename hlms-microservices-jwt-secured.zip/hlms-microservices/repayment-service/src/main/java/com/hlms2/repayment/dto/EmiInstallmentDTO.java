package com.hlms2.repayment.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class EmiInstallmentDTO {
    private String installmentId;
    private String appId;
    private Integer installmentNo;
    private LocalDate dueDate;
    private BigDecimal emiAmount;
    private BigDecimal principalComponent;
    private BigDecimal interestComponent;
    private BigDecimal closingBalance;
    private String status;
    private LocalDate paidDate;

    public EmiInstallmentDTO() {
    }

    public EmiInstallmentDTO(String installmentId, String appId, Integer installmentNo, LocalDate dueDate, BigDecimal emiAmount, BigDecimal principalComponent, BigDecimal interestComponent, BigDecimal closingBalance, String status, LocalDate paidDate) {
        this.installmentId = installmentId;
        this.appId = appId;
        this.installmentNo = installmentNo;
        this.dueDate = dueDate;
        this.emiAmount = emiAmount;
        this.principalComponent = principalComponent;
        this.interestComponent = interestComponent;
        this.closingBalance = closingBalance;
        this.status = status;
        this.paidDate = paidDate;
    }

    public String getInstallmentId() {
        return installmentId;
    }
    public void setInstallmentId(String installmentId) {
        this.installmentId = installmentId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public Integer getInstallmentNo() {
        return installmentNo;
    }
    public void setInstallmentNo(Integer installmentNo) {
        this.installmentNo = installmentNo;
    }
    public LocalDate getDueDate() {
        return dueDate;
    }
    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }
    public BigDecimal getEmiAmount() {
        return emiAmount;
    }
    public void setEmiAmount(BigDecimal emiAmount) {
        this.emiAmount = emiAmount;
    }
    public BigDecimal getPrincipalComponent() {
        return principalComponent;
    }
    public void setPrincipalComponent(BigDecimal principalComponent) {
        this.principalComponent = principalComponent;
    }
    public BigDecimal getInterestComponent() {
        return interestComponent;
    }
    public void setInterestComponent(BigDecimal interestComponent) {
        this.interestComponent = interestComponent;
    }
    public BigDecimal getClosingBalance() {
        return closingBalance;
    }
    public void setClosingBalance(BigDecimal closingBalance) {
        this.closingBalance = closingBalance;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public LocalDate getPaidDate() {
        return paidDate;
    }
    public void setPaidDate(LocalDate paidDate) {
        this.paidDate = paidDate;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String installmentId;
        private String appId;
        private Integer installmentNo;
        private LocalDate dueDate;
        private BigDecimal emiAmount;
        private BigDecimal principalComponent;
        private BigDecimal interestComponent;
        private BigDecimal closingBalance;
        private String status;
        private LocalDate paidDate;

        public Builder installmentId(String installmentId) {
            this.installmentId = installmentId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder installmentNo(Integer installmentNo) {
            this.installmentNo = installmentNo;
            return this;
        }
        public Builder dueDate(LocalDate dueDate) {
            this.dueDate = dueDate;
            return this;
        }
        public Builder emiAmount(BigDecimal emiAmount) {
            this.emiAmount = emiAmount;
            return this;
        }
        public Builder principalComponent(BigDecimal principalComponent) {
            this.principalComponent = principalComponent;
            return this;
        }
        public Builder interestComponent(BigDecimal interestComponent) {
            this.interestComponent = interestComponent;
            return this;
        }
        public Builder closingBalance(BigDecimal closingBalance) {
            this.closingBalance = closingBalance;
            return this;
        }
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        public Builder paidDate(LocalDate paidDate) {
            this.paidDate = paidDate;
            return this;
        }

        public EmiInstallmentDTO build() {
            return new EmiInstallmentDTO(installmentId, appId, installmentNo, dueDate, emiAmount, principalComponent, interestComponent, closingBalance, status, paidDate);
        }
    }
}
