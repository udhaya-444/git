package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.AuctionCase;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AuctionCaseRepository extends JpaRepository<AuctionCase, Long> {
    Optional<AuctionCase> findByAppIdAndDeletedAtIsNull(String appId);
    Optional<AuctionCase> findByAuctionIdAndDeletedAtIsNull(Long auctionId);
    List<AuctionCase> findByDeletedAtIsNull();
}
