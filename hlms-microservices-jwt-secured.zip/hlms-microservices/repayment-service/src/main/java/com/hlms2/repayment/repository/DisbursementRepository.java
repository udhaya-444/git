package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.Disbursement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DisbursementRepository extends JpaRepository<Disbursement, Long> {
    Optional<Disbursement> findByAppIdAndDeletedAtIsNull(String appId);
    Optional<Disbursement> findByDisbursementIdAndDeletedAtIsNull(Long disbursementId);
    List<Disbursement> findByDeletedAtIsNull();
}
