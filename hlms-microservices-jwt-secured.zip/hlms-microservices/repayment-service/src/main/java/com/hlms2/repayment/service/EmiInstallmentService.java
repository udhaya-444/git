package com.hlms2.repayment.service;

import com.hlms2.repayment.dto.EmiInstallmentDTO;

import java.util.List;
import java.util.Set;

public interface EmiInstallmentService {
    EmiInstallmentDTO create(EmiInstallmentDTO dto);
    EmiInstallmentDTO update(EmiInstallmentDTO dto);
    boolean softDelete(String installmentId);
    boolean restore(String installmentId);
    EmiInstallmentDTO findById(String installmentId);
    List<EmiInstallmentDTO> findAll();

    List<EmiInstallmentDTO> getPaymentHistory(String appId);
    Set<String> detectOverdueLoans();
    String determineEscalationLevel(String appId);
    String getDefaultStatus(String appId);
}
