package com.hlms.UserServices.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hlms.UserServices.Entity.customerEmploymentProfileEntity;
import com.hlms.UserServices.Service.customerEmploymentProfileService;

@RestController
@RequestMapping("/api/customer-profile")
public class customerEmploymentProfileController {

    @Autowired
    private customerEmploymentProfileService service;

    @PostMapping
    @PreAuthorize("hasAnyRole('CUSTOMER','ADMIN')")
    public ResponseEntity<customerEmploymentProfileEntity>
    createProfile(
            @RequestBody
            customerEmploymentProfileEntity profile) {

        return ResponseEntity.ok(
                service.createProfile(profile));
    }

    @GetMapping("/{email}")
    @PreAuthorize("hasAnyRole('CUSTOMER','LEGAL','BANK_OFFICER','ADMIN')")
    public ResponseEntity<customerEmploymentProfileEntity>
    getProfile(
            @PathVariable String email) {

        return ResponseEntity.ok(
                service.getProfile(email));
    }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('BANK_OFFICER','ADMIN')")
    public ResponseEntity<List<customerEmploymentProfileEntity>>
    getAllProfiles() {

        return ResponseEntity.ok(
                service.getAllProfiles());
    }

    @PutMapping("/{email}")
    @PreAuthorize("hasAnyRole('CUSTOMER','ADMIN')")
    public ResponseEntity<customerEmploymentProfileEntity>
    updateProfile(
            @PathVariable String email,
            @RequestBody customerEmploymentProfileEntity profile) {

        return ResponseEntity.ok(
                service.updateProfile(email, profile));
    }

    @DeleteMapping("/{email}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String>
    deleteProfile(
            @PathVariable String email) {

        service.deleteProfile(email);

        return ResponseEntity.ok(
                "Customer Profile Deleted Successfully");
    }
}