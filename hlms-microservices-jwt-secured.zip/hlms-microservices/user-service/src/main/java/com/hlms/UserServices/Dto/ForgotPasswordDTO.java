package com.hlms.UserServices.Dto;

public class ForgotPasswordDTO {

    private String email;

    public ForgotPasswordDTO() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}