package com.hlms.UserServices.Enum;

public enum roleEnum {

    CUSTOMER,
    LEGAL,
    BANK_OFFICER,
    BIDDER,
    ADMIN
}