package com.hlms.UserServices.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hlms.UserServices.Entity.customerEmploymentProfileEntity;

@Repository
public interface customerEmploymentProfileRepository
        extends JpaRepository<customerEmploymentProfileEntity, Long> {

    Optional<customerEmploymentProfileEntity>
    findByUserEmailAndDeletedAtIsNull(String userEmail);

    boolean existsByUserEmail(String userEmail);
}