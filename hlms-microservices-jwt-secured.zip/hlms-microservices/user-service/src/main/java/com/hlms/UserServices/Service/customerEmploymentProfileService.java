package com.hlms.UserServices.Service;

import java.util.List;

import com.hlms.UserServices.Entity.customerEmploymentProfileEntity;

public interface customerEmploymentProfileService {

    customerEmploymentProfileEntity createProfile(
            customerEmploymentProfileEntity profile);

    customerEmploymentProfileEntity getProfile(
            String userEmail);

    List<customerEmploymentProfileEntity> getAllProfiles();

    customerEmploymentProfileEntity updateProfile(
            String userEmail,
            customerEmploymentProfileEntity profile);

    void deleteProfile(
            String userEmail);
}
