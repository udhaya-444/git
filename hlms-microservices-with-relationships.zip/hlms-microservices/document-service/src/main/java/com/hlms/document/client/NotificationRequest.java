package com.hlms.document.client;

/** Response/request shape for notification-service's internal endpoint. */
public record NotificationRequest(String userEmail, String title, String body, java.util.List<String> channels) { }
