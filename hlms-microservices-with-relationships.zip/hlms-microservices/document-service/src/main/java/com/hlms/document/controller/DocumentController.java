package com.hlms.document.controller;
import com.hlms.document.entity.ApplicationDocument;
import com.hlms.document.service.DocumentService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;
import java.util.Map;
/** US-LA-02 Document Upload, US-LA-03 Document Validation */
@RestController
@RequestMapping("/api/documents")
public class DocumentController {
    private final DocumentService service;
    @PostMapping(value = "/{appId}/upload", consumes = "multipart/form-data")
    public ApplicationDocument upload(@PathVariable String appId,
                                       @RequestParam String docType,
                                       @RequestParam("file") MultipartFile file) {
        return service.upload(appId, docType, file);
    }
    @GetMapping("/{appId}")
    public List<ApplicationDocument> listForApp(@PathVariable String appId) {
        return service.listForApp(appId);
    }
    @GetMapping("/{appId}/missing")
    public Map<String, Object> missing(@PathVariable String appId) {
        return Map.of("appId", appId, "missingMandatoryDocs", service.missingMandatoryDocs(appId));
    }
    @GetMapping("/download/{documentId}")
    public ResponseEntity<byte[]> download(@PathVariable String documentId) {
        ApplicationDocument doc = service.get(documentId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + doc.getFileName() + "\"")
                .body(doc.getFileData());
    }
    @PreAuthorize("hasAnyRole('LEGAL','BANKOFFICE','ADMIN')")
    @PatchMapping("/{documentId}/verify")
    public ApplicationDocument verify(@PathVariable String documentId, @RequestBody Map<String, String> body) {
        return service.verify(documentId, body.get("status"), body.get("verifiedBy"), body.get("remarks"));
    }

    public DocumentController(DocumentService service) {
        this.service = service;
    }
}