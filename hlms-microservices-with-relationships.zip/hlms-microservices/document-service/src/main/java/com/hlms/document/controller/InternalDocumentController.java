package com.hlms.document.controller;

import com.hlms.document.entity.ApplicationDocument;
import com.hlms.document.repository.ApplicationDocumentRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Service-to-service endpoint (not for end users): other microservices call this
 * to check document completeness for an application - e.g. loan-service deciding
 * whether an application can move past the document-collection stage, legal-service
 * checking whether title documents are verified before recording a decision.
 * Protected by InternalApiKeyFilter instead of the normal JWT filter - see SecurityConfig.
 */
@RestController
@RequestMapping("/internal/documents")
public class InternalDocumentController {

    private final ApplicationDocumentRepository repository;

    public InternalDocumentController(ApplicationDocumentRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/application/{appId}/status")
    public DocumentStatusResponse getStatus(@PathVariable String appId) {
        List<ApplicationDocument> docs = repository.findByAppIdAndDeletedAtIsNull(appId);
        long verified = docs.stream().filter(d -> "Verified".equalsIgnoreCase(d.getVerificationStatus())).count();
        long rejected = docs.stream().filter(d -> "Rejected".equalsIgnoreCase(d.getVerificationStatus())).count();
        boolean allVerified = !docs.isEmpty() && verified == docs.size();
        return new DocumentStatusResponse(appId, docs.size(), (int) verified, (int) rejected, allVerified);
    }

    public record DocumentStatusResponse(String appId, int totalDocuments, int verifiedDocuments,
                                          int rejectedDocuments, boolean allVerified) { }
}
