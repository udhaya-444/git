package com.hlms.document.repository;

import com.hlms.document.entity.ApplicationDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ApplicationDocumentRepository extends JpaRepository<ApplicationDocument, String> {
    List<ApplicationDocument> findByAppIdAndDeletedAtIsNull(String appId);
}
