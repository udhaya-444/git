package com.hlms.legal.controller;

import com.hlms.legal.entity.LegalVerification;
import com.hlms.legal.repository.LegalVerificationRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Service-to-service endpoint (not for end users): other microservices call this
 * to check legal-verification status for an application - e.g. loan-service deciding
 * whether an application can proceed to disbursement, repayment-service checking
 * before escalating a default. Protected by InternalApiKeyFilter instead of the
 * normal JWT filter - see SecurityConfig.
 */
@RestController
@RequestMapping("/internal/legal-verifications")
public class InternalLegalVerificationController {

    private final LegalVerificationRepository repository;

    public InternalLegalVerificationController(LegalVerificationRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/application/{appId}/status")
    public LegalStatusResponse getStatus(@PathVariable String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId)
                .map(v -> new LegalStatusResponse(appId, true, v.getDecision(), v.getOfficer()))
                .orElseGet(() -> new LegalStatusResponse(appId, false, null, null));
    }

    public record LegalStatusResponse(String appId, boolean verificationExists, String decision, String officer) { }
}
