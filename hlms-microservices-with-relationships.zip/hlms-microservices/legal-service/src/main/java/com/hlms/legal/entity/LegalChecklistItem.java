package com.hlms.legal.entity;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name = "legal_checklist_item")
public class LegalChecklistItem {
    @Id
    @Column(name = "checklist_item_id", length = 50)
    private String checklistItemId;
    @Column(name = "app_id", nullable = false)
    private String appId;
    @Column(name = "checklist_key", length = 100, nullable = false)
    private String checklistKey;
    @Column(name = "status", length = 30, nullable = false)
    private String status = "Pending";
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public LegalChecklistItem() {
    }

    public LegalChecklistItem(String checklistItemId, String appId, String checklistKey, String status, OffsetDateTime deletedAt) {
        this.checklistItemId = checklistItemId;
        this.appId = appId;
        this.checklistKey = checklistKey;
        this.status = status;
        this.deletedAt = deletedAt;
    }

    public String getChecklistItemId() {
        return checklistItemId;
    }
    public void setChecklistItemId(String checklistItemId) {
        this.checklistItemId = checklistItemId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getChecklistKey() {
        return checklistKey;
    }
    public void setChecklistKey(String checklistKey) {
        this.checklistKey = checklistKey;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String checklistItemId;
        private String appId;
        private String checklistKey;
        private String status = "Pending";
        private OffsetDateTime deletedAt;

        public Builder checklistItemId(String checklistItemId) {
            this.checklistItemId = checklistItemId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder checklistKey(String checklistKey) {
            this.checklistKey = checklistKey;
            return this;
        }
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public LegalChecklistItem build() {
            return new LegalChecklistItem(checklistItemId, appId, checklistKey, status, deletedAt);
        }
    }
}