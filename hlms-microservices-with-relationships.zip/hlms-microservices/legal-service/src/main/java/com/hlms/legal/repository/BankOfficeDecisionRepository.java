package com.hlms.legal.repository;

import com.hlms.legal.entity.BankOfficeDecision;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface BankOfficeDecisionRepository extends JpaRepository<BankOfficeDecision, Long> {
    Optional<BankOfficeDecision> findByAppIdAndDeletedAtIsNull(String appId);
}
