package com.hlms.legal.repository;

import com.hlms.legal.entity.LegalVerification;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface LegalVerificationRepository extends JpaRepository<LegalVerification, Long> {
    Optional<LegalVerification> findByAppIdAndDeletedAtIsNull(String appId);
}
