package com.hlms.legal.service;
import com.hlms.legal.client.ApplicationSummaryResponse;
import com.hlms.legal.client.LoanApplicationClient;
import com.hlms.legal.client.NotificationClient;
import com.hlms.legal.client.NotificationRequest;
import com.hlms.legal.entity.LegalNotice;
import com.hlms.legal.repository.LegalNoticeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
/** Backs feature "10. Default Management and Notice Generation". */
@Service
public class LegalNoticeService {
    private static final Logger log = LoggerFactory.getLogger(LegalNoticeService.class);
    private final LegalNoticeRepository repository;
    private final LoanApplicationClient loanApplicationClient;
    private final NotificationClient notificationClient;
    @Transactional
    public LegalNotice generateNotice(String appId, String noticeType, String officer, String content, LocalDate dueDate) {
        // Pull applicant context from loan-service (over Feign) so a notice can be
        // auto-drafted even if the caller (e.g. repayment-service's default sweep)
        // didn't pass explicit content, and so we know who to notify below.
        ApplicationSummaryResponse application = null;
        try {
            application = loanApplicationClient.getApplication(appId);
        } catch (Exception ex) {
            log.warn("Could not fetch application {} from loan-service while generating a notice: {}", appId, ex.getMessage());
        }
        String resolvedContent = (content == null || content.isBlank()) && application != null
                ? "Notice regarding loan application " + appId + " (" + application.applicantName() + "): "
                        + noticeType + " - please respond by " + dueDate + "."
                : content;
        LegalNotice notice = LegalNotice.builder()
                .noticeId("NOTICE-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .noticeNo("NO-" + System.currentTimeMillis())
                .appId(appId)
                .noticeType(noticeType)
                .issueDate(LocalDate.now())
                .dueDate(dueDate)
                .status("Active")
                .officer(officer)
                .content(resolvedContent)
                .build();
        LegalNotice saved = repository.save(notice);

        // Best-effort auto-notification to the borrower via notification-service; a failure
        // here must never roll back the notice itself, so it's caught and logged only.
        if (application != null && application.userEmail() != null) {
            try {
                notificationClient.send(new NotificationRequest(application.userEmail(),
                        "Legal notice issued: " + noticeType,
                        resolvedContent, List.of("email", "inapp")));
            } catch (Exception ex) {
                log.warn("Could not send notification for notice on application {}: {}", appId, ex.getMessage());
            }
        }
        return saved;
    }
    public List<LegalNotice> listForApp(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId);
    }
    @Transactional
    public LegalNotice updateStatus(String noticeId, String status) {
        LegalNotice notice = repository.findById(noticeId).orElseThrow();
        notice.setStatus(status); // Sent, Delivered, Failed (US-DMNG-03 Notice Tracking)
        return repository.save(notice);
    }

    public LegalNoticeService(LegalNoticeRepository repository, LoanApplicationClient loanApplicationClient, NotificationClient notificationClient) {
        this.repository = repository;
        this.loanApplicationClient = loanApplicationClient;
        this.notificationClient = notificationClient;
    }
}