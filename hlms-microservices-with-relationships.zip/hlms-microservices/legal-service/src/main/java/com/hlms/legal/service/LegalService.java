package com.hlms.legal.service;
import com.hlms.legal.entity.LegalChecklistItem;
import com.hlms.legal.entity.LegalVerification;
import com.hlms.legal.exception.ResourceNotFoundException;
import com.hlms.legal.repository.LegalChecklistItemRepository;
import com.hlms.legal.repository.LegalVerificationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
/** Backs the legal-verification stage of the loan workflow. */
@Service
public class LegalService {
    private final LegalVerificationRepository verificationRepository;
    private final LegalChecklistItemRepository checklistRepository;
    public LegalVerification getVerification(String appId) {
        return verificationRepository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseThrow(() -> new ResourceNotFoundException("No legal verification record for app: " + appId));
    }
    public List<LegalChecklistItem> getChecklist(String appId) {
        return checklistRepository.findByAppIdAndDeletedAtIsNull(appId);
    }
    @Transactional
    public LegalVerification recordDecision(String appId, String decision, String officer, String remarks) {
        LegalVerification verification = verificationRepository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseGet(() -> LegalVerification.builder().appId(appId).build());
        verification.setDecision(decision);
        verification.setOfficer(officer);
        verification.setRemarks(remarks);
        verification.setDecisionDate(OffsetDateTime.now());
        return verificationRepository.save(verification);
    }
    /** Legal officer requests additional documents/info from the customer. */
    @Transactional
    public LegalVerification requestInfo(String appId, String details) {
        LegalVerification verification = verificationRepository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseGet(() -> LegalVerification.builder().appId(appId).build());
        verification.setInfoRequested(true);
        verification.setInfoRequestDetails(details);
        verification.setInfoRequestedAt(OffsetDateTime.now());
        return verificationRepository.save(verification);
    }
    @Transactional
    public LegalChecklistItem upsertChecklistItem(String appId, String checklistKey, String status) {
        LegalChecklistItem item = checklistRepository.findByAppIdAndDeletedAtIsNull(appId).stream()
                .filter(i -> i.getChecklistKey().equals(checklistKey))
                .findFirst()
                .orElseGet(() -> LegalChecklistItem.builder()
                        .checklistItemId("CHK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                        .appId(appId)
                        .checklistKey(checklistKey)
                        .build());
        item.setStatus(status);
        return checklistRepository.save(item);
    }

    public LegalService(LegalVerificationRepository verificationRepository, LegalChecklistItemRepository checklistRepository) {
        this.verificationRepository = verificationRepository;
        this.checklistRepository = checklistRepository;
    }
}