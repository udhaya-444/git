package com.hlms.loan.client;

import feign.RequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Attaches the shared internal API key to every outgoing Feign call so the callee
 * service's /internal/** endpoints (which skip normal JWT auth, since these calls
 * happen from scheduled jobs / system flows with no logged-in user) can verify the
 * caller is a trusted internal service and not a public client.
 */
@Configuration
public class FeignClientConfig {

    @Value("${hlms.internal.api-key}")
    private String internalApiKey;

    @Bean
    public RequestInterceptor internalApiKeyInterceptor() {
        return requestTemplate -> requestTemplate.header("X-Internal-Api-Key", internalApiKey);
    }
}
