package com.hlms.loan.controller;
import com.hlms.loan.dto.MortgageCalculationRequest;
import com.hlms.loan.dto.MortgageCalculationResponse;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.service.MortgageService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Map;
/**
 * US-MRC-01..05 Mortgage Requirement Calculation - previously entirely unbuilt.
 */
@RestController
@RequestMapping("/api/mortgage")
public class MortgageController {
    private final MortgageService service;
    /** Stateless "what-if" calculator - no appId required, mirrors /eligibility/simulate. */
    @PostMapping("/calculate")
    public MortgageCalculationResponse calculate(@Valid @RequestBody MortgageCalculationRequest req) {
        return service.calculate(req);
    }
    /** Runs the calculation against a real application's own figures and persists the result
     *  into that application's record (US-MRC-05). */
    @PostMapping("/{appId}/calculate")
    public MortgageCalculationResponse calculateForApplication(@PathVariable String appId,
                                                                @RequestParam(required = false) String actorEmail) {
        return service.calculateForApplication(appId, actorEmail);
    }
    @PreAuthorize("hasAnyRole('BANKOFFICE','LEGAL','ADMIN')")
    @PostMapping("/{appId}/evaluate-property")
    public LoanApplication evaluateProperty(@PathVariable String appId, @RequestBody Map<String, Object> body,
                                             @RequestParam(required = false) String actorEmail) {
        BigDecimal propertyValue = new BigDecimal(body.get("propertyValue").toString());
        String propertyType = (String) body.get("propertyType");
        String notes = (String) body.get("notes");
        return service.evaluateProperty(appId, propertyValue, propertyType, notes, actorEmail);
    }
    @GetMapping("/{appId}")
    public Map<String, Object> getMortgageRecord(@PathVariable String appId) {
        return service.getMortgageRecord(appId);
    }

    public MortgageController(MortgageService service) {
        this.service = service;
    }
}