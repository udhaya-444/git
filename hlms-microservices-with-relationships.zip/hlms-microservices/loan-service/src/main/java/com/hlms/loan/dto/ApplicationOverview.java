package com.hlms.loan.dto;

import com.hlms.loan.client.DocumentStatusResponse;
import com.hlms.loan.client.LegalStatusResponse;
import com.hlms.loan.client.RepaymentSummaryResponse;
import com.hlms.loan.client.UserSummaryResponse;

/**
 * Cross-service snapshot for a single loan application, aggregated live from
 * user-service, document-service, legal-service, and repayment-service via
 * their /internal/** Feign clients (see com.hlms.loan.client). Any field may
 * be null if the callee had nothing to report yet (e.g. no documents uploaded,
 * no legal verification started) - that's a normal, not-yet-reached state,
 * not a failure.
 */
public record ApplicationOverview(
        String appId,
        String status,
        UserSummaryResponse applicant,
        DocumentStatusResponse documentStatus,
        LegalStatusResponse legalStatus,
        RepaymentSummaryResponse repaymentStatus
) { }
