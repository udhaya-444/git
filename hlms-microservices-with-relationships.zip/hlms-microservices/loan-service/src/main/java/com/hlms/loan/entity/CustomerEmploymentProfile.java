package com.hlms.loan.entity;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name = "customer_employment_profile")
public class CustomerEmploymentProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "profile_id")
    private Long profileId;
    @Column(name = "user_email", nullable = false, unique = true)
    private String userEmail;
    @Column(name = "employment_type", length = 30)
    private String employmentType;
    @Column(name = "employer", length = 150)
    private String employer;
    @Column(name = "monthly_income", precision = 14, scale = 2)
    private BigDecimal monthlyIncome;
    @Column(name = "other_emis", precision = 14, scale = 2)
    private BigDecimal otherEmis;
    @Column(name = "desired_amount", precision = 14, scale = 2)
    private BigDecimal desiredAmount;
    @Column(name = "pan", length = 20)
    private String pan;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    // Read-only navigation to the owning user; "userEmail" above stays the writable FK column.
    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_email", referencedColumnName = "email", insertable = false, updatable = false)
    private AppUser user;


    public CustomerEmploymentProfile() {
    }

    public CustomerEmploymentProfile(Long profileId, String userEmail, String employmentType, String employer, BigDecimal monthlyIncome, BigDecimal otherEmis, BigDecimal desiredAmount, String pan, OffsetDateTime deletedAt) {
        this.profileId = profileId;
        this.userEmail = userEmail;
        this.employmentType = employmentType;
        this.employer = employer;
        this.monthlyIncome = monthlyIncome;
        this.otherEmis = otherEmis;
        this.desiredAmount = desiredAmount;
        this.pan = pan;
        this.deletedAt = deletedAt;
    }

    public Long getProfileId() {
        return profileId;
    }
    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }
    public String getUserEmail() {
        return userEmail;
    }
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    public String getEmploymentType() {
        return employmentType;
    }
    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }
    public String getEmployer() {
        return employer;
    }
    public void setEmployer(String employer) {
        this.employer = employer;
    }
    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }
    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }
    public BigDecimal getOtherEmis() {
        return otherEmis;
    }
    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }
    public BigDecimal getDesiredAmount() {
        return desiredAmount;
    }
    public void setDesiredAmount(BigDecimal desiredAmount) {
        this.desiredAmount = desiredAmount;
    }
    public String getPan() {
        return pan;
    }
    public void setPan(String pan) {
        this.pan = pan;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }
    public AppUser getUser() {
        return user;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private Long profileId;
        private String userEmail;
        private String employmentType;
        private String employer;
        private BigDecimal monthlyIncome;
        private BigDecimal otherEmis;
        private BigDecimal desiredAmount;
        private String pan;
        private OffsetDateTime deletedAt;

        public Builder profileId(Long profileId) {
            this.profileId = profileId;
            return this;
        }
        public Builder userEmail(String userEmail) {
            this.userEmail = userEmail;
            return this;
        }
        public Builder employmentType(String employmentType) {
            this.employmentType = employmentType;
            return this;
        }
        public Builder employer(String employer) {
            this.employer = employer;
            return this;
        }
        public Builder monthlyIncome(BigDecimal monthlyIncome) {
            this.monthlyIncome = monthlyIncome;
            return this;
        }
        public Builder otherEmis(BigDecimal otherEmis) {
            this.otherEmis = otherEmis;
            return this;
        }
        public Builder desiredAmount(BigDecimal desiredAmount) {
            this.desiredAmount = desiredAmount;
            return this;
        }
        public Builder pan(String pan) {
            this.pan = pan;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public CustomerEmploymentProfile build() {
            return new CustomerEmploymentProfile(profileId, userEmail, employmentType, employer, monthlyIncome, otherEmis, desiredAmount, pan, deletedAt);
        }
    }
}