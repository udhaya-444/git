package com.hlms.loan.service;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hlms.loan.entity.AuditLog;
import com.hlms.loan.repository.AuditLogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Map;
/**
 * Central place that writes to the existing `audit_log` table.
 *
 * No schema change: audit_log already exists in the v2 schema with exactly the
 * columns used here (entity_type, entity_id, action, actor_email, before_data,
 * after_data, created_at). This service is what was missing - something that
 * actually calls repository.save() on every meaningful state change.
 *
 * Beyond compliance/traceability, this doubles as the data source for:
 *  - workflow timeline (StatusTrackingService reconstructs stage history from
 *    the loan_application audit trail instead of needing a new "history" table)
 *  - turnaround-time / SLA reporting (gaps between consecutive audit rows)
 *  - default-management escalation state (see DefaultManagementService, which
 *    reads the last ESCALATION audit row instead of persisting an escalation
 *    level column that doesn't exist in the schema)
 */
@Service
public class AuditService {
    private final AuditLogRepository repository;
    private final ObjectMapper objectMapper;
    /** Runs in its own transaction so an audit failure never rolls back the business change it's logging,
     *  and a business rollback never discards the audit trail of what was attempted. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void record(String entityType, String entityId, String action, String actorEmail,
                        Map<String, Object> before, Map<String, Object> after) {
        AuditLog log = AuditLog.builder()
                .entityType(entityType)
                .entityId(entityId)
                .action(action)
                .actorEmail(actorEmail)
                .beforeData(toJson(before))
                .afterData(toJson(after))
                .build();
        repository.save(log);
    }
    public List<AuditLog> history(String entityType, String entityId) {
        return repository.findByEntityTypeAndEntityIdOrderByCreatedAtDesc(entityType, entityId);
    }
    /** History in chronological order (oldest first) - what timeline/SLA calculations actually want. */
    public List<AuditLog> historyChronological(String entityType, String entityId) {
        List<AuditLog> chronological = new java.util.ArrayList<>(history(entityType, entityId));
        java.util.Collections.reverse(chronological);
        return chronological;
    }
    private String toJson(Map<String, Object> data) {
        if (data == null) return null;
        try {
            return objectMapper.writeValueAsString(data);
        } catch (Exception e) {
            return "{}";
        }
    }

    public AuditService(AuditLogRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
    }
}