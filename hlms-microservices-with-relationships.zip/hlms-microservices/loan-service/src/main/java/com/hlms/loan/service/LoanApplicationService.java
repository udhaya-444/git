package com.hlms.loan.service;
import com.hlms.loan.dto.SubmitApplicationRequest;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.exception.BadRequestException;
import com.hlms.loan.exception.ResourceNotFoundException;
import com.hlms.loan.repository.LoanApplicationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.UUID;
/**
 * Backs feature "4. Digital Loan Application Management" and
 * "5. Loan Status Tracking & Workflow Visibility".
 */
@Service
public class LoanApplicationService {
    private final LoanApplicationRepository repository;
    private final AuditService auditService;
    private static final List<String> WORKFLOW_STAGES = List.of(
            "Draft", "Submitted", "Document Verification", "Legal Verification",
            "Bank Office Decision", "Disbursement", "Active"
    );
    public List<LoanApplication> listForUser(String userEmail) {
        return repository.findByUserEmailAndDeletedAtIsNull(userEmail);
    }
    public List<LoanApplication> listAll() {
        return repository.findByDeletedAtIsNull();
    }
    /** Paginated/sortable variants (cross-cutting gap). */
    public org.springframework.data.domain.Page<LoanApplication> listAll(org.springframework.data.domain.Pageable pageable) {
        return repository.findByDeletedAtIsNull(pageable);
    }
    public org.springframework.data.domain.Page<LoanApplication> listForUser(String userEmail, org.springframework.data.domain.Pageable pageable) {
        return repository.findByUserEmailAndDeletedAtIsNull(userEmail, pageable);
    }
    public LoanApplication get(String appId) {
        return repository.findById(appId)
                .filter(a -> a.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Loan application not found: " + appId));
    }
    public LoanApplication getByTrackingNo(String trackingNo) {
        return repository.findByTrackingNoAndDeletedAtIsNull(trackingNo)
                .orElseThrow(() -> new ResourceNotFoundException("No application found for tracking number: " + trackingNo));
    }
    /** US-LA-06 Draft Saving: create-or-update a draft, identified by appId if provided. */
    @Transactional
    public LoanApplication saveDraft(String appId, String userEmail, SubmitApplicationRequest req, int currentStep) {
        boolean isNew = appId == null;
        LoanApplication app = (appId != null)
                ? get(appId)
                : LoanApplication.builder().appId(generateAppId()).userEmail(userEmail).status("Draft").build();
        applyFields(app, req);
        app.setCurrentStep(currentStep);
        if (app.getStatus() == null) app.setStatus("Draft");
        LoanApplication saved = repository.save(app);
        if (isNew) {
            auditService.record("loan_application", saved.getAppId(), "CREATE", userEmail,
                    null, Map.of("status", saved.getStatus(), "stageIndex", saved.getStageIndex()));
        }
        return saved;
    }
    /** US-LA-01/03/05: validates required fields, then submits and assigns a tracking number. */
    @Transactional
    public LoanApplication submit(String appId) {
        LoanApplication app = get(appId);
        validateForSubmission(app);
        String prevStatus = app.getStatus();
        int prevStage = app.getStageIndex();
        app.setStatus("Submitted");
        app.setStageIndex(1);
        if (app.getTrackingNo() == null) {
            app.setTrackingNo(generateTrackingNo());
        }
        LoanApplication saved = repository.save(app);
        auditService.record("loan_application", appId, "SUBMIT", app.getUserEmail(),
                Map.of("status", prevStatus, "stageIndex", prevStage),
                Map.of("status", saved.getStatus(), "stageIndex", saved.getStageIndex(), "trackingNo", saved.getTrackingNo()));
        return saved;
    }
    @Transactional
    public LoanApplication updateStage(String appId, int stageIndex, String status) {
        return updateStage(appId, stageIndex, status, null);
    }
    /** Same as updateStage(appId, stageIndex, status) but records who/which role made the change,
     *  which is what powers "current stakeholder" tracking (US-LT-03) without a new column -
     *  we simply read it back out of the audit trail. */
    @Transactional
    public LoanApplication updateStage(String appId, int stageIndex, String status, String actorEmail) {
        LoanApplication app = get(appId);
        String prevStatus = app.getStatus();
        int prevStage = app.getStageIndex();
        app.setStageIndex(stageIndex);
        if (status != null) app.setStatus(status);
        LoanApplication saved = repository.save(app);
        auditService.record("loan_application", appId, "STAGE_CHANGE", actorEmail,
                Map.of("status", prevStatus, "stageIndex", prevStage),
                Map.of("status", saved.getStatus(), "stageIndex", saved.getStageIndex()));
        return saved;
    }
    @Transactional
    public void withdraw(String appId) {
        LoanApplication app = get(appId);
        app.setDeletedAt(OffsetDateTime.now());
        repository.save(app);
        // Note: in Postgres, the trg_cascade_soft_delete_loan_application trigger
        // handles cascading the soft-delete to documents, decisions, EMIs, etc.
        auditService.record("loan_application", appId, "WITHDRAW", app.getUserEmail(),
                Map.of("status", app.getStatus()), Map.of("deletedAt", app.getDeletedAt().toString()));
    }
    public List<String> workflowStages() {
        return WORKFLOW_STAGES;
    }
    private void validateForSubmission(LoanApplication app) {
        if (app.getProductId() == null) throw new BadRequestException("Select a loan product before submitting.");
        if (app.getLoanAmount() == null || app.getLoanAmount().signum() <= 0)
            throw new BadRequestException("Loan amount must be greater than zero.");
        if (app.getTenureYears() == null || app.getTenureYears() <= 0)
            throw new BadRequestException("Tenure (years) is required.");
        if (app.getApplicantName() == null || app.getApplicantPan() == null)
            throw new BadRequestException("Applicant name and PAN are required.");
    }
    private void applyFields(LoanApplication app, SubmitApplicationRequest req) {
        if (req.getProductId() != null) app.setProductId(req.getProductId());
        if (req.getLoanAmount() != null) app.setLoanAmount(req.getLoanAmount());
        if (req.getTenureYears() != null) app.setTenureYears(req.getTenureYears());
        if (req.getPurpose() != null) app.setPurpose(req.getPurpose());
        if (req.getApplicantName() != null) app.setApplicantName(req.getApplicantName());
        if (req.getApplicantMobile() != null) app.setApplicantMobile(req.getApplicantMobile());
        if (req.getApplicantPan() != null) app.setApplicantPan(req.getApplicantPan());
        if (req.getAddrDoorNo() != null) app.setAddrDoorNo(req.getAddrDoorNo());
        if (req.getAddrStreet() != null) app.setAddrStreet(req.getAddrStreet());
        if (req.getAddrCity() != null) app.setAddrCity(req.getAddrCity());
        if (req.getAddrState() != null) app.setAddrState(req.getAddrState());
        if (req.getAddrPincode() != null) app.setAddrPincode(req.getAddrPincode());
        if (req.getEmploymentType() != null) app.setEmploymentType(req.getEmploymentType());
        if (req.getEmployer() != null) app.setEmployer(req.getEmployer());
        if (req.getMonthlyIncome() != null) app.setMonthlyIncome(req.getMonthlyIncome());
        if (req.getOtherEmis() != null) app.setOtherEmis(req.getOtherEmis());
        if (req.getPropertyAddress() != null) app.setPropertyAddress(req.getPropertyAddress());
        if (req.getPropertyType() != null) app.setPropertyType(req.getPropertyType());
        if (req.getPropertyValue() != null) app.setPropertyValue(req.getPropertyValue());
    }
    private String generateAppId() {
        return "APP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
    private String generateTrackingNo() {
        String datePart = OffsetDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        return "TRK-" + datePart + "-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
    }

    public LoanApplicationService(LoanApplicationRepository repository, AuditService auditService) {
        this.repository = repository;
        this.auditService = auditService;
    }
}