package com.hlms.repayment.controller;
import com.hlms.repayment.entity.EmiInstallment;
import com.hlms.repayment.service.EmiService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
/** Feature 7: Loan Repayment Monitoring (US-LRM-01..05) */
@RestController
@RequestMapping("/api/emi")
public class EmiController {
    private final EmiService service;
    @PostMapping("/{appId}/generate-schedule")
    public List<EmiInstallment> generate(@PathVariable String appId, @RequestBody Map<String, Object> body) {
        BigDecimal principal = new BigDecimal(body.get("principal").toString());
        BigDecimal rate = new BigDecimal(body.get("annualRatePercent").toString());
        int tenureYears = Integer.parseInt(body.get("tenureYears").toString());
        LocalDate firstDueDate = LocalDate.parse(body.get("firstDueDate").toString());
        return service.generateSchedule(appId, principal, rate, tenureYears, firstDueDate);
    }
    @GetMapping("/{appId}/schedule")
    public List<EmiInstallment> schedule(@PathVariable String appId) {
        return service.getSchedule(appId);
    }
    @GetMapping("/{appId}/outstanding-balance")
    public Map<String, Object> outstanding(@PathVariable String appId) {
        return Map.of("appId", appId, "outstandingBalance", service.outstandingBalance(appId));
    }
    @PostMapping("/installments/{installmentId}/pay")
    public EmiInstallment pay(@PathVariable String installmentId, @RequestParam(required = false) String paidDate) {
        LocalDate date = paidDate != null ? LocalDate.parse(paidDate) : LocalDate.now();
        return service.recordPayment(installmentId, date);
    }
    // US-DMNG-01: run manually or wire to a @Scheduled job for nightly execution.
    @PreAuthorize("hasAnyRole('BANKOFFICE','ADMIN')")
    @PostMapping("/mark-overdue")
    public Map<String, Object> markOverdue() {
        return Map.of("updatedCount", service.markOverdueInstallments());
    }

    public EmiController(EmiService service) {
        this.service = service;
    }
}