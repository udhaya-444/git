package com.hlms.repayment.dto;

/**
 * US-DMNG-05 Default Status Monitoring.
 * escalationLevel is computed on the fly from emi_installment rows - not stored,
 * since the schema has no escalation-level column and none may be added.
 *  0 = current, 1 = reminder, 2 = warning notice, 3 = legal notice / SARFAESI trigger, 4 = auction referral
 */
public record DefaultStatus(
        String appId,
        String userEmail,
        int overdueInstallmentCount,
        long maxDaysOverdue,
        int escalationLevel,
        String escalationLabel,
        String recommendedAction
) {}
