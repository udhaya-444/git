package com.hlms.repayment.entity;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.time.OffsetDateTime;
import com.fasterxml.jackson.annotation.JsonIgnore;
// Intentionally has no deleted_at: an audit trail must remain permanent.
@Entity
@Table(name = "audit_log")
public class AuditLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "log_id")
    private Long logId;
    @Column(name = "entity_type", length = 50, nullable = false)
    private String entityType;
    @Column(name = "entity_id", length = 50, nullable = false)
    private String entityId;
    @Column(name = "action", length = 30, nullable = false)
    private String action;
    @Column(name = "actor_email")
    private String actorEmail;
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "before_data", columnDefinition = "jsonb")
    private String beforeData;
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "after_data", columnDefinition = "jsonb")
    private String afterData;
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;
    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }

    // Read-only navigation to the acting user; "actorEmail" above stays the writable FK column.
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "actor_email", referencedColumnName = "email", insertable = false, updatable = false)
    private AppUser actor;


    public AuditLog() {
    }

    public AuditLog(Long logId, String entityType, String entityId, String action, String actorEmail, String beforeData, String afterData, OffsetDateTime createdAt) {
        this.logId = logId;
        this.entityType = entityType;
        this.entityId = entityId;
        this.action = action;
        this.actorEmail = actorEmail;
        this.beforeData = beforeData;
        this.afterData = afterData;
        this.createdAt = createdAt;
    }

    public Long getLogId() {
        return logId;
    }
    public void setLogId(Long logId) {
        this.logId = logId;
    }
    public String getEntityType() {
        return entityType;
    }
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }
    public String getEntityId() {
        return entityId;
    }
    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
    public String getActorEmail() {
        return actorEmail;
    }
    public void setActorEmail(String actorEmail) {
        this.actorEmail = actorEmail;
    }
    public String getBeforeData() {
        return beforeData;
    }
    public void setBeforeData(String beforeData) {
        this.beforeData = beforeData;
    }
    public String getAfterData() {
        return afterData;
    }
    public void setAfterData(String afterData) {
        this.afterData = afterData;
    }
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public AppUser getActor() {
        return actor;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private Long logId;
        private String entityType;
        private String entityId;
        private String action;
        private String actorEmail;
        private String beforeData;
        private String afterData;
        private OffsetDateTime createdAt;

        public Builder logId(Long logId) {
            this.logId = logId;
            return this;
        }
        public Builder entityType(String entityType) {
            this.entityType = entityType;
            return this;
        }
        public Builder entityId(String entityId) {
            this.entityId = entityId;
            return this;
        }
        public Builder action(String action) {
            this.action = action;
            return this;
        }
        public Builder actorEmail(String actorEmail) {
            this.actorEmail = actorEmail;
            return this;
        }
        public Builder beforeData(String beforeData) {
            this.beforeData = beforeData;
            return this;
        }
        public Builder afterData(String afterData) {
            this.afterData = afterData;
            return this;
        }
        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public AuditLog build() {
            return new AuditLog(logId, entityType, entityId, action, actorEmail, beforeData, afterData, createdAt);
        }
    }
}