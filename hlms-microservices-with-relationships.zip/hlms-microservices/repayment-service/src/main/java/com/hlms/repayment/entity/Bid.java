package com.hlms.repayment.entity;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name = "bid")
public class Bid {
    @Id
    @Column(name = "bid_id", length = 50)
    private String bidId;
    // References auction_case.app_id
    @Column(name = "app_id", nullable = false)
    private String appId;
    @Column(name = "bidder_email", nullable = false)
    private String bidderEmail;
    @Column(name = "bid_amount", precision = 14, scale = 2, nullable = false)
    private BigDecimal bidAmount;
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }

    // --- Relationships (read-only navigation; the FK columns above stay the writable source of truth) ---
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "app_id", referencedColumnName = "app_id", insertable = false, updatable = false)
    private AuctionCase auctionCase;
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bidder_email", referencedColumnName = "email", insertable = false, updatable = false)
    private AppUser bidder;


    public Bid() {
    }

    public Bid(String bidId, String appId, String bidderEmail, BigDecimal bidAmount, OffsetDateTime createdAt, OffsetDateTime deletedAt) {
        this.bidId = bidId;
        this.appId = appId;
        this.bidderEmail = bidderEmail;
        this.bidAmount = bidAmount;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    public String getBidId() {
        return bidId;
    }
    public void setBidId(String bidId) {
        this.bidId = bidId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getBidderEmail() {
        return bidderEmail;
    }
    public void setBidderEmail(String bidderEmail) {
        this.bidderEmail = bidderEmail;
    }
    public BigDecimal getBidAmount() {
        return bidAmount;
    }
    public void setBidAmount(BigDecimal bidAmount) {
        this.bidAmount = bidAmount;
    }
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }
    public AuctionCase getAuctionCase() {
        return auctionCase;
    }
    public AppUser getBidder() {
        return bidder;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String bidId;
        private String appId;
        private String bidderEmail;
        private BigDecimal bidAmount;
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        public Builder bidId(String bidId) {
            this.bidId = bidId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder bidderEmail(String bidderEmail) {
            this.bidderEmail = bidderEmail;
            return this;
        }
        public Builder bidAmount(BigDecimal bidAmount) {
            this.bidAmount = bidAmount;
            return this;
        }
        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public Bid build() {
            return new Bid(bidId, appId, bidderEmail, bidAmount, createdAt, deletedAt);
        }
    }
}