package com.hlms.repayment.entity;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name = "insurance_policy")
public class InsurancePolicy {
    @Id
    @Column(name = "policy_id", length = 50)
    private String policyId;
    @Column(name = "app_id", nullable = false)
    private String appId;
    @Column(name = "policy_type", length = 50)
    private String policyType; // property, life
    @Column(name = "status", length = 30, nullable = false)
    private String status = "Active";
    @Column(name = "valid_till")
    private LocalDate validTill;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    // Read-only navigation to the parent loan application; "appId" above stays the writable FK column.
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "app_id", referencedColumnName = "app_id", insertable = false, updatable = false)
    private LoanApplication loanApplication;


    public InsurancePolicy() {
    }

    public InsurancePolicy(String policyId, String appId, String policyType, String status, LocalDate validTill, OffsetDateTime deletedAt) {
        this.policyId = policyId;
        this.appId = appId;
        this.policyType = policyType;
        this.status = status;
        this.validTill = validTill;
        this.deletedAt = deletedAt;
    }

    public String getPolicyId() {
        return policyId;
    }
    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getPolicyType() {
        return policyType;
    }
    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public LocalDate getValidTill() {
        return validTill;
    }
    public void setValidTill(LocalDate validTill) {
        this.validTill = validTill;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }
    public LoanApplication getLoanApplication() {
        return loanApplication;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String policyId;
        private String appId;
        private String policyType;
        private String status = "Active";
        private LocalDate validTill;
        private OffsetDateTime deletedAt;

        public Builder policyId(String policyId) {
            this.policyId = policyId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder policyType(String policyType) {
            this.policyType = policyType;
            return this;
        }
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        public Builder validTill(LocalDate validTill) {
            this.validTill = validTill;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public InsurancePolicy build() {
            return new InsurancePolicy(policyId, appId, policyType, status, validTill, deletedAt);
        }
    }
}