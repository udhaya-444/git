package com.hlms.repayment.repository;

import com.hlms.repayment.entity.EmiInstallment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface EmiInstallmentRepository extends JpaRepository<EmiInstallment, String> {
    List<EmiInstallment> findByAppIdAndDeletedAtIsNullOrderByInstallmentNoAsc(String appId);
    List<EmiInstallment> findByStatusAndDeletedAtIsNull(String status);
    List<EmiInstallment> findByStatusAndDueDateBetweenAndDeletedAtIsNull(String status, LocalDate from, LocalDate to);
}
