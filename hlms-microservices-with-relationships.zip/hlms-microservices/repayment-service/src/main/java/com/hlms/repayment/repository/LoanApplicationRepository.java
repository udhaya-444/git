package com.hlms.repayment.repository;

import com.hlms.repayment.entity.LoanApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface LoanApplicationRepository extends JpaRepository<LoanApplication, String> {
    List<LoanApplication> findByUserEmailAndDeletedAtIsNull(String userEmail);
    List<LoanApplication> findByDeletedAtIsNull();
    List<LoanApplication> findByStatusAndDeletedAtIsNull(String status);
    Optional<LoanApplication> findByTrackingNoAndDeletedAtIsNull(String trackingNo);

    // Cross-cutting: paginated/sortable variants for the list endpoints.
    Page<LoanApplication> findByDeletedAtIsNull(Pageable pageable);
    Page<LoanApplication> findByUserEmailAndDeletedAtIsNull(String userEmail, Pageable pageable);
}
