package com.hlms.user.client;

/** Response/request shape for loan-service's internal endpoint. */
public record ApplicationSummaryResponse(String appId, String trackingNo, String userEmail, String productId, java.math.BigDecimal loanAmount, String status, String applicantName, String applicantMobile) { }
