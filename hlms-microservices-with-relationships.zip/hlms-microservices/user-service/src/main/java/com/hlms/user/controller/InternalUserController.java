package com.hlms.user.controller;

import com.hlms.user.entity.AppUser;
import com.hlms.user.repository.AppUserRepository;
import com.hlms.user.exception.ResourceNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Service-to-service endpoint (not for end users): other microservices call this
 * to resolve basic borrower/officer identity (name, mobile, role) for an email
 * they already hold (e.g. loan-service showing an applicant's name, document-service
 * showing who uploaded a file) without duplicating user data or depending on
 * user-service's internal code. Protected by InternalApiKeyFilter instead of the
 * normal JWT filter - see SecurityConfig.
 */
@RestController
@RequestMapping("/internal/users")
public class InternalUserController {

    private final AppUserRepository repository;

    public InternalUserController(AppUserRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/{email}")
    public UserSummaryResponse getUser(@PathVariable String email) {
        AppUser user = repository.findByEmailAndDeletedAtIsNull(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + email));
        return new UserSummaryResponse(user.getEmail(), user.getName(), user.getMobile(),
                user.getRole(), user.isActive());
    }

    public record UserSummaryResponse(String email, String name, String mobile, String role, Boolean active) { }
}
