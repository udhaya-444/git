package com.hlms.user.dto;

public record AuthResponse(String email, String name, String role, String message, String token) {
    public static AuthResponse withoutToken(String email, String name, String role, String message) {
        return new AuthResponse(email, name, role, message, null);
    }
}
