package com.hlms.user.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name = "otp_verification")
public class OtpVerification {
    @Id
    @Column(name = "otp_id", length = 50)
    private String otpId;
    @Column(name = "email", nullable = false)
    private String email;
    @Column(name = "otp_code", length = 10, nullable = false)
    private String otpCode;
    @Column(name = "purpose", length = 30, nullable = false)
    private String purpose = "LOGIN";
    @Column(name = "expires_at", nullable = false)
    private OffsetDateTime expiresAt;
    @Column(name = "consumed", nullable = false)
    private Boolean consumed = false;
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    // Read-only navigation to the owning user; "email" above stays the writable FK column.
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "email", referencedColumnName = "email", insertable = false, updatable = false)
    private AppUser user;

    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }

    public OtpVerification() {
    }

    public OtpVerification(String otpId, String email, String otpCode, String purpose, OffsetDateTime expiresAt, Boolean consumed, OffsetDateTime createdAt, OffsetDateTime deletedAt) {
        this.otpId = otpId;
        this.email = email;
        this.otpCode = otpCode;
        this.purpose = purpose;
        this.expiresAt = expiresAt;
        this.consumed = consumed;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    public String getOtpId() {
        return otpId;
    }
    public void setOtpId(String otpId) {
        this.otpId = otpId;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getOtpCode() {
        return otpCode;
    }
    public void setOtpCode(String otpCode) {
        this.otpCode = otpCode;
    }
    public String getPurpose() {
        return purpose;
    }
    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
    public OffsetDateTime getExpiresAt() {
        return expiresAt;
    }
    public void setExpiresAt(OffsetDateTime expiresAt) {
        this.expiresAt = expiresAt;
    }
    public Boolean isConsumed() {
        return consumed;
    }
    public void setConsumed(Boolean consumed) {
        this.consumed = consumed;
    }
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }
    public AppUser getUser() {
        return user;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String otpId;
        private String email;
        private String otpCode;
        private String purpose = "LOGIN";
        private OffsetDateTime expiresAt;
        private Boolean consumed = false;
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        public Builder otpId(String otpId) {
            this.otpId = otpId;
            return this;
        }
        public Builder email(String email) {
            this.email = email;
            return this;
        }
        public Builder otpCode(String otpCode) {
            this.otpCode = otpCode;
            return this;
        }
        public Builder purpose(String purpose) {
            this.purpose = purpose;
            return this;
        }
        public Builder expiresAt(OffsetDateTime expiresAt) {
            this.expiresAt = expiresAt;
            return this;
        }
        public Builder consumed(Boolean consumed) {
            this.consumed = consumed;
            return this;
        }
        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public OtpVerification build() {
            return new OtpVerification(otpId, email, otpCode, purpose, expiresAt, consumed, createdAt, deletedAt);
        }
    }
}