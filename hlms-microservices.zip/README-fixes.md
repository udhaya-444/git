# HLMS Microservices — Fix Notes (user-service & notification-service)

This documents what was wrong in `user-service` and `notification-service`
and what was changed, so it's easy to verify or revert.

## 1. `user-service` — JWT was generated but never checked

**Problem:** `JwtService.generateToken()` worked and a token came back from
`POST /api/users/login`, but nothing on the server ever read that token
back on later requests. `JwtSecurityConfig` used `.httpBasic()`, so every
protected endpoint expected a `Basic` username/password header instead of
your JWT — the token was effectively decorative.

**Fixed:**
- Added `JwtAuthenticationFilter.java` (new file) — reads
  `Authorization: Bearer <token>` on every request, validates it via
  `JwtService`, and puts an authenticated user (email + `ROLE_<role>`)
  into Spring Security's context if it's valid.
- `JwtSecurityConfig.java` now registers that filter with
  `.addFilterBefore(...)` and no longer uses `.httpBasic()`.
- `JwtService.java` was rewritten to use one consistent API. It was mixing
  the **old, deprecated** jjwt 0.11.x builder calls (`setClaims`,
  `setSubject`, `setExpiration`, `SignatureAlgorithm.HS256`) with the
  **new** jjwt 0.12.x parser calls (`Jwts.parser().verifyWith(...)`) —
  the pom already declares jjwt `0.12.7`, so it's now all written against
  that version's fluent API (`Jwts.builder().claims(...).subject(...)`, `Keys.hmacShaKeyFor(...)`).

**How to use it now:**
```
POST /api/users/login        -> { "token": "<jwt>" }

GET  /api/users/{email}
Authorization: Bearer <jwt>
```
Requests to `/api/users/register`, `/api/users/login`,
`/api/users/forgot-password`, `/api/users/reset-password`, and
`/api/otp/**` stay public (no token needed). Everything else now requires
a valid `Bearer` token.

## 2. Database config mismatch (both services)

**Problem:** in both `user-service` and `notification-service`, the
datasource pointed at Postgres:
```
spring.datasource.url=jdbc:postgresql://10.23.240.29:5432/Housing_Loan_db
```
...but `spring.jpa.database-platform` was set to
`org.hibernate.dialect.H2Dialect`, and the H2 console was enabled. Hibernate
was being told "talk H2" while the connection was actually Postgres —
this can produce SQL Hibernate generates that Postgres doesn't accept.

**Fixed:** `spring.jpa.database-platform` is now
`org.hibernate.dialect.PostgreSQLDialect` in both services, and the H2
console is now `spring.h2.console.enabled=false` (H2 has nothing to show
against a live Postgres connection — flip it back to `true` and swap the
datasource only if you deliberately want to run against local H2).

**Also flagged, not changed for you (please confirm which is correct):**
`user-service` uses `spring.datasource.username=Housing_Loan_user`
(lowercase `u`), `notification-service` uses `Housing_Loan_User`
(capital `U`) — same database, different casing. If your Postgres role
name is case-sensitive, one of these two services will fail to connect.

## 3. `notification-service` pom.xml — namespace mismatch

`xsi:schemaLocation` declared `https://maven.apache.org/POM/4.0.0`, which
doesn't match the `xmlns="http://maven.apache.org/POM/4.0.0"` above it
(`http` vs `https`). Fixed to match — this is the kind of mismatch strict
IDE pom validators flag as an error even though Maven itself often
tolerates it.

## 4. Routing paths through the new `api-gateway`

Each service keeps its own existing `@RequestMapping` paths unchanged —
they're not consistent with each other (e.g. `legal-service` alone has
`/api/legal/checklist-items`, `/api/legal-notices`,
`/api/bank-office/decisions`), so rather than guess a single path per
service, the gateway reaches every service under **its own name as a
prefix**, and strips that prefix before forwarding:

| Through the gateway (:8080)                          | Reaches                                   |
|--------------------------------------------------------|--------------------------------------------|
| `POST /user-service/api/users/login`                   | user-service `POST /api/users/login`       |
| `GET /user-service/api/users/{email}`                  | user-service `GET /api/users/{email}`      |
| `POST /loan-service/api/loan-applications`              | loan-service `POST /api/loan-applications` |
| `GET /notification-service/api/notifications`           | notification-service `GET /api/notifications` |
| `GET /document-service/api/application-documents`       | document-service `GET /api/application-documents` |

Calling a service directly on its own port (e.g. `:8081` for
user-service) still works exactly as before — the gateway is an
additional, optional front door, not a replacement.

## Not changed, worth knowing

- The DB password is stored in plain text in `application.properties` for
  both services — fine for local dev, but move it to an environment
  variable or a secrets manager before this goes anywhere shared.
- `JwtAuthenticationFilter` currently trusts the `role` claim embedded in
  the token itself and doesn't re-check the database on every request.
  That's the standard stateless-JWT tradeoff (fast, no DB hit) — just be
  aware a role change in the DB won't take effect until the user's
  current token expires and they log in again.
