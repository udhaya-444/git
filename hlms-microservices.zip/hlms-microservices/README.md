# HLMS Microservices

Your six services turned into a proper microservice system: service discovery
(Eureka), a single entry point (API Gateway), inter-service calls (Feign),
and real JPA relationships within each service.

## Modules & ports

| Module | Port | Role |
|---|---|---|
| `eureka-server` | 8761 | Service registry / discovery dashboard |
| `api-gateway` | 8080 | Single entry point, routes to everything below |
| `user-service` | 8081 | Auth, OTP, roles, employment profile |
| `loan-service` | 8082 | Loan applications, eligibility, mortgage calc, status tracking |
| `hlms-notification-service` | 8083 | Notifications, service requests |
| `legal-service` | 8084 | Legal verification, checklist, notices, bank-office decisions |
| `repayment-service` | 8085 | EMI, disbursement, insurance, auctions, bids, default management |
| `hlms-document-service` | 8086 | Application documents, audit logs, post-disbursement documents |

All 8 modules were normalized to **Spring Boot 3.3.5 + Spring Cloud 2023.0.3**
so they're compatible with each other (your original zips were on a mix of
3.2.5 / 3.3.5 / 3.5.4 / 4.1.0 — that mismatch would have broken Feign/Eureka).

## How to run (Eclipse)

1. **File → Import → Maven → Existing Maven Projects**, point at the
   `hlms-microservices` folder, select all 8 modules, Finish.
2. Start in this order (each is a normal `Run As → Spring Boot App`):
   1. `eureka-server` — wait until http://localhost:8761 loads
   2. `user-service`, `loan-service`, `legal-service`, `repayment-service`,
      `hlms-notification-service`, `hlms-document-service` — any order, wait
      ~15s each so they register with Eureka
   3. `api-gateway` — start last
3. Check http://localhost:8761 — you should see all 6 services + the gateway
   listed as `UP`.
4. Call everything through the gateway, e.g.
   `GET http://localhost:8080/api/loan-applications/{appId}`
   `GET http://localhost:8080/api/legal/verifications/by-application/{appId}/context`
   (that last one is a live Feign call: legal-service → loan-service → user-service)

## What changed in each service

- **pom.xml**: bumped to Spring Boot 3.3.5, added `spring-cloud-starter-netflix-eureka-client`
  and `spring-cloud-starter-openfeign`, added the Spring Cloud 2023.0.3 BOM.
- **application.properties**: unique `spring.application.name` + `server.port`
  (was previously conflicting — several services defaulted to 8080), added
  `eureka.client.service-url.defaultZone=http://localhost:8761/eureka/`.
  Datasource lines were left exactly as they were (still pointed at your
  shared Postgres DB, per your "no schema changes" constraint) — update the
  host/user/password if that's changed.
- **Main class**: added `@EnableDiscoveryClient` + `@EnableFeignClients`.

## Feign clients (cross-service calls, no shared entities)

Each service that needs data owned by another service now calls it over
HTTP via Feign, resolved through Eureka by service name — not a hard-coded
URL, and not a JPA join across service boundaries (that's not physically
possible once services are separate deployables):

- `UserServiceClient.getUserByEmail(email)` → `GET /api/users/{email}` on
  user-service. Used by loan-service, legal-service, repayment-service,
  hlms-notification-service.
- `LoanServiceClient.getLoanApplication(appId)` → `GET /api/loan-applications/{appId}`
  on loan-service. Used by legal-service, repayment-service,
  hlms-notification-service, hlms-document-service.

Each of those services got one new demo endpoint (`.../context`) that
actually calls these clients and stitches the results together — e.g.
`GET /api/legal/verifications/by-application/{appId}/context` returns the
local verification record plus the live loan application and applicant
fetched from the other two services.

## JPA relationships added (within each service)

Real `@OneToOne` / `@ManyToOne` / `@OneToMany` were only added **within**
a service's own entities — a JPA relationship can't span two separate
JVMs/deployables even though your services currently share one physical
Postgres database. The existing raw FK columns (`app_id`, `user_email`,
`product_id`, etc.) were **left untouched** so none of your existing
service/DTO code breaks; the new relationship fields are read-only mirrors
(`insertable = false, updatable = false`) that Hibernate populates
automatically when you navigate the object graph.

- **loan-service**: `LoanApplication` ↔ `LoanProduct`, `AppUser`,
  `BankOfficeDecision` (1:1), `LegalVerification` (1:1), `Disbursement` (1:1);
  `AppUser` ↔ `CustomerEmploymentProfile` (1:1), `EligibilityAssessment` (1:N).
- **legal-service**: doesn't own `loan_application`, so a slim read-only
  `LoanApplicationRef` projection entity was added to hang relationships off
  — `LoanApplicationRef` ↔ `BankOfficeDecision`/`LegalVerification` (1:1),
  `LegalChecklistItem`/`LegalNotice` (1:N); `AppUser` ↔ those same entities
  via the `officer` email column.
- **repayment-service**: already had a local `LoanApplication` mirror —
  wired it to `AuctionCase`/`Disbursement` (1:1), `AuctionNote`/`Bid`/
  `EmiInstallment`/`InsurancePolicy` (1:N); `AppUser` ↔ `LoanApplication`
  (borrower) and `Bid` (bidder).
- **hlms-document-service**: added a `LoanApplicationRef` projection,
  wired to `ApplicationDocumentEntity`/`PostDisbursementDocumentEntity` (1:N).
- **hlms-notification-service**: added `LoanApplicationRef` + `AppUserRef`
  projections, wired to `ServiceRequestEntity`/`NotificationEntity`.
- **user-service**: `appUserEntity` ↔ `customerEmploymentProfileEntity` (1:1),
  `otpVerificationEntity` (1:N).

`AuditLog`/`AuditLogEntity` entities were left alone — they're generic
polymorphic logs (`entity_type` + `entity_id` can point at *any* table), so
a single typed FK relationship doesn't apply there.

## Known limitations / next steps

- No circuit breaker (Resilience4j) on the Feign clients yet — if a
  downstream service is down, the calling service will throw rather than
  degrade gracefully. Worth adding before this goes anywhere near production.
- No API-key/JWT propagation across the gateway yet — each service's own
  auth is untouched, so a request coming through the gateway isn't
  automatically authenticated against the others.
- The shared-database-per-service setup (all 6 services pointing at the
  same Postgres DB) works for now but isn't a "real" microservice data
  boundary — that's an intentional trade-off to honor your no-schema-change
  constraint, not something this refactor tries to fix.
