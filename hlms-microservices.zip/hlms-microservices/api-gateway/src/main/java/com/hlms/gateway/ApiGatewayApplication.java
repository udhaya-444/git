package com.hlms.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * Single entry point for the whole HLMS system.
 * Front-end / Postman only ever talks to this gateway (port 8080);
 * routing to the right backend service happens via application.yml below,
 * with load-balanced URIs resolved through Eureka (lb://SERVICE-NAME).
 */
@SpringBootApplication
@EnableDiscoveryClient
public class ApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}
