package com.hlms.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * HLMS Service Discovery Server.
 *
 * Every HLMS microservice (user-service, loan-service, legal-service,
 * repayment-service, hlms-notification-service, hlms-document-service)
 * registers itself here on startup, and the api-gateway + Feign clients
 * use this registry to look each other up by spring.application.name
 * instead of hard-coded host:port values.
 *
 * Run this FIRST, before any other service. Dashboard: http://localhost:8761
 */
@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurekaServerApplication.class, args);
    }
}
