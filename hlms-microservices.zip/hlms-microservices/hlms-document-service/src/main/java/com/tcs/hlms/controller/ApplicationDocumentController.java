package com.tcs.hlms.controller;

import com.tcs.hlms.client.LoanServiceClient;
import com.tcs.hlms.dto.LoanApplicationSummaryDTO;
import com.tcs.hlms.entity.ApplicationDocumentEntity;
import com.tcs.hlms.service.ApplicationDocumentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/application-documents")
public class ApplicationDocumentController {

    private final ApplicationDocumentService service;
    private final LoanServiceClient loanServiceClient;

    public ApplicationDocumentController(
            ApplicationDocumentService service,
            LoanServiceClient loanServiceClient) {
        this.service = service;
        this.loanServiceClient = loanServiceClient;
    }

    /**
     * Cross-service example: list documents for a loan application alongside
     * the application's current status, fetched from loan-service over Feign.
     */
    @GetMapping("/app/{appId}/context")
    public Map<String, Object> getDocumentsWithContext(@PathVariable String appId) {
        List<ApplicationDocumentEntity> documents = service.getDocumentsByAppId(appId);
        LoanApplicationSummaryDTO loanApplication = loanServiceClient.getLoanApplication(appId);

        return Map.of(
                "documents", documents,
                "loanApplication", loanApplication != null ? loanApplication : Map.of()
        );
    }

    @PostMapping
    public ApplicationDocumentEntity saveDocument(
            @RequestBody ApplicationDocumentEntity document) {

        return service.saveDocument(document);
    }

    @GetMapping("/{documentId}")
    public ApplicationDocumentEntity getDocumentById(
            @PathVariable String documentId) {

        return service.getDocumentById(documentId);
    }

    @GetMapping("/app/{appId}")
    public List<ApplicationDocumentEntity> getDocumentsByAppId(
            @PathVariable String appId) {

        return service.getDocumentsByAppId(appId);
    }

    @GetMapping
    public List<ApplicationDocumentEntity> getAllDocuments() {
        return service.getAllDocuments();
    }

    @DeleteMapping("/{documentId}")
    public String deleteDocument(
            @PathVariable String documentId) {

        service.deleteDocument(documentId);
        return "Document deleted successfully";
    }
}