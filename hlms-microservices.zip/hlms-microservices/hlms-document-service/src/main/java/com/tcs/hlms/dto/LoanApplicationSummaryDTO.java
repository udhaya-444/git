package com.tcs.hlms.dto;

import java.math.BigDecimal;

/**
 * Slim, read-only projection of loan-service's LoanApplication, used only
 * for cross-service Feign calls (this service does not own loan_application).
 */
public class LoanApplicationSummaryDTO {
    private String appId;
    private String trackingNo;
    private String userEmail;
    private String status;
    private BigDecimal loanAmount;

    public LoanApplicationSummaryDTO() {
    }

    public String getAppId() { return appId; }
    public void setAppId(String appId) { this.appId = appId; }

    public String getTrackingNo() { return trackingNo; }
    public void setTrackingNo(String trackingNo) { this.trackingNo = trackingNo; }

    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public BigDecimal getLoanAmount() { return loanAmount; }
    public void setLoanAmount(BigDecimal loanAmount) { this.loanAmount = loanAmount; }
}
