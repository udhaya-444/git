package com.tcs.hlms.entity;

import jakarta.persistence.*;

/**
 * Read-only local projection of loan-service's "loan_application" table.
 *
 * hlms-document-service does not own this table - loan-service does - but
 * since both services currently share one physical Postgres database (and
 * the schema can't be changed), mapping a slim, insertable=false/updatable=false
 * projection here lets Hibernate build real @OneToMany object graphs for
 * local queries. All writes to loan_application must go through
 * loan-service's own API (see LoanServiceClient), which is why every field
 * below is read-only.
 */
@Entity
@Table(name = "loan_application")
public class LoanApplicationRef {

    @Id
    @Column(name = "app_id", length = 50, insertable = false, updatable = false)
    private String appId;

    @Column(name = "tracking_no", length = 50, insertable = false, updatable = false)
    private String trackingNo;

    @Column(name = "user_email", insertable = false, updatable = false)
    private String userEmail;

    @Column(name = "status", insertable = false, updatable = false)
    private String status;

    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private java.util.List<ApplicationDocumentEntity> applicationDocuments;

    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private java.util.List<PostDisbursementDocumentEntity> postDisbursementDocuments;

    public String getAppId() {
        return appId;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getStatus() {
        return status;
    }

    public java.util.List<ApplicationDocumentEntity> getApplicationDocuments() {
        return applicationDocuments;
    }

    public java.util.List<PostDisbursementDocumentEntity> getPostDisbursementDocuments() {
        return postDisbursementDocuments;
    }
}
