package com.tcs.hlms.entity;

import jakarta.persistence.*;

/**
 * Read-only local projection of user-service's "app_user" table. This
 * service doesn't own app_user - mapped here read-mostly (all columns
 * insertable/updatable = false) purely so Notification/ServiceRequest can
 * carry a real JPA @ManyToOne to the requesting user instead of a bare
 * String column. Writes go through user-service's API (see UserServiceClient).
 */
@Entity
@Table(name = "app_user")
public class AppUserRef {

    @Id
    @Column(name = "email", length = 255, insertable = false, updatable = false)
    private String email;

    @Column(name = "name", insertable = false, updatable = false)
    private String name;

    @Column(name = "role", insertable = false, updatable = false)
    private String role;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private java.util.List<NotificationEntity> notifications;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private java.util.List<ServiceRequestEntity> serviceRequests;

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

    public java.util.List<NotificationEntity> getNotifications() {
        return notifications;
    }

    public java.util.List<ServiceRequestEntity> getServiceRequests() {
        return serviceRequests;
    }
}
