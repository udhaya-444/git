package com.tcs.hlms.entity;

import jakarta.persistence.*;

/**
 * Read-only local projection of loan-service's "loan_application" table.
 * Used so ServiceRequestEntity can carry a real @ManyToOne instead of a
 * bare String appId column. Writes go through loan-service's API (see
 * LoanServiceClient).
 */
@Entity
@Table(name = "loan_application")
public class LoanApplicationRef {

    @Id
    @Column(name = "app_id", length = 50, insertable = false, updatable = false)
    private String appId;

    @Column(name = "tracking_no", length = 50, insertable = false, updatable = false)
    private String trackingNo;

    @Column(name = "status", insertable = false, updatable = false)
    private String status;

    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private java.util.List<ServiceRequestEntity> serviceRequests;

    public String getAppId() {
        return appId;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public String getStatus() {
        return status;
    }

    public java.util.List<ServiceRequestEntity> getServiceRequests() {
        return serviceRequests;
    }
}
