package com.tcs.hlms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.hlms.entity.NotificationEntity;

@Repository
public interface NotificationRepository
        extends JpaRepository<NotificationEntity, String> {

    List<NotificationEntity> findByDeletedAtIsNull();
}
