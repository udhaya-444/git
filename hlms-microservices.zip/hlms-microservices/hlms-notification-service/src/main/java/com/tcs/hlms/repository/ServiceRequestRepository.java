package com.tcs.hlms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.hlms.entity.ServiceRequestEntity;

@Repository
public interface ServiceRequestRepository extends JpaRepository<ServiceRequestEntity, String> {

    List<ServiceRequestEntity> findByUserEmailAndDeletedAtIsNull(String email);

    List<ServiceRequestEntity> findByAppIdAndDeletedAtIsNull(String appId);

}