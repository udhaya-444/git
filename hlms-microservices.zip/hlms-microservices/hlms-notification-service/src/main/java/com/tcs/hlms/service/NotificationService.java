package com.tcs.hlms.service;

import java.util.List;

import com.tcs.hlms.entity.NotificationEntity;

public interface NotificationService {

    NotificationEntity createNotification(NotificationEntity notification);

    List<NotificationEntity> getAllNotifications();

    void markAsRead(String notificationId);

    void softDeleteNotification(String notificationId);

}