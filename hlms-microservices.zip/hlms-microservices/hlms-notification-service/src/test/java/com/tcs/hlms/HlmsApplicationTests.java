package com.tcs.hlms;

import static org.junit.jupiter.api.Assertions.*;

import java.time.OffsetDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tcs.hlms.entity.NotificationEntity;
import com.tcs.hlms.entity.ServiceRequestEntity;
import com.tcs.hlms.serviceImplementation.NotificationServiceImplementation;
import com.tcs.hlms.serviceImplementation.ServiceRequestServiceImplementation;

@SpringBootTest
class HlmsApplicationTests {

    @Autowired
    private NotificationServiceImplementation notificationService;

    @Autowired
    private ServiceRequestServiceImplementation serviceRequestService;

    @Test
    void contextLoads() {
        assertNotNull(notificationService);
        assertNotNull(serviceRequestService);
    }

    @Test
    void testCreateNotification() {

        NotificationEntity notification =
                new NotificationEntity();

        notification.setNotificationId("NOTIF-101");
        notification.setUserEmail("user@gmail.com");
        notification.setTitle("Test Notification");
        notification.setBody("Notification Body");
        notification.setIsRead(false);
        notification.setCreatedAt(OffsetDateTime.now());

        NotificationEntity result =
                notificationService.createNotification(notification);

        assertNotNull(result);
    }

    @Test
    void testGetAllNotifications() {

        List<NotificationEntity> notifications =
                notificationService.getAllNotifications();

        assertNotNull(notifications);
    }

    @Test
    void testCreateServiceRequest() {

        ServiceRequestEntity request =
                new ServiceRequestEntity();

        request.setRequestId("SR-101");
        request.setRefNo("REF-101");
        request.setAppId("APP-101");
        request.setUserEmail("user@gmail.com");
        request.setRequestType("Address Change");
        request.setDescription("Update Address");
        request.setStatus("Requested");
        request.setCreatedAt(OffsetDateTime.now());

        ServiceRequestEntity result =
                serviceRequestService.createRequest(request);

        assertNotNull(result);
    }

    @Test
    void testGetRequestsByApplication() {

        List<ServiceRequestEntity> requests =
                serviceRequestService
                        .getRequestsByApplication("APP-101");

        assertNotNull(requests);
    }
}