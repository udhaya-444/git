package com.hlms2.legal.controller;

import com.hlms2.legal.client.LoanServiceClient;
import com.hlms2.legal.client.UserServiceClient;
import com.hlms2.legal.dto.LegalVerificationDTO;
import com.hlms2.legal.dto.LoanApplicationSummaryDTO;
import com.hlms2.legal.dto.UserSummaryDTO;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.service.LegalVerificationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/legal/verifications")
public class LegalVerificationController {

    private final LegalVerificationService service;
    private final LoanServiceClient loanServiceClient;
    private final UserServiceClient userServiceClient;

    public LegalVerificationController(LegalVerificationService service,
                                        LoanServiceClient loanServiceClient,
                                        UserServiceClient userServiceClient) {
        this.service = service;
        this.loanServiceClient = loanServiceClient;
        this.userServiceClient = userServiceClient;
    }

    /**
     * Cross-service example: legal-service does not own loan_application or
     * app_user, so instead of a JPA join it calls loan-service and
     * user-service over Feign (via Eureka) and stitches the result together.
     */
    @GetMapping("/by-application/{appId}/context")
    public Map<String, Object> findByAppIdWithContext(@PathVariable String appId) {
        LegalVerificationDTO verification = service.findByAppId(appId);
        if (verification == null) {
            throw new ResourceNotFoundException("No legal verification found for application " + appId + ".");
        }
        LoanApplicationSummaryDTO loanApplication = loanServiceClient.getLoanApplication(appId);
        UserSummaryDTO applicant = loanApplication != null
                ? userServiceClient.getUserByEmail(loanApplication.getUserEmail())
                : null;

        return Map.of(
                "verification", verification,
                "loanApplication", loanApplication != null ? loanApplication : Map.of(),
                "applicant", applicant != null ? applicant : Map.of()
        );
    }

    @PostMapping
    public ResponseEntity<LegalVerificationDTO> create(@RequestBody LegalVerificationDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{verificationId}")
    public LegalVerificationDTO update(@PathVariable Long verificationId, @RequestBody LegalVerificationDTO dto) {
        return service.update(verificationId, dto);
    }

    @DeleteMapping("/{verificationId}")
    public ResponseEntity<Void> softDelete(@PathVariable Long verificationId) {
        return service.softDelete(verificationId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{verificationId}/restore")
    public ResponseEntity<Void> restore(@PathVariable Long verificationId) {
        return service.restore(verificationId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{verificationId}")
    public LegalVerificationDTO findById(@PathVariable Long verificationId) {
        LegalVerificationDTO dto = service.findById(verificationId);
        if (dto == null) {
            throw new ResourceNotFoundException("No legal verification found with id " + verificationId + ".");
        }
        return dto;
    }

    @GetMapping("/by-application/{appId}")
    public LegalVerificationDTO findByAppId(@PathVariable String appId) {
        LegalVerificationDTO dto = service.findByAppId(appId);
        if (dto == null) {
            throw new ResourceNotFoundException("No legal verification found for application " + appId + ".");
        }
        return dto;
    }

    @GetMapping
    public List<LegalVerificationDTO> findAll() {
        return service.findAll();
    }
}
