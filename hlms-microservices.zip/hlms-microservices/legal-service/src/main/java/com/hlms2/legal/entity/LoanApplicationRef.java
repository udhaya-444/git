package com.hlms2.legal.entity;

import jakarta.persistence.*;

/**
 * Read-only local projection of loan-service's "loan_application" table.
 *
 * legal-service does not own this table - loan-service does - but since
 * both services currently share one physical Postgres database (and the
 * schema can't be changed), mapping a slim, insertable=false/updatable=false
 * projection here lets Hibernate build real @OneToMany / @OneToOne object
 * graphs for local queries (e.g. verification.getLoanApplication().getStatus()).
 *
 * This entity is never saved/updated from legal-service. All writes to
 * loan_application must go through loan-service's own API (use
 * LoanServiceClient for that), which is why every field below is
 * insertable = false, updatable = false.
 */
@Entity
@Table(name = "loan_application")
public class LoanApplicationRef {

    @Id
    @Column(name = "app_id", length = 50, insertable = false, updatable = false)
    private String appId;

    @Column(name = "tracking_no", length = 50, insertable = false, updatable = false)
    private String trackingNo;

    @Column(name = "user_email", insertable = false, updatable = false)
    private String userEmail;

    @Column(name = "status", insertable = false, updatable = false)
    private String status;

    @OneToOne(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private BankOfficeDecision bankOfficeDecision;

    @OneToOne(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private LegalVerification legalVerification;

    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private java.util.List<LegalChecklistItem> checklistItems;

    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private java.util.List<LegalNotice> legalNotices;

    public String getAppId() {
        return appId;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getStatus() {
        return status;
    }

    public BankOfficeDecision getBankOfficeDecision() {
        return bankOfficeDecision;
    }

    public LegalVerification getLegalVerification() {
        return legalVerification;
    }

    public java.util.List<LegalChecklistItem> getChecklistItems() {
        return checklistItems;
    }

    public java.util.List<LegalNotice> getLegalNotices() {
        return legalNotices;
    }
}
