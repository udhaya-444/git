package com.hlms.loan.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "disbursement")
public class Disbursement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "disbursement_id")
    private Long disbursementId;

    @Column(name = "app_id", nullable = false, unique = true)
    private String appId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "app_id", referencedColumnName = "app_id", insertable = false, updatable = false)
    private LoanApplication loanApplication;

    public LoanApplication getLoanApplication() {
        return loanApplication;
    }

    @Column(name = "disbursed_date")
    private OffsetDateTime disbursedDate;

    @Column(name = "amount", precision = 14, scale = 2)
    private BigDecimal amount;

    @Column(name = "ref_no", length = 50)
    private String refNo;

    @Column(name = "mode", length = 30)
    private String mode;

    @Column(name = "bank_details", length = 150)
    private String bankDetails;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public Disbursement() {
    }

    public Disbursement(Long disbursementId, String appId, OffsetDateTime disbursedDate, BigDecimal amount,
                         String refNo, String mode, String bankDetails, OffsetDateTime deletedAt) {
        this.disbursementId = disbursementId;
        this.appId = appId;
        this.disbursedDate = disbursedDate;
        this.amount = amount;
        this.refNo = refNo;
        this.mode = mode;
        this.bankDetails = bankDetails;
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public Long getDisbursementId() {
        return disbursementId;
    }

    public void setDisbursementId(Long disbursementId) {
        this.disbursementId = disbursementId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public OffsetDateTime getDisbursedDate() {
        return disbursedDate;
    }

    public void setDisbursedDate(OffsetDateTime disbursedDate) {
        this.disbursedDate = disbursedDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getRefNo() {
        return refNo;
    }

    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getBankDetails() {
        return bankDetails;
    }

    public void setBankDetails(String bankDetails) {
        this.bankDetails = bankDetails;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static final class Builder {
        private Long disbursementId;
        private String appId;
        private OffsetDateTime disbursedDate;
        private BigDecimal amount;
        private String refNo;
        private String mode;
        private String bankDetails;
        private OffsetDateTime deletedAt;

        private Builder() {
        }

        public Builder disbursementId(Long disbursementId) {
            this.disbursementId = disbursementId;
            return this;
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder disbursedDate(OffsetDateTime disbursedDate) {
            this.disbursedDate = disbursedDate;
            return this;
        }

        public Builder amount(BigDecimal amount) {
            this.amount = amount;
            return this;
        }

        public Builder refNo(String refNo) {
            this.refNo = refNo;
            return this;
        }

        public Builder mode(String mode) {
            this.mode = mode;
            return this;
        }

        public Builder bankDetails(String bankDetails) {
            this.bankDetails = bankDetails;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public Disbursement build() {
            return new Disbursement(disbursementId, appId, disbursedDate, amount, refNo, mode, bankDetails, deletedAt);
        }
    }
}
