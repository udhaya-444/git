package com.hlms.loan.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Persists a snapshot of each eligibility run (feature 2), instead of being stateless-only. */
@Entity
@Table(name = "eligibility_assessment")
public class EligibilityAssessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "assessment_id")
    private Long assessmentId;

    @Column(name = "user_email", nullable = false)
    private String userEmail;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_email", referencedColumnName = "email", insertable = false, updatable = false)
    private AppUser user;

    public AppUser getUser() {
        return user;
    }

    @Column(name = "requested_amount", precision = 14, scale = 2)
    private BigDecimal requestedAmount;

    @Column(name = "tenure_years")
    private Integer tenureYears;

    @Column(name = "cibil_score")
    private Integer cibilScore;

    @Column(name = "monthly_income", precision = 14, scale = 2)
    private BigDecimal monthlyIncome;

    @Column(name = "other_emis", precision = 14, scale = 2)
    private BigDecimal otherEmis;

    @Column(name = "interest_rate", precision = 5, scale = 2)
    private BigDecimal interestRate;

    @Column(name = "status", length = 30, nullable = false)
    private String status;

    @Column(name = "max_eligible_loan_amount", precision = 14, scale = 2)
    private BigDecimal maxEligibleLoanAmount;

    @Column(name = "estimated_emi", precision = 14, scale = 2)
    private BigDecimal estimatedEmi;

    @Column(name = "dti_ratio", precision = 6, scale = 4)
    private BigDecimal dtiRatio;

    // Stored as JSON text (list of strings serialized by the service layer).
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "reasons", columnDefinition = "jsonb")
    private String reasons;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "recommendations", columnDefinition = "jsonb")
    private String recommendations;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public EligibilityAssessment() {
    }

    public EligibilityAssessment(Long assessmentId, String userEmail, BigDecimal requestedAmount,
                                  Integer tenureYears, Integer cibilScore, BigDecimal monthlyIncome,
                                  BigDecimal otherEmis, BigDecimal interestRate, String status,
                                  BigDecimal maxEligibleLoanAmount, BigDecimal estimatedEmi, BigDecimal dtiRatio,
                                  String reasons, String recommendations, OffsetDateTime createdAt,
                                  OffsetDateTime deletedAt) {
        this.assessmentId = assessmentId;
        this.userEmail = userEmail;
        this.requestedAmount = requestedAmount;
        this.tenureYears = tenureYears;
        this.cibilScore = cibilScore;
        this.monthlyIncome = monthlyIncome;
        this.otherEmis = otherEmis;
        this.interestRate = interestRate;
        this.status = status;
        this.maxEligibleLoanAmount = maxEligibleLoanAmount;
        this.estimatedEmi = estimatedEmi;
        this.dtiRatio = dtiRatio;
        this.reasons = reasons;
        this.recommendations = recommendations;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }

    public static Builder builder() {
        return new Builder();
    }

    public Long getAssessmentId() {
        return assessmentId;
    }

    public void setAssessmentId(Long assessmentId) {
        this.assessmentId = assessmentId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public BigDecimal getRequestedAmount() {
        return requestedAmount;
    }

    public void setRequestedAmount(BigDecimal requestedAmount) {
        this.requestedAmount = requestedAmount;
    }

    public Integer getTenureYears() {
        return tenureYears;
    }

    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }

    public Integer getCibilScore() {
        return cibilScore;
    }

    public void setCibilScore(Integer cibilScore) {
        this.cibilScore = cibilScore;
    }

    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public BigDecimal getOtherEmis() {
        return otherEmis;
    }

    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getMaxEligibleLoanAmount() {
        return maxEligibleLoanAmount;
    }

    public void setMaxEligibleLoanAmount(BigDecimal maxEligibleLoanAmount) {
        this.maxEligibleLoanAmount = maxEligibleLoanAmount;
    }

    public BigDecimal getEstimatedEmi() {
        return estimatedEmi;
    }

    public void setEstimatedEmi(BigDecimal estimatedEmi) {
        this.estimatedEmi = estimatedEmi;
    }

    public BigDecimal getDtiRatio() {
        return dtiRatio;
    }

    public void setDtiRatio(BigDecimal dtiRatio) {
        this.dtiRatio = dtiRatio;
    }

    public String getReasons() {
        return reasons;
    }

    public void setReasons(String reasons) {
        this.reasons = reasons;
    }

    public String getRecommendations() {
        return recommendations;
    }

    public void setRecommendations(String recommendations) {
        this.recommendations = recommendations;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static final class Builder {
        private Long assessmentId;
        private String userEmail;
        private BigDecimal requestedAmount;
        private Integer tenureYears;
        private Integer cibilScore;
        private BigDecimal monthlyIncome;
        private BigDecimal otherEmis;
        private BigDecimal interestRate;
        private String status;
        private BigDecimal maxEligibleLoanAmount;
        private BigDecimal estimatedEmi;
        private BigDecimal dtiRatio;
        private String reasons;
        private String recommendations;
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        private Builder() {
        }

        public Builder assessmentId(Long assessmentId) {
            this.assessmentId = assessmentId;
            return this;
        }

        public Builder userEmail(String userEmail) {
            this.userEmail = userEmail;
            return this;
        }

        public Builder requestedAmount(BigDecimal requestedAmount) {
            this.requestedAmount = requestedAmount;
            return this;
        }

        public Builder tenureYears(Integer tenureYears) {
            this.tenureYears = tenureYears;
            return this;
        }

        public Builder cibilScore(Integer cibilScore) {
            this.cibilScore = cibilScore;
            return this;
        }

        public Builder monthlyIncome(BigDecimal monthlyIncome) {
            this.monthlyIncome = monthlyIncome;
            return this;
        }

        public Builder otherEmis(BigDecimal otherEmis) {
            this.otherEmis = otherEmis;
            return this;
        }

        public Builder interestRate(BigDecimal interestRate) {
            this.interestRate = interestRate;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder maxEligibleLoanAmount(BigDecimal maxEligibleLoanAmount) {
            this.maxEligibleLoanAmount = maxEligibleLoanAmount;
            return this;
        }

        public Builder estimatedEmi(BigDecimal estimatedEmi) {
            this.estimatedEmi = estimatedEmi;
            return this;
        }

        public Builder dtiRatio(BigDecimal dtiRatio) {
            this.dtiRatio = dtiRatio;
            return this;
        }

        public Builder reasons(String reasons) {
            this.reasons = reasons;
            return this;
        }

        public Builder recommendations(String recommendations) {
            this.recommendations = recommendations;
            return this;
        }

        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public EligibilityAssessment build() {
            return new EligibilityAssessment(assessmentId, userEmail, requestedAmount, tenureYears, cibilScore,
                    monthlyIncome, otherEmis, interestRate, status, maxEligibleLoanAmount, estimatedEmi, dtiRatio,
                    reasons, recommendations, createdAt, deletedAt);
        }
    }
}
