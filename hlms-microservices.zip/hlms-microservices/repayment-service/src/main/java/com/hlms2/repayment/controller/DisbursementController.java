package com.hlms2.repayment.controller;

import com.hlms2.repayment.client.LoanServiceClient;
import com.hlms2.repayment.client.UserServiceClient;
import com.hlms2.repayment.dto.DisbursementDTO;
import com.hlms2.repayment.dto.LoanApplicationSummaryDTO;
import com.hlms2.repayment.dto.UserSummaryDTO;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.service.DisbursementService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/disbursements")
public class DisbursementController {

    private final DisbursementService service;
    private final LoanServiceClient loanServiceClient;
    private final UserServiceClient userServiceClient;

    public DisbursementController(DisbursementService service,
                                   LoanServiceClient loanServiceClient,
                                   UserServiceClient userServiceClient) {
        this.service = service;
        this.loanServiceClient = loanServiceClient;
        this.userServiceClient = userServiceClient;
    }

    /**
     * Cross-service example: enrich a disbursement with the owning loan
     * application (loan-service) and borrower (user-service), fetched over
     * Feign via Eureka rather than a local JPA join.
     */
    @GetMapping("/by-application/{appId}/context")
    public Map<String, Object> findByAppIdWithContext(@PathVariable String appId) {
        DisbursementDTO disbursement = service.findByAppId(appId);
        if (disbursement == null) {
            throw new ResourceNotFoundException("No disbursement found for application " + appId + ".");
        }
        LoanApplicationSummaryDTO loanApplication = loanServiceClient.getLoanApplication(appId);
        UserSummaryDTO borrower = loanApplication != null
                ? userServiceClient.getUserByEmail(loanApplication.getUserEmail())
                : null;

        return Map.of(
                "disbursement", disbursement,
                "loanApplication", loanApplication != null ? loanApplication : Map.of(),
                "borrower", borrower != null ? borrower : Map.of()
        );
    }

    @PostMapping
    public ResponseEntity<DisbursementDTO> create(@RequestBody DisbursementDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{disbursementId}")
    public DisbursementDTO update(@PathVariable Long disbursementId, @RequestBody DisbursementDTO dto) {
        return service.update(disbursementId, dto);
    }

    @DeleteMapping("/{disbursementId}")
    public ResponseEntity<Void> softDelete(@PathVariable Long disbursementId) {
        return service.softDelete(disbursementId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{disbursementId}/restore")
    public ResponseEntity<Void> restore(@PathVariable Long disbursementId) {
        return service.restore(disbursementId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{disbursementId}")
    public DisbursementDTO findById(@PathVariable Long disbursementId) {
        DisbursementDTO dto = service.findById(disbursementId);
        if (dto == null) {
            throw new ResourceNotFoundException("No disbursement found with id " + disbursementId + ".");
        }
        return dto;
    }

    @GetMapping("/by-application/{appId}")
    public DisbursementDTO findByAppId(@PathVariable String appId) {
        DisbursementDTO dto = service.findByAppId(appId);
        if (dto == null) {
            throw new ResourceNotFoundException("No disbursement found for application " + appId + ".");
        }
        return dto;
    }

    @GetMapping
    public List<DisbursementDTO> findAll() {
        return service.findAll();
    }
}
