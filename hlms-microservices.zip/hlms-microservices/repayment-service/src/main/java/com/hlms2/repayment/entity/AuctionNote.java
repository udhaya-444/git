package com.hlms2.repayment.entity;

import jakarta.persistence.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'auction_note'. Ported from hlms2.entity.AuctionNote -
 * the FK to the auction case is via app_id (the schema's
 * auction_note.app_id references auction_case.app_id, its unique column,
 * not the surrogate auction_id), so this stays a flat appId string exactly
 * as it was pre-v2. Adds the deleted_at soft delete marker.
 */
@Entity
@Table(name = "auction_note")
public class AuctionNote {

    @Id
    @Column(name = "note_id", length = 50)
    private String noteId;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "app_id", referencedColumnName = "app_id", insertable = false, updatable = false)
    private LoanApplication loanApplication;

    public LoanApplication getLoanApplication() {
        return loanApplication;
    }

    @Column(name = "note_date")
    private OffsetDateTime noteDate;

    @Column(name = "note_text", columnDefinition = "TEXT", nullable = false)
    private String noteText;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public AuctionNote() {
    }

    public AuctionNote(String noteId, String appId, OffsetDateTime noteDate, String noteText, OffsetDateTime deletedAt) {
        this.noteId = noteId;
        this.appId = appId;
        this.noteDate = noteDate;
        this.noteText = noteText;
        this.deletedAt = deletedAt;
    }

    public String getNoteId() {
        return noteId;
    }
    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public OffsetDateTime getNoteDate() {
        return noteDate;
    }
    public void setNoteDate(OffsetDateTime noteDate) {
        this.noteDate = noteDate;
    }
    public String getNoteText() {
        return noteText;
    }
    public void setNoteText(String noteText) {
        this.noteText = noteText;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String noteId;
        private String appId;
        private OffsetDateTime noteDate;
        private String noteText;
        private OffsetDateTime deletedAt;

        public Builder noteId(String noteId) {
            this.noteId = noteId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder noteDate(OffsetDateTime noteDate) {
            this.noteDate = noteDate;
            return this;
        }
        public Builder noteText(String noteText) {
            this.noteText = noteText;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public AuctionNote build() {
            return new AuctionNote(noteId, appId, noteDate, noteText, deletedAt);
        }
    }
}
