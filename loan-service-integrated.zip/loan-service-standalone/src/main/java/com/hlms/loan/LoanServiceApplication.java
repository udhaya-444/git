package com.hlms.loan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * loan-service - one of 6 microservices in the HLMS system
 * (the others being user-service, legal-service, repayment-service,
 * notifications-service, and document-service).
 *
 * - @EnableDiscoveryClient registers this instance with the Eureka
 *   discovery server (see eureka.client.* in application.properties) so
 *   the other services can find it by the name "loan-service", and so it
 *   can find them.
 * - @EnableFeignClients activates the declarative REST clients under
 *   com.hlms.loan.client used to call those other services.
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = "com.hlms.loan.client")
public class LoanServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoanServiceApplication.class, args);
    }
}
