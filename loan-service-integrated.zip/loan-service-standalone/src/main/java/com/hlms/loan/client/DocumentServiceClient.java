package com.hlms.loan.client;

import com.hlms.loan.client.dto.DocumentChecklistDto;
import com.hlms.loan.config.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/** Client for document-service - upload/verification status of an application's paperwork. */
@FeignClient(name = "document-service", configuration = FeignClientConfig.class)
public interface DocumentServiceClient {

    @GetMapping("/api/documents/checklist/{appId}")
    DocumentChecklistDto getChecklist(@PathVariable("appId") String appId);
}
