package com.hlms.loan.client;

import com.hlms.loan.client.dto.LegalVerificationAckDto;
import com.hlms.loan.client.dto.LegalVerificationRequestDto;
import com.hlms.loan.config.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/** Client for legal-service - opens/tracks a legal verification case for an application. */
@FeignClient(name = "legal-service", configuration = FeignClientConfig.class)
public interface LegalServiceClient {

    @PostMapping("/api/legal/verifications")
    LegalVerificationAckDto openVerification(@RequestBody LegalVerificationRequestDto request);
}
