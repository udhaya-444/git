package com.hlms.loan.client;

import com.hlms.loan.client.dto.AckResponse;
import com.hlms.loan.client.dto.NotificationRequestDto;
import com.hlms.loan.config.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/** Client for notifications-service - sends email/SMS alerts to applicants. */
@FeignClient(name = "notifications-service", configuration = FeignClientConfig.class)
public interface NotificationsServiceClient {

    @PostMapping("/api/notifications")
    AckResponse send(@RequestBody NotificationRequestDto request);
}
