package com.hlms.loan.client;

import com.hlms.loan.client.dto.AckResponse;
import com.hlms.loan.client.dto.GenerateScheduleRequestDto;
import com.hlms.loan.config.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/** Client for repayment-service - generates the EMI schedule once a loan is disbursed. */
@FeignClient(name = "repayment-service", configuration = FeignClientConfig.class)
public interface RepaymentServiceClient {

    @PostMapping("/api/repayments/schedule")
    AckResponse generateSchedule(@RequestBody GenerateScheduleRequestDto request);
}
