package com.hlms.loan.client;

import com.hlms.loan.client.dto.UserProfileDto;
import com.hlms.loan.config.FeignClientConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Client for user-service - the source of truth for user/customer identity and KYC status.
 * "user-service" must match that service's spring.application.name so Eureka can resolve it.
 */
@FeignClient(name = "user-service", configuration = FeignClientConfig.class)
public interface UserServiceClient {

    @GetMapping("/api/users/by-email/{email}")
    UserProfileDto getByEmail(@PathVariable("email") String email);
}
