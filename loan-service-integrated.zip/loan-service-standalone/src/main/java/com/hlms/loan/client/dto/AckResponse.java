package com.hlms.loan.client.dto;

/** Generic ack shape reused by notifications-service and repayment-service responses. */
public class AckResponse {

    private boolean accepted;
    private String referenceId;
    private String message;

    public AckResponse() {
    }

    public AckResponse(boolean accepted, String referenceId, String message) {
        this.accepted = accepted;
        this.referenceId = referenceId;
        this.message = message;
    }

    public boolean isAccepted() {
        return accepted;
    }

    public void setAccepted(boolean accepted) {
        this.accepted = accepted;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
