package com.hlms.loan.client.dto;

import java.util.ArrayList;
import java.util.List;

/** Mirrors GET /api/documents/checklist/{appId} from document-service. */
public class DocumentChecklistDto {

    private String appId;
    private List<DocumentRequirement> requiredDocuments = new ArrayList<>();
    private boolean allVerified;

    public DocumentChecklistDto() {
    }

    public DocumentChecklistDto(String appId, List<DocumentRequirement> requiredDocuments, boolean allVerified) {
        this.appId = appId;
        this.requiredDocuments = requiredDocuments;
        this.allVerified = allVerified;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public List<DocumentRequirement> getRequiredDocuments() {
        return requiredDocuments;
    }

    public void setRequiredDocuments(List<DocumentRequirement> requiredDocuments) {
        this.requiredDocuments = requiredDocuments;
    }

    public boolean isAllVerified() {
        return allVerified;
    }

    public void setAllVerified(boolean allVerified) {
        this.allVerified = allVerified;
    }
}
