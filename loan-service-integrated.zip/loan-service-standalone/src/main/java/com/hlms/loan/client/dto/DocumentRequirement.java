package com.hlms.loan.client.dto;

/** A single required document and its upload/verification status, from document-service. */
public class DocumentRequirement {

    private String docType;
    private boolean uploaded;
    private boolean verified;

    public DocumentRequirement() {
    }

    public DocumentRequirement(String docType, boolean uploaded, boolean verified) {
        this.docType = docType;
        this.uploaded = uploaded;
        this.verified = verified;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public boolean isUploaded() {
        return uploaded;
    }

    public void setUploaded(boolean uploaded) {
        this.uploaded = uploaded;
    }

    public boolean isVerified() {
        return verified;
    }

    public void setVerified(boolean verified) {
        this.verified = verified;
    }
}
