package com.hlms.loan.client.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Request body sent to repayment-service's POST /api/repayments/schedule. */
public class GenerateScheduleRequestDto {

    private String appId;
    private BigDecimal principal;
    private Integer tenureYears;
    private BigDecimal interestRate;
    private LocalDate startDate;

    public GenerateScheduleRequestDto() {
    }

    public GenerateScheduleRequestDto(String appId, BigDecimal principal, Integer tenureYears,
                                       BigDecimal interestRate, LocalDate startDate) {
        this.appId = appId;
        this.principal = principal;
        this.tenureYears = tenureYears;
        this.interestRate = interestRate;
        this.startDate = startDate;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public BigDecimal getPrincipal() {
        return principal;
    }

    public void setPrincipal(BigDecimal principal) {
        this.principal = principal;
    }

    public Integer getTenureYears() {
        return tenureYears;
    }

    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }
}
