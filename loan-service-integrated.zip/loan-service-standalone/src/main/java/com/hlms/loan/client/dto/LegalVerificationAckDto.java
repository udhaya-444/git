package com.hlms.loan.client.dto;

/** Acknowledgement returned by legal-service after a verification case is opened. */
public class LegalVerificationAckDto {

    private String verificationId;
    private String status;

    public LegalVerificationAckDto() {
    }

    public LegalVerificationAckDto(String verificationId, String status) {
        this.verificationId = verificationId;
        this.status = status;
    }

    public String getVerificationId() {
        return verificationId;
    }

    public void setVerificationId(String verificationId) {
        this.verificationId = verificationId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
