package com.hlms.loan.client.dto;

/** Request body sent to legal-service to open a verification case for an application. */
public class LegalVerificationRequestDto {

    private String appId;
    private String applicantName;
    private String propertyAddress;
    private String requestedBy;

    public LegalVerificationRequestDto() {
    }

    public LegalVerificationRequestDto(String appId, String applicantName, String propertyAddress, String requestedBy) {
        this.appId = appId;
        this.applicantName = applicantName;
        this.propertyAddress = propertyAddress;
        this.requestedBy = requestedBy;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public String getPropertyAddress() {
        return propertyAddress;
    }

    public void setPropertyAddress(String propertyAddress) {
        this.propertyAddress = propertyAddress;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }
}
