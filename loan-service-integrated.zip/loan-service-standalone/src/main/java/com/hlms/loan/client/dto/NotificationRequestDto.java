package com.hlms.loan.client.dto;

import java.util.HashMap;
import java.util.Map;

/** Request body sent to notifications-service's POST /api/notifications. */
public class NotificationRequestDto {

    private String recipientEmail;
    private String channel;      // e.g. "EMAIL", "SMS"
    private String templateCode; // e.g. "LOAN_APPLICATION_SUBMITTED"
    private Map<String, Object> params = new HashMap<>();

    public NotificationRequestDto() {
    }

    public NotificationRequestDto(String recipientEmail, String channel, String templateCode, Map<String, Object> params) {
        this.recipientEmail = recipientEmail;
        this.channel = channel;
        this.templateCode = templateCode;
        this.params = params;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public void setRecipientEmail(String recipientEmail) {
        this.recipientEmail = recipientEmail;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getTemplateCode() {
        return templateCode;
    }

    public void setTemplateCode(String templateCode) {
        this.templateCode = templateCode;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }
}
