package com.hlms.loan.client.dto;

/**
 * Mirrors the profile payload returned by user-service's
 * GET /api/users/by-email/{email}. Kept intentionally narrow -
 * only the fields loan-service actually needs.
 */
public class UserProfileDto {

    private String email;
    private String fullName;
    private String mobile;
    private String panNumber;
    private String role;
    private boolean kycVerified;

    public UserProfileDto() {
    }

    public UserProfileDto(String email, String fullName, String mobile, String panNumber,
                           String role, boolean kycVerified) {
        this.email = email;
        this.fullName = fullName;
        this.mobile = mobile;
        this.panNumber = panNumber;
        this.role = role;
        this.kycVerified = kycVerified;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPanNumber() {
        return panNumber;
    }

    public void setPanNumber(String panNumber) {
        this.panNumber = panNumber;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isKycVerified() {
        return kycVerified;
    }

    public void setKycVerified(boolean kycVerified) {
        this.kycVerified = kycVerified;
    }
}
