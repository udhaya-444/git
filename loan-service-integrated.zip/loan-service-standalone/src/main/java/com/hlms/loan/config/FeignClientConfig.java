package com.hlms.loan.config;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Shared Feign configuration for every client in com.hlms.loan.client.
 *
 * Each of the 6 HLMS microservices validates the JWT independently
 * (see SecurityConfig), so when loan-service calls another service on
 * behalf of the logged-in user, it must forward the same
 * "Authorization: Bearer <jwt>" header, otherwise the downstream call
 * would be rejected as unauthenticated.
 */
@Configuration
public class FeignClientConfig {

    private static final String AUTHORIZATION_HEADER = "Authorization";

    @Bean
    public RequestInterceptor authForwardingInterceptor() {
        return (RequestTemplate template) -> {
            ServletRequestAttributes attributes =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attributes == null) {
                return;
            }
            HttpServletRequest incoming = attributes.getRequest();
            String authHeader = incoming.getHeader(AUTHORIZATION_HEADER);
            if (authHeader != null && !authHeader.isBlank()) {
                template.header(AUTHORIZATION_HEADER, authHeader);
            }
        };
    }
}
