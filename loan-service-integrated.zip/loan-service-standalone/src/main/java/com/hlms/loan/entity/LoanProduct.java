package com.hlms.loan.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "loan_product")
public class LoanProduct {

    @Id
    @Column(name = "product_id", length = 50)
    private String productId;

    @Column(name = "name", length = 150, nullable = false)
    private String name;

    @Column(name = "category", length = 50)
    private String category;

    @Column(name = "interest_rate", precision = 5, scale = 2, nullable = false)
    private BigDecimal interestRate;

    @Column(name = "max_tenure_years", nullable = false)
    private Integer maxTenureYears;

    @Column(name = "max_ltv", length = 10)
    private String maxLtv;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public LoanProduct() {
    }

    public LoanProduct(String productId, String name, String category, BigDecimal interestRate,
                        Integer maxTenureYears, String maxLtv, String description, OffsetDateTime deletedAt) {
        this.productId = productId;
        this.name = name;
        this.category = category;
        this.interestRate = interestRate;
        this.maxTenureYears = maxTenureYears;
        this.maxLtv = maxLtv;
        this.description = description;
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public Integer getMaxTenureYears() {
        return maxTenureYears;
    }

    public void setMaxTenureYears(Integer maxTenureYears) {
        this.maxTenureYears = maxTenureYears;
    }

    public String getMaxLtv() {
        return maxLtv;
    }

    public void setMaxLtv(String maxLtv) {
        this.maxLtv = maxLtv;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static final class Builder {
        private String productId;
        private String name;
        private String category;
        private BigDecimal interestRate;
        private Integer maxTenureYears;
        private String maxLtv;
        private String description;
        private OffsetDateTime deletedAt;

        private Builder() {
        }

        public Builder productId(String productId) {
            this.productId = productId;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder category(String category) {
            this.category = category;
            return this;
        }

        public Builder interestRate(BigDecimal interestRate) {
            this.interestRate = interestRate;
            return this;
        }

        public Builder maxTenureYears(Integer maxTenureYears) {
            this.maxTenureYears = maxTenureYears;
            return this;
        }

        public Builder maxLtv(String maxLtv) {
            this.maxLtv = maxLtv;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public LoanProduct build() {
            return new LoanProduct(productId, name, category, interestRate, maxTenureYears, maxLtv, description,
                    deletedAt);
        }
    }
}
