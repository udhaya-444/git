package com.hlms.loan.exception;

/**
 * Raised when a call to another HLMS microservice (user-service, legal-service,
 * document-service, notifications-service, repayment-service) fails or times out
 * and the caller needs to know about it (as opposed to best-effort calls, which
 * are caught and logged instead of thrown).
 */
public class DownstreamServiceException extends RuntimeException {

    private final String serviceName;

    public DownstreamServiceException(String serviceName, String message, Throwable cause) {
        super(message, cause);
        this.serviceName = serviceName;
    }

    public String getServiceName() {
        return serviceName;
    }
}
