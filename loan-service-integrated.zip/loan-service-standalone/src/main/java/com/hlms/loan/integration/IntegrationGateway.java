package com.hlms.loan.integration;

import com.hlms.loan.client.DocumentServiceClient;
import com.hlms.loan.client.LegalServiceClient;
import com.hlms.loan.client.NotificationsServiceClient;
import com.hlms.loan.client.RepaymentServiceClient;
import com.hlms.loan.client.UserServiceClient;
import com.hlms.loan.client.dto.AckResponse;
import com.hlms.loan.client.dto.DocumentChecklistDto;
import com.hlms.loan.client.dto.GenerateScheduleRequestDto;
import com.hlms.loan.client.dto.LegalVerificationAckDto;
import com.hlms.loan.client.dto.LegalVerificationRequestDto;
import com.hlms.loan.client.dto.NotificationRequestDto;
import com.hlms.loan.client.dto.UserProfileDto;
import com.hlms.loan.exception.DownstreamServiceException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Single entry point loan-service's own domain services (LoanApplicationService,
 * StatusTrackingService, etc.) go through to talk to the other 5 microservices,
 * instead of injecting the 5 Feign clients everywhere.
 *
 * Two call styles are exposed:
 *  - "best effort" calls (notify*, requestLegalVerification, requestRepaymentSchedule)
 *    log a warning and return empty/false on failure rather than blocking the caller's
 *    transaction - a notification or downstream kickoff failing shouldn't stop a loan
 *    application from being saved.
 *  - "required" calls (fetchUserProfile, fetchDocumentChecklist) throw
 *    DownstreamServiceException on failure, for the cases where the caller genuinely
 *    needs the answer before it can proceed.
 *
 * hlms.integration.enabled (application.properties) lets the whole service still run
 * stand-alone, with the other 5 services and Eureka absent, e.g. during local dev.
 */
@Service
public class IntegrationGateway {

    private static final Logger log = LoggerFactory.getLogger(IntegrationGateway.class);

    private final UserServiceClient userServiceClient;
    private final LegalServiceClient legalServiceClient;
    private final DocumentServiceClient documentServiceClient;
    private final NotificationsServiceClient notificationsServiceClient;
    private final RepaymentServiceClient repaymentServiceClient;
    private final boolean integrationEnabled;

    public IntegrationGateway(UserServiceClient userServiceClient,
                               LegalServiceClient legalServiceClient,
                               DocumentServiceClient documentServiceClient,
                               NotificationsServiceClient notificationsServiceClient,
                               RepaymentServiceClient repaymentServiceClient,
                               @Value("${hlms.integration.enabled:false}") boolean integrationEnabled) {
        this.userServiceClient = userServiceClient;
        this.legalServiceClient = legalServiceClient;
        this.documentServiceClient = documentServiceClient;
        this.notificationsServiceClient = notificationsServiceClient;
        this.repaymentServiceClient = repaymentServiceClient;
        this.integrationEnabled = integrationEnabled;
    }

    // ------------------------------------------------------------- user-service

    @CircuitBreaker(name = "userService", fallbackMethod = "fetchUserProfileFallback")
    public Optional<UserProfileDto> fetchUserProfile(String email) {
        if (!integrationEnabled) return Optional.empty();
        try {
            return Optional.ofNullable(userServiceClient.getByEmail(email));
        } catch (Exception ex) {
            throw new DownstreamServiceException("user-service", ex.getMessage(), ex);
        }
    }

    @SuppressWarnings("unused")
    private Optional<UserProfileDto> fetchUserProfileFallback(String email, Throwable t) {
        log.warn("user-service unavailable while fetching profile for {}: {}", email, t.toString());
        return Optional.empty();
    }

    // ------------------------------------------------------------ legal-service

    @CircuitBreaker(name = "legalService", fallbackMethod = "requestLegalVerificationFallback")
    public Optional<LegalVerificationAckDto> requestLegalVerification(LegalVerificationRequestDto request) {
        if (!integrationEnabled) return Optional.empty();
        try {
            return Optional.ofNullable(legalServiceClient.openVerification(request));
        } catch (Exception ex) {
            log.warn("legal-service call failed for appId {}: {}", request.getAppId(), ex.toString());
            return Optional.empty();
        }
    }

    @SuppressWarnings("unused")
    private Optional<LegalVerificationAckDto> requestLegalVerificationFallback(LegalVerificationRequestDto request, Throwable t) {
        log.warn("legal-service unavailable while opening verification for {}: {}", request.getAppId(), t.toString());
        return Optional.empty();
    }

    // --------------------------------------------------------- document-service

    @CircuitBreaker(name = "documentService", fallbackMethod = "fetchDocumentChecklistFallback")
    public Optional<DocumentChecklistDto> fetchDocumentChecklist(String appId) {
        if (!integrationEnabled) return Optional.empty();
        try {
            return Optional.ofNullable(documentServiceClient.getChecklist(appId));
        } catch (Exception ex) {
            throw new DownstreamServiceException("document-service", ex.getMessage(), ex);
        }
    }

    @SuppressWarnings("unused")
    private Optional<DocumentChecklistDto> fetchDocumentChecklistFallback(String appId, Throwable t) {
        log.warn("document-service unavailable while fetching checklist for {}: {}", appId, t.toString());
        return Optional.empty();
    }

    // ---------------------------------------------------- notifications-service

    @CircuitBreaker(name = "notificationsService", fallbackMethod = "notifyFallback")
    public boolean notify(NotificationRequestDto request) {
        if (!integrationEnabled) return false;
        try {
            AckResponse ack = notificationsServiceClient.send(request);
            return ack != null && ack.isAccepted();
        } catch (Exception ex) {
            log.warn("notifications-service call failed for {}: {}", request.getRecipientEmail(), ex.toString());
            return false;
        }
    }

    @SuppressWarnings("unused")
    private boolean notifyFallback(NotificationRequestDto request, Throwable t) {
        log.warn("notifications-service unavailable, dropping notification to {}: {}", request.getRecipientEmail(), t.toString());
        return false;
    }

    // ------------------------------------------------------- repayment-service

    @CircuitBreaker(name = "repaymentService", fallbackMethod = "requestRepaymentScheduleFallback")
    public boolean requestRepaymentSchedule(GenerateScheduleRequestDto request) {
        if (!integrationEnabled) return false;
        try {
            AckResponse ack = repaymentServiceClient.generateSchedule(request);
            return ack != null && ack.isAccepted();
        } catch (Exception ex) {
            log.warn("repayment-service call failed for appId {}: {}", request.getAppId(), ex.toString());
            return false;
        }
    }

    @SuppressWarnings("unused")
    private boolean requestRepaymentScheduleFallback(GenerateScheduleRequestDto request, Throwable t) {
        log.warn("repayment-service unavailable while requesting schedule for {}: {}", request.getAppId(), t.toString());
        return false;
    }
}
