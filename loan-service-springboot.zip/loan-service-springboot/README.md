# loan-service — Spring Boot module for hlms's loan domain

This is the `loan-service` microservice extracted from the `hlms-microservices`
project, packaged in the same standalone layout used for `legal-service`.
It's a Spring Boot + Spring Data JPA module covering loan products,
applications, eligibility, mortgage calculations, and status tracking.

## Structure

- `loan-service/` — the actual Maven module (`pom.xml`, `src`)
- `schema/hlms_schema_updated_v2.sql` — the full HLMS database schema
  (shared across all microservices; includes the `loan_application`,
  `loan_product`, `customer_employment_profile`, `disbursement`, and
  `audit_log` tables this service reads/writes)

## Package layout (`com.hlms.loan`)

| Package | Purpose |
|---|---|
| `entity` | JPA `@Entity` classes: `LoanApplication`, `LoanProduct`, `EligibilityAssessment`, `Disbursement`, `CustomerEmploymentProfile`, `BankOfficeDecision`, `LegalVerification`, `AuditLog`, `AppUser` |
| `repository` | Spring Data `JpaRepository` interfaces |
| `service` | Business logic (eligibility scoring, mortgage/EMI calculations, application workflow) |
| `controller` | REST endpoints (see below) |
| `dto` | Request/response payloads |
| `security` | Auth/JWT support for this service |
| `config` | Spring Boot configuration classes |
| `exception` | Custom exceptions + global `@RestControllerAdvice` handler |

## REST endpoints

| Controller | Base path |
|---|---|
| `LoanProductController` | `/api/loan-products` |
| `LoanApplicationController` | `/api/loan-applications` |
| `StatusTrackingController` | `/api/loan-applications` (status sub-resources) |
| `EligibilityController` | `/api/eligibility` |
| `MortgageController` | `/api/mortgage` |
| `LoanGuidanceController` | `/api/loan-guidance` |

## Notes

- This module is part of the larger `hlms-microservices` system (Eureka
  service discovery, Spring Cloud Config, API Gateway). It registers with
  Eureka and expects the config server to be reachable at startup — see
  `src/main/resources/application.yml` for connection settings.
- The schema file here is the same one bundled with `legal-service`, since
  both services share a single Postgres database in this architecture.
