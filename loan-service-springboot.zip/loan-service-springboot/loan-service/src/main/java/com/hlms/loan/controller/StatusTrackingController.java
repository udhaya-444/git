package com.hlms.loan.controller;

import com.hlms.loan.dto.ExpectedCompletion;
import com.hlms.loan.dto.StakeholderInfo;
import com.hlms.loan.dto.TurnaroundReportEntry;
import com.hlms.loan.dto.WorkflowTimelineResponse;
import com.hlms.loan.service.StatusTrackingService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Completes feature "5. Loan Status Tracking & Workflow Visibility":
 * US-LT-03 Stakeholder Assignment Tracking, US-LT-05 Expected Completion Date,
 * US-LT-06 Workflow Timeline View, US-LT-07 Turnaround Time Tracking.
 */
@RestController
@RequestMapping("/api/loan-applications")
@RequiredArgsConstructor
public class StatusTrackingController {

    private final StatusTrackingService service;

    @GetMapping("/{appId}/stakeholder")
    public StakeholderInfo stakeholder(@PathVariable String appId) {
        return service.currentStakeholder(appId);
    }

    @GetMapping("/{appId}/timeline")
    public WorkflowTimelineResponse timeline(@PathVariable String appId) {
        return service.timeline(appId);
    }

    @GetMapping("/{appId}/expected-completion")
    public ExpectedCompletion expectedCompletion(@PathVariable String appId) {
        return service.expectedCompletion(appId);
    }

    @GetMapping("/{appId}/turnaround")
    public List<TurnaroundReportEntry> turnaround(@PathVariable String appId) {
        return service.turnaroundReport(appId);
    }

    // Manager-facing, bank-wide SLA report (US-LT-07) - not scoped to a single app.
    @PreAuthorize("hasAnyRole('ADMIN','BANKOFFICE')")
    @GetMapping("/turnaround-report")
    public Map<String, Double> turnaroundReportAcrossApplications() {
        return service.averageTurnaroundAcrossApplications();
    }
}
