package com.hlms.loan.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter @Setter
public class EligibilityRequest {
    private BigDecimal monthlyIncome;
    private BigDecimal otherEmis;
    private Integer cibilScore;
    private BigDecimal requestedAmount;
    private Integer tenureYears;
    private BigDecimal interestRate; // annual %, e.g. 8.5
}
