package com.hlms.loan.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter @Setter
public class GuidanceAssistantRequest {
    private BigDecimal loanAmount;
    private BigDecimal interestRate;      // annual %
    private BigDecimal maxAffordableEmi;  // optional - used to pick the "recommended" tenure
}
