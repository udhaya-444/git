package com.hlms.loan.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter @Setter
public class LoanRecommendationRequest {
    private String purpose;           // free text, matched loosely against loan_product.category (US-LG-03)
    private BigDecimal monthlyIncome;
    private BigDecimal otherEmis;
    private Integer cibilScore;
    private BigDecimal requestedAmount;
    private Integer tenureYears;
}
