package com.hlms.loan.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter @Setter
public class SubmitApplicationRequest {
    private String productId;
    private BigDecimal loanAmount;
    private Integer tenureYears;
    private String purpose;

    private String applicantName;
    private String applicantMobile;
    private String applicantPan;

    private String addrDoorNo;
    private String addrStreet;
    private String addrCity;
    private String addrState;
    private String addrPincode;

    private String employmentType;
    private String employer;
    private BigDecimal monthlyIncome;
    private BigDecimal otherEmis;

    private String propertyAddress;
    private String propertyType;
    private BigDecimal propertyValue;
}
