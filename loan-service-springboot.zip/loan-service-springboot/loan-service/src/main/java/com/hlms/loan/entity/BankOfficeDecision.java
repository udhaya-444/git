package com.hlms.loan.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "bank_office_decision")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BankOfficeDecision {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "decision_id")
    private Long decisionId;

    @Column(name = "app_id", nullable = false, unique = true)
    private String appId;

    @Column(name = "status", length = 30)
    private String status;

    @Column(name = "officer")
    private String officer;

    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;

    @Column(name = "reason", length = 255)
    private String reason;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
