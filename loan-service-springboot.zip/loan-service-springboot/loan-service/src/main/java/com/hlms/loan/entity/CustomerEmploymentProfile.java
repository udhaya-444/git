package com.hlms.loan.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "customer_employment_profile")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CustomerEmploymentProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "profile_id")
    private Long profileId;

    @Column(name = "user_email", nullable = false, unique = true)
    private String userEmail;

    @Column(name = "employment_type", length = 30)
    private String employmentType;

    @Column(name = "employer", length = 150)
    private String employer;

    @Column(name = "monthly_income", precision = 14, scale = 2)
    private BigDecimal monthlyIncome;

    @Column(name = "other_emis", precision = 14, scale = 2)
    private BigDecimal otherEmis;

    @Column(name = "desired_amount", precision = 14, scale = 2)
    private BigDecimal desiredAmount;

    @Column(name = "pan", length = 20)
    private String pan;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
