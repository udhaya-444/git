package com.hlms.loan.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "disbursement")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Disbursement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "disbursement_id")
    private Long disbursementId;

    @Column(name = "app_id", nullable = false, unique = true)
    private String appId;

    @Column(name = "disbursed_date")
    private OffsetDateTime disbursedDate;

    @Column(name = "amount", precision = 14, scale = 2)
    private BigDecimal amount;

    @Column(name = "ref_no", length = 50)
    private String refNo;

    @Column(name = "mode", length = 30)
    private String mode;

    @Column(name = "bank_details", length = 150)
    private String bankDetails;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
