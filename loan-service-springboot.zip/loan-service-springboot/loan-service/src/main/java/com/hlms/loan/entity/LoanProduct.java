package com.hlms.loan.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "loan_product")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class LoanProduct {

    @Id
    @Column(name = "product_id", length = 50)
    private String productId;

    @Column(name = "name", length = 150, nullable = false)
    private String name;

    @Column(name = "category", length = 50)
    private String category;

    @Column(name = "interest_rate", precision = 5, scale = 2, nullable = false)
    private BigDecimal interestRate;

    @Column(name = "max_tenure_years", nullable = false)
    private Integer maxTenureYears;

    @Column(name = "max_ltv", length = 10)
    private String maxLtv;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
}
